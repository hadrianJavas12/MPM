"""Patch selected ASDF FILE nodes into same-ID serial owner MODULEs.

Default preview is read-only. No source extraction, Lisp execution or tests.
Uses the current ASD, never an old copy; preserves unrelated edits byte-for-byte.

python .tmp/integrate-p2-asdf.py --stage A
python .tmp/integrate-p2-asdf.py --stage A --backup-asd output/P2-A-before/cl-mpm.asd --apply
"""
import argparse,datetime,hashlib,json,os,pathlib,re,subprocess
from dataclasses import dataclass,field

ROOT=pathlib.Path('D:/MPM')
sha=lambda data:hashlib.sha256(data).hexdigest()

@dataclass
class Node:
    kind:str
    value:str
    start:int
    end:int
    children:list=field(default_factory=list)

def tokenize(text):
    result=[];index=0
    while index<len(text):
        char=text[index]
        if char.isspace():index+=1;continue
        if char==';':
            stop=text.find('\n',index);index=len(text) if stop<0 else stop;continue
        if text.startswith('#|',index):
            depth=1;index+=2
            while index<len(text) and depth:
                if text.startswith('#|',index):depth+=1;index+=2
                elif text.startswith('|#',index):depth-=1;index+=2
                else:index+=1
            if depth:raise ValueError('Unclosed Lisp block comment')
            continue
        if text.startswith('#;',index):result.append(Node('discard','#;',index,index+2));index+=2;continue
        if char in '()':result.append(Node(char,char,index,index+1));index+=1;continue
        if char=='"':
            start=index;index+=1;value=[]
            while index<len(text):
                if text[index]=='\\':
                    index+=1
                    if index==len(text):raise ValueError('Unclosed Lisp string escape')
                    value.append(text[index]);index+=1
                elif text[index]=='"':index+=1;break
                else:value.append(text[index]);index+=1
            else:raise ValueError('Unclosed Lisp string')
            result.append(Node('string',''.join(value),start,index));continue
        start=index
        while index<len(text) and not text[index].isspace() and text[index] not in '();"':index+=1
        if index==start:raise ValueError('Unsupported token at '+str(index))
        result.append(Node('symbol',text[start:index],start,index))
    return result

def parse(text):
    tokens=tokenize(text);index=0
    def one():
        nonlocal index
        if index==len(tokens):raise ValueError('Unexpected EOF')
        token=tokens[index];index+=1
        if token.kind=='discard':
            one()  # Reader-discarded source cannot create a candidate component.
            return None
        if token.kind==')':raise ValueError('Unexpected closing parenthesis')
        if token.kind!='(':return token
        children=[]
        while index<len(tokens) and tokens[index].kind!=')':
            child=one()
            if child is not None:children.append(child)
        if index==len(tokens):raise ValueError('Unclosed Lisp list')
        end=tokens[index].end;index+=1
        return Node('list','',token.start,end,children)
    roots=[]
    while index<len(tokens):
        node=one()
        if node is not None:roots.append(node)
    return roots

def atom(node):
    if node.kind not in {'string','symbol'}:raise ValueError('Computed ASDF name/path requires manual review')
    return node.value.removeprefix('#:').removeprefix(':')

def keyword(node):
    return node.value.lower() if node.kind=='symbol' else ''

def property_value(node,key,start=2):
    found=[]
    for index in range(start,len(node.children)-1):
        if keyword(node.children[index])==key:found.append(node.children[index+1])
    if len(found)>1:raise ValueError('Duplicate ASDF property '+key)
    return found[0] if found else None

def components(node):
    value=property_value(node,':components')
    if value is None:return []
    if value.kind!='list':raise ValueError('Computed ASDF components require manual review')
    return [child for child in value.children if child.kind=='list' and len(child.children)>=2
            and keyword(child.children[0]) in {':file',':module'}]

def module_directory(node,parent):
    override=property_value(node,':pathname')
    relative=atom(override) if override is not None else atom(node.children[1])
    return (parent/relative).resolve()

def file_path(node,parent):
    override=property_value(node,':pathname')
    relative=atom(override) if override is not None else atom(node.children[1])
    candidate=parent/relative
    if not candidate.suffix:candidate=candidate.with_suffix('.lisp')
    return candidate.resolve()

def locate(system,route,base):
    current=system;parent=base
    for position,name in enumerate(route):
        matches=[child for child in components(current) if atom(child.children[1])==name]
        if len(matches)!=1:raise ValueError(f'Expected one exact component route {route}; found {len(matches)} matches at {name}')
        current=matches[0]
        if position<len(route)-1:
            if keyword(current.children[0])!=':module':raise ValueError('Non-module route parent '+name)
            parent=module_directory(current,parent);parent.relative_to(ROOT)
    return current,parent

def quoted(value):return '"'+value.replace('\\','\\\\').replace('"','\\"')+'"'

def replacement(node,parent,targets,text,newline):
    if keyword(node.children[0])!=':file':raise ValueError('Selected component is not an original FILE (already migrated?)')
    # Current affected FILE entries are plain. Fail rather than dropping future
    # encoding/feature/compile/dependency options with uncertain module semantics.
    if len(node.children)!=2:raise ValueError('Selected FILE has additional options; preserve them by explicit review before patching')
    name=atom(node.children[1]);relative_root=os.path.relpath(ROOT,parent).replace('\\','/')
    relative_root='./' if relative_root=='.' else relative_root.rstrip('/')+'/'
    line_start=text.rfind('\n',0,node.start)+1
    indent=re.match(r'[ \t]*',text[line_start:node.start]).group(0)
    lines=['(:module '+quoted(name)+' :pathname '+quoted(relative_root)+' :serial t',indent+'  :components (']
    for index,path in enumerate(targets,1):
        resolved=(ROOT/path).resolve();resolved.relative_to(ROOT)
        if not path.endswith('.lisp'):raise ValueError('Expected exact Lisp target '+path)
        child_id=f'p2-{index:02}-'+pathlib.PurePosixPath(path).stem
        lines.append(indent+'    (:file '+quoted(child_id)+' :pathname '+quoted(path[:-5])+')')
    lines.append(indent+'  ))')
    return newline.join(lines)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan',default='docs/architecture/P2_COMPACT_MIGRATION.json')
    parser.add_argument('--stage',nargs='+',required=True,choices=['A','B','C','D','all'])
    parser.add_argument('--asdf',default='cl-mpm.asd')
    parser.add_argument('--backup-asd')
    parser.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    plan_path=(ROOT/args.plan).resolve();plan_path.relative_to(ROOT)
    plan_bytes=plan_path.read_bytes();plan=json.loads(plan_bytes)
    selected={g['stage'] for g in plan['checkpoint_groups']} if 'all' in args.stage else set(args.stage)
    selected_sources={p for g in plan['checkpoint_groups'] if g['stage'] in selected for p in g['sources']}
    asd_path=(ROOT/args.asdf).resolve();asd_path.relative_to(ROOT)
    raw=asd_path.read_bytes();text=raw.decode('utf-8');roots=parse(text)
    systems={}
    for node in roots:
        if (node.kind=='list' and len(node.children)>1
                and atom(node.children[0]).lower().split(':')[-1]=='defsystem'):
            systems.setdefault(atom(node.children[1]).lower(),[]).append(node)
    patches=[];seen=set()
    for source in plan['sources']:
        if source['source_path'] not in selected_sources:continue
        targets=source['compact_ordered_targets']
        if not targets:raise ValueError('No compact owner targets for '+source['source_path'])
        placements=[p for p in source['current_asdf_placements'] if p['source_asd']==args.asdf.replace('\\','/')]
        if not placements:raise ValueError('Missing actual component placement for '+source['source_path'])
        for placement in placements:
            candidates=systems.get(placement['system'].lower(),[])
            if len(candidates)!=1:raise ValueError('Ambiguous/missing selected DEFSYSTEM '+placement['system'])
            system=candidates[0]
            system_base=asd_path.parent
            system_override=property_value(system,':pathname')
            if system_override is not None:system_base=(system_base/atom(system_override)).resolve()
            node,parent=locate(system,placement['component_route'],system_base)
            actual=file_path(node,parent)
            expected=(ROOT/source['source_path']).resolve()
            if actual!=expected:raise ValueError(f'Component path changed: {actual} != {expected}')
            if (node.start,node.end) in seen:raise ValueError('Duplicate selected node')
            seen.add((node.start,node.end))
            patches.append({'source':source['source_path'],'system':placement['system'],'route':placement['component_route'],
                            'start':node.start,'end':node.end,'targets':targets,
                            'replacement':replacement(node,parent,targets,text,'\r\n' if b'\r\n' in raw else '\n')})
    patches.sort(key=lambda row:row['start'])
    if any(left['end']>right['start'] for left,right in zip(patches,patches[1:])):raise ValueError('Overlapping selected ASD nodes')
    updated=text
    for patch in reversed(patches):updated=updated[:patch['start']]+patch['replacement']+updated[patch['end']:]
    parse(updated)  # Lexical balance only; never evaluate ASDF or model source.
    updated_bytes=updated.encode('utf-8')
    summary={'mode':'APPLY' if args.apply else 'READ_ONLY_PREVIEW','stages':sorted(selected),'asdf':str(asd_path),
             'original_sha256':sha(raw),'updated_sha256':sha(updated_bytes),'selected_node_count':len(patches),
             'patches':[{k:v for k,v in p.items() if k not in {'replacement','start','end'}} for p in patches],
             'unrelated_bytes_preserved':True,'native_or_test_execution':'NONE'}
    print(json.dumps(summary,indent=2))
    if not args.apply:return
    if not args.backup_asd:raise ValueError('--backup-asd must name a fresh evidence file')
    backup=(ROOT/args.backup_asd).resolve();backup.relative_to(ROOT)
    proof=backup.with_name(backup.name+'.patch.json')
    if backup.exists() or proof.exists():raise ValueError('Do not overwrite ASD backup/evidence')
    committed=subprocess.check_output(['git','show','HEAD:'+plan_path.relative_to(ROOT).as_posix()],cwd=ROOT)
    normalize=lambda value:value.replace(b'\r\n',b'\n')
    if normalize(committed)!=normalize(plan_bytes):raise ValueError('Checkpoint this exact compact plan before applying')
    if asd_path.read_bytes()!=raw:raise ValueError('ASD changed during planning; do not overwrite concurrent edits')
    backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(raw)
    asd_path.write_bytes(updated_bytes)
    summary['applied_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    summary['plan_sha256']=sha(plan_bytes)
    proof.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print('Selected ASDF nodes updated; original ASD and patch manifest saved. No source/native/test execution.')

if __name__=='__main__':main()
