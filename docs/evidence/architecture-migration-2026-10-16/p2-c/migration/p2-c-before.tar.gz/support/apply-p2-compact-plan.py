"""Guarded mechanical extraction of an explicitly checkpointed compact plan.

Never edits ASDF, starts Lisp or runs a test. Root owns ASD integration and must
commit the implementation before native validation. Default is read-only preview.

python .tmp/apply-p2-compact-plan.py --stage A
python .tmp/apply-p2-compact-plan.py --stage A --backup-dir output/P2-A-before --apply
"""
import argparse,datetime,hashlib,json,pathlib,subprocess
R=pathlib.Path('D:/MPM'); sha=lambda b:hashlib.sha256(b).hexdigest()
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--plan',default='docs/architecture/P2_COMPACT_MIGRATION.json')
parser.add_argument('--stage',nargs='+',choices=['A','B','C','D','all'],required=True)
parser.add_argument('--backup-dir')
parser.add_argument('--apply',action='store_true')
args=parser.parse_args()
plan_path=(R/args.plan).resolve();plan_path.relative_to(R)
plan_raw=plan_path.read_bytes();plan=json.loads(plan_raw)
assert plan['status']=='REVIEWED_EXECUTION_CANDIDATE_NOT_IMPLEMENTED'
assert plan['numerical_behavior_change_allowed'] is False and plan['arithmetic_body_changes_allowed'] is False
stages=plan['checkpoint_groups']
selected_stages={s['stage'] for s in stages} if 'all' in args.stage else set(args.stage)
selected_sources={p for s in stages if s['stage'] in selected_stages for p in s['sources']}
source_records={s['source_path']:s for s in plan['sources'] if s['source_path'] in selected_sources}
assert set(source_records)==selected_sources
raw_sources={path:(R/path).read_bytes() for path in selected_sources}
for path,raw in raw_sources.items():
 assert sha(raw)==source_records[path]['source_sha256_before'],f'Stale before-source {path}'
selected_targets=[t for t in plan['targets'] if t['source_path'] in selected_sources]
payloads={};form_proof=[]
for target in selected_targets:
 path=(R/target['target_path']).resolve();path.relative_to(R)
 assert not path.exists(),f'Refusing existing target {path}'
 raw=raw_sources[target['source_path']]
 for form in target['forms']:
  body=raw[form['source_start_byte']:form['source_end_byte_exclusive']]
  assert sha(body)==form['source_form_sha256'],(target['source_path'],form['source_form_id'])
  form_proof.append({'source_path':target['source_path'],'source_form_id':form['source_form_id'],
                     'original_form_sha256':sha(body),'target_path':target['target_path']})
 if target['copy_mode']=='WHOLE_BYTE_FILE':data=raw
 else:
  chunks=[]
  for context in (target['inserted_package_preamble'],target['inserted_compiler_policy_preamble']):
   if context:chunks.append(context.encode('utf-8')+b'\r\n\r\n')
  for fragment in target['source_fragments']:
   chunk=raw[fragment['source_start_byte']:fragment['source_end_byte_exclusive']]
   assert sha(chunk)==fragment['fragment_sha256']
   chunks.append(chunk)
  data=b''.join(chunks)
  if not data.endswith(b'\n'):data+=b'\r\n'
 assert path not in payloads
 payloads[path]=data
for source,record in source_records.items():
 selected=[p for p in form_proof if p['source_path']==source]
 assert len(selected)==record['source_top_level_form_count']
 assert len({p['source_form_id'] for p in selected})==len(selected)
 assert record['compact_form_coverage_exactly_once']
print(json.dumps({'mode':'APPLY' if args.apply else 'READ_ONLY_PREVIEW','stages':sorted(selected_stages),
 'source_files':len(selected_sources),'targets':len(payloads),'verified_original_forms':len(form_proof),
 'asdf_mutation':'NONE; root must integrate recorded compact_ordered_targets without reverting unrelated edits'},indent=2))
if not args.apply:raise SystemExit(0)
assert args.backup_dir,'--backup-dir must name a fresh stage directory'
backup=(R/args.backup_dir).resolve();backup.relative_to(R)
assert not backup.exists(),'Do not overwrite before-source evidence'
# Require the reviewable plan in current HEAD before source mutation.
committed=subprocess.check_output(['git','show','HEAD:'+plan_path.relative_to(R).as_posix()],cwd=R)
normalize=lambda b:b.replace(b'\r\n',b'\n')
assert normalize(committed)==normalize(plan_raw),'Checkpoint this exact plan before applying it'
for path,raw in raw_sources.items():
 destination=backup/path;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(raw)
for path,data in payloads.items():path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
for source,record in source_records.items():
 depth=len(pathlib.PurePosixPath(source).parent.parts)
 paths=record['compact_ordered_targets']
 shim=';;;; Historical source-path compatibility; ASDF loads owner files directly.\n(in-package :cl-user)\n'
 shim+='(let ((root (merge-pathnames '+json.dumps('../'*depth)+' (uiop:pathname-directory-pathname *load-truename*))))\n'
 shim+='  (dolist (relative \''+'('+ ' '.join(json.dumps(path) for path in paths)+'))\n'
 shim+='    (load (merge-pathnames relative root))))\n'
 (R/source).write_text(shim,encoding='utf-8')
manifest={'phase':'P2_COMPACT_NATIVE_OWNERSHIP','applied_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'stages':sorted(selected_stages),'plan_sha256':sha(plan_raw),'source_before_sha256':{p:sha(b) for p,b in raw_sources.items()},
 'target_sha256':{p.relative_to(R).as_posix():sha(data) for p,data in payloads.items()},'exact_original_forms':form_proof,
 'arithmetic_body_changes':False,'definition_order_changes':'Explicit compact plan schedule only','asdf_changed_by_helper':False,
 'tests_status':'NOT_RUN','native_execution_status':'NOT_RUN'}
(backup/'extraction-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Owner files and compatibility shims written. ASDF integration/commit/native validation remain root responsibilities.')
