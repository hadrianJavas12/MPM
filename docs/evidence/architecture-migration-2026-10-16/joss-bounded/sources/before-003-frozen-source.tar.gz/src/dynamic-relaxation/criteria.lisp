(in-package :cl-mpm/dynamic-relaxation)
(declaim #.cl-mpm/settings:*optimise-setting*)

(defparameter *debug-oobf* t)

(defun combi-stats (sim)
  (destructuring-bind (mass
                       energy
                       oobf-num
                       oobf-denom
                       power)
      (cl-mpm::reduce-over-nodes
       (cl-mpm:sim-mesh sim)
       (lambda (node)
         (if (and (cl-mpm/mesh:node-active node))
             (with-accessors ((active cl-mpm/mesh::node-active)
                              (f-ext cl-mpm/mesh::node-external-force)
                              (res cl-mpm/mesh::node-force)
                              (mass cl-mpm/mesh::node-mass)
                              (volume cl-mpm/mesh::node-volume)
                              (volume-t cl-mpm/mesh::node-volume-true)
                              (vel cl-mpm/mesh::node-velocity)
                              (disp cl-mpm/mesh::node-displacment)
                              )
                 node
               (declare (double-float mass))
               (let (;(mass 1d0)
                     ;; (scale-factor (expt mass 1))
                     (scale-factor 1d0)
                     ;; (scale-factor (/ volume volume-t))
                     )
                 (list
                  scale-factor
                  (* scale-factor (* 0.5d0 mass (cl-mpm/fastmaths::mag-squared vel)))
                  ;(* scale-factor (cl-mpm/fastmaths::mag (cl-mpm/fastmaths::fast-.+-vector f-ext f-int)))
                  (* scale-factor (cl-mpm/fastmaths::mag-squared res))
                  (* scale-factor (cl-mpm/fastmaths::mag-squared f-ext))
                  (* scale-factor
                     (cl-mpm/fastmaths:dot
                      disp f-ext)))))
             (list 0d0 0d0 0d0 0d0 0d0)))
       (lambda (a b) (mapcar (lambda (x y) (declare (double-float x y)) (+ x y)) a b)))
    (declare (double-float mass energy oobf-num oobf-denom power))
    (let ((oobf 0d0))
      ;; (format t "OOBF norms ~E ~E~%" oobf-num oobf-denom)
      (if (> oobf-denom 0d0)
          (setf oobf (sqrt (/ oobf-num oobf-denom)))
          (setf oobf (if (> oobf-num 0d0) sb-ext:double-float-positive-infinity 0d0)))
      (when (and *debug-oobf*
                 (> oobf-denom 0d0))
        (cl-mpm::iterate-over-nodes
         (cl-mpm:sim-mesh sim)
         (lambda (node)
           (with-accessors ((active cl-mpm/mesh::node-active)
                            (agg cl-mpm/mesh::node-agg)
                            ;; (f-ext cl-mpm/mesh::node-external-force)
                            (res cl-mpm/mesh::node-residual)
                            (n-mass cl-mpm/mesh::node-mass)
                            (node-oobf cl-mpm/mesh::node-oobf))
               node
             (if (and active
                        (or
                         (not agg) (cl-mpm/mesh::node-interior node)))
               (when t
                 (setf node-oobf
                       (if (> oobf 0d0)
                           (/ (* n-mass (cl-mpm/fastmaths::mag res))
                               oobf-denom)
                           0d0)))
               (setf node-oobf 0d0))))))
      (if (> mass 0d0)
          ;; (values (/ energy mass) oobf (/ power mass))
          (values energy oobf power)
          (values 0d0 0d0 0d0)))))

(defun combi-stats-mass-factor (sim)
  (destructuring-bind (mass
                       energy
                       oobf-num
                       oobf-denom
                       power)
      (cl-mpm::reduce-over-nodes
       (cl-mpm:sim-mesh sim)
       (lambda (node)
         (if (and (cl-mpm/mesh:node-active node))
             (with-accessors ((active cl-mpm/mesh::node-active)
                              (f-ext cl-mpm/mesh::node-external-force)
                              (res cl-mpm/mesh::node-force)
                              (mass cl-mpm/mesh::node-mass)
                              (volume cl-mpm/mesh::node-volume)
                              (volume-t cl-mpm/mesh::node-volume-true)
                              (vel cl-mpm/mesh::node-velocity)
                              (disp cl-mpm/mesh::node-displacment)
                              )
                 node
               (declare (double-float mass))
               (let (;(mass 1d0)
                     (scale-factor (expt mass 1))
                     ;; (scale-factor 1d0)
                     ;; (scale-factor (/ volume volume-t))
                     )
                 (list
                  scale-factor
                  (* scale-factor (* 0.5d0 mass (cl-mpm/fastmaths::mag-squared vel)))
                  ;(* scale-factor (cl-mpm/fastmaths::mag (cl-mpm/fastmaths::fast-.+-vector f-ext f-int)))
                  (* scale-factor (cl-mpm/fastmaths::mag-squared res))
                  (* scale-factor (cl-mpm/fastmaths::mag-squared f-ext))
                  (* scale-factor
                     (cl-mpm/fastmaths:dot
                      disp f-ext)))))
             (list 0d0 0d0 0d0 0d0 0d0)))
       (lambda (a b) (mapcar (lambda (x y) (declare (double-float x y)) (+ x y)) a b)))
    (declare (double-float mass energy oobf-num oobf-denom power))
    (let ((oobf 0d0))
      ;; (format t "OOBF norms ~E ~E~%" oobf-num oobf-denom)
      (if (> oobf-denom 0d0)
          (setf oobf (sqrt (/ oobf-num oobf-denom)))
          (setf oobf (if (> oobf-num 0d0) sb-ext:double-float-positive-infinity 0d0)))
      (when (and *debug-oobf*
                 (> oobf-denom 0d0))
        (cl-mpm::iterate-over-nodes
         (cl-mpm:sim-mesh sim)
         (lambda (node)
           (with-accessors ((active cl-mpm/mesh::node-active)
                            (agg cl-mpm/mesh::node-agg)
                            ;; (f-ext cl-mpm/mesh::node-external-force)
                            (res cl-mpm/mesh::node-residual)
                            (n-mass cl-mpm/mesh::node-mass)
                            (node-oobf cl-mpm/mesh::node-oobf))
               node
             (if (and active
                        (or
                         (not agg) (cl-mpm/mesh::node-interior node)))
               (when t
                 (setf node-oobf
                       (if (> oobf 0d0)
                           (/ (* n-mass (cl-mpm/fastmaths::mag res))
                               oobf-denom)
                           0d0)))
               (setf node-oobf 0d0))))))
      (if (> mass 0d0)
          (values (/ energy mass) oobf (/ power mass))
          ;; (values energy oobf power)
          (values 0d0 0d0 0d0)))))

(defun combi-stats-aggregated (sim)
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (sim-agg cl-mpm/aggregate::sim-enable-aggregate))
      sim
    (destructuring-bind (energy
                         oobf-num
                         oobf-denom
                         power)
        (cl-mpm::reduce-over-nodes
         (cl-mpm:sim-mesh sim)
         (lambda (node)
           (if (and (cl-mpm/mesh:node-active node)
                    (not (cl-mpm/mesh::node-agg node)))
               (with-accessors ((active cl-mpm/mesh::node-active)
                                (f-ext cl-mpm/mesh::node-external-force)
                                (f-rct cl-mpm/mesh::node-reaction-force)
                                ;(res cl-mpm/mesh::node-residual)
                                (res cl-mpm/mesh::node-force)
                                (f-int cl-mpm/mesh::node-internal-force)
                                (node-oobf cl-mpm/mesh::node-oobf)
                                (mass cl-mpm/mesh::node-mass)
                                (volume cl-mpm/mesh::node-volume)
                                (volume-t cl-mpm/mesh::node-volume-true)
                                (vel cl-mpm/mesh::node-velocity)
                                (disp cl-mpm/mesh::node-displacment)
                                )
                   node
                 (declare (double-float mass))
                 (let ()
                   (list
                    (* 0.5d0 mass (cl-mpm/fastmaths::mag-squared vel))
                    (cl-mpm/fastmaths::mag-squared res)
                    (+
                     (cl-mpm/fastmaths::mag-squared f-ext)
                     (cl-mpm/fastmaths::mag-squared f-rct))
                    ;; (+ (cl-mpm/fastmaths::mag-squared f-ext)
                    ;;    (cl-mpm/fastmaths::mag-squared f-rct)
                    ;;    )
                    (cl-mpm/fastmaths:dot disp f-ext))))
               (list 0d0 0d0 0d0 0d0)))
         (lambda (a b) (mapcar (lambda (x y) (declare (double-float x y)) (+ x y)) a b)))
      (declare (double-float energy oobf-num oobf-denom power))
      (when sim-agg
        (cl-mpm/aggregate::iterate-over-dimensions-with-mutex
         (cl-mpm/mesh::mesh-nd mesh)
         (lambda (d mut)
           (let* ((res (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-force d))
                  (f-ext (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-external-force d))
                  (f-rct (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-reaction-force d))
                  (ma (cl-mpm/aggregate::sim-global-ma sim))
                  (mv (cl-mpm/aggregate::assemble-global-scalar sim #'cl-mpm/mesh::node-mass))
                  (vi (cl-mpm/aggregate::assemble-internal-vec sim #'cl-mpm/mesh::node-velocity d))
                  (disp (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-displacment d)))

             (let ((doobf-num (cl-mpm/fastmaths::mag-squared
                               ;; res
                               (cl-mpm/aggregate::aggregate-vec sim res d)
                               ))
                   (doobf-denom
                     (+
                      (cl-mpm/fastmaths::mag-squared
                       f-rct)
                      (cl-mpm/fastmaths::mag-squared
                       (cl-mpm/aggregate::aggregate-vec sim f-ext d))))
                   (dpower (cl-mpm/fastmaths:dot
                            disp f-ext))
                   (denergy (* 0.5d0 (cl-mpm/fastmaths::dot vi (cl-mpm/aggregate::@-mass-matrix-vec sim vi d)))))
               (sb-thread:with-mutex (mut)
                 (incf oobf-num doobf-num)
                 (incf oobf-denom doobf-denom)
                 (incf power dpower)
                 (incf energy denergy)))))))

      (let ((oobf 0d0)
            (oobf-num (sqrt oobf-num))
            (oobf-denom (sqrt oobf-denom)))

        (if (> oobf-denom 0d0)
            (setf oobf (/ oobf-num oobf-denom))
            (setf oobf (if (> oobf-num 0d0) sb-ext:double-float-positive-infinity 0d0)))

        (when (and *debug-oobf*
                   (> oobf-denom 0d0))
          (cl-mpm::iterate-over-nodes
           (cl-mpm:sim-mesh sim)
           (lambda (node)
             (with-accessors ((active cl-mpm/mesh::node-active)
                              (agg cl-mpm/mesh::node-agg)
                              (int cl-mpm/mesh::node-interior)
                              (f-ext cl-mpm/mesh::node-external-force)
                              ;; (f-int cl-mpm/mesh::node-internal-force)
                              (f-int cl-mpm/mesh::node-force)
                              (n-mass cl-mpm/mesh::node-mass)
                              (node-oobf cl-mpm/mesh::node-oobf))
                 node
               (if (and active
                        ;; (or
                        ;;  int
                        ;;  (not agg))
                        )
                   (setf node-oobf
                         (if (> oobf 0d0)
                             (cl-mpm/fastmaths::mag-squared f-int)
                             ;; (/ (cl-mpm/fastmaths::mag f-int)
                             ;;  ;; (* n-mass (cl-mpm/fastmaths::mag f-int))
                             ;;    oobf-denom)
                             0d0
                             ))
                 (setf node-oobf 0d0)))))

          (cl-mpm::iterate-over-nodes
           (cl-mpm:sim-mesh sim)
           (lambda (node)
             (with-accessors ((active cl-mpm/mesh::node-active)
                              (agg cl-mpm/mesh::node-agg)
                              (int cl-mpm/mesh::node-interior)
                              (node-oobf cl-mpm/mesh::node-oobf))
                 node
               (when (and active
                          ;; agg
                          ;int
                          )
                 (setf node-oobf (/ (sqrt (max node-oobf 0d0)) oobf-denom))
                 ))))
          )
        (values energy oobf power)
        ))))

(defgeneric estimate-energy-norm (sim))
(defmethod estimate-energy-norm ((sim cl-mpm::mpm-sim))
  (let ((energy 0d0)
        (mass 0d0)
        (lock (sb-thread:make-mutex))
        )
    (cl-mpm:iterate-over-nodes
     (cl-mpm:sim-mesh sim)
     (lambda (n)
       (when (cl-mpm/mesh:node-active n)
         (sb-thread:with-mutex (lock)
           (incf mass (cl-mpm/mesh:node-mass n))
           (incf energy
                 (*
                  ;; (/ (cl-mpm/mesh::node-volume n) (cl-mpm/mesh::node-volume-true n))
                  (cl-mpm/mesh:node-mass n)
                  (cl-mpm/mesh::node-mass n)
                  (cl-mpm/fastmaths::mag-squared (cl-mpm/mesh::node-velocity n))
                  ))))))
    ;; (setf
    ;;  energy
    ;;  (cl-mpm::reduce-over-nodes
    ;;   (cl-mpm:sim-mesh sim)
    ;;   (lambda (n)
    ;;     (if (cl-mpm/mesh:node-active n)
    ;;         (*
    ;;          (cl-mpm/mesh::node-mass n)
    ;;          (cl-mpm/fastmaths::mag-squared (cl-mpm/mesh::node-velocity n)))
    ;;         0d0
    ;;         ))
    ;;   #'+))
    ;; (setf
    ;;  mass
    ;;  (cl-mpm::reduce-over-nodes
    ;;   (cl-mpm:sim-mesh sim)
    ;;   (lambda (n)
    ;;     (if (cl-mpm/mesh:node-active n)
    ;;         (cl-mpm/mesh::node-mass n)
    ;;         0d0))
    ;;   #'+))
    (if (= mass 0d0)
        0d0
        (/ energy mass))))
(defmethod estimate-energy-norm ((sim cl-mpm/mpi::mpm-sim-mpi))
  (cl-mpm/mpi::mpi-sum
   (let ((energy 0d0)
         (mass 0d0)
         (lock (sb-thread:make-mutex)))
     (cl-mpm:iterate-over-nodes
      (cl-mpm:sim-mesh sim)
      (lambda (n)
        (when (cl-mpm/mesh:node-active n)
          (when (cl-mpm/mpi::in-computational-domain sim (cl-mpm/mesh::node-position n))
            (sb-thread:with-mutex (lock)
              (incf mass (cl-mpm/mesh:node-mass n))
              (incf energy
                    (*
                     ;; (/ (cl-mpm/mesh::node-volume n) (cl-mpm/mesh::node-volume-true n))
                     (cl-mpm/mesh:node-mass n)
                     (cl-mpm/mesh::node-mass n)
                     (cl-mpm/fastmaths::mag-squared (cl-mpm/mesh::node-velocity n))
                     )))))))
     (if (= mass 0d0)
         0d0
         (/ energy mass)))))

(defgeneric estimate-power-norm (sim))
(defmethod estimate-power-norm ((sim cl-mpm::mpm-sim))
  (let ((dt (cl-mpm:sim-dt sim)))
    (let ((energy 0d0)
          (mass 0d0)
          (lock (sb-thread:make-mutex)))
      (cl-mpm:iterate-over-nodes
       (cl-mpm:sim-mesh sim)
       (lambda (n)
         (when (cl-mpm/mesh:node-active n)
           (sb-thread:with-mutex (lock)
             (incf mass (cl-mpm/mesh:node-mass n))
             (incf energy
                   (*
                    dt
                    ;; (cl-mpm/mesh::node-volume n)
                    ;; (/ (cl-mpm/mesh::node-volume n) (cl-mpm/mesh::node-volume-true n))
                    (cl-mpm/mesh:node-mass n)
                    (cl-mpm/fastmaths:dot
                     ;(cl-mpm/mesh::node-displacment n)
                     (cl-mpm/mesh::node-velocity n)
                     (cl-mpm/mesh::node-external-force n))
                    ))))))
      (if (= mass 0d0)
          0d0
          ;; energy
          (/ energy mass)
          ))))

(defmethod estimate-power-norm ((sim cl-mpm/mpi::mpm-sim-mpi))
  (let ((dt (cl-mpm:sim-dt sim)))
    (cl-mpm/mpi::mpi-sum
     (let ((energy 0d0)
           (mass 0d0)
           (lock (sb-thread:make-mutex)))
       (cl-mpm:iterate-over-nodes
        (cl-mpm:sim-mesh sim)
        (lambda (n)
          (when (cl-mpm/mesh:node-active n)
            (when (cl-mpm/mpi::in-computational-domain sim (cl-mpm/mesh::node-position n))
              (sb-thread:with-mutex (lock)
                (incf mass (cl-mpm/mesh:node-mass n))
                (incf energy
                      (*
                       dt
                       ;; (cl-mpm/mesh::node-volume n)
                       (cl-mpm/mesh:node-mass n)
                       ;; (/ (cl-mpm/mesh::node-volume n) (cl-mpm/mesh::node-volume-true n))
                       (cl-mpm/fastmaths:dot
                        (cl-mpm/mesh::node-velocity n)
                        (cl-mpm/mesh::node-external-force n))
                       )))))))
       (if (= mass 0d0)
           0d0
           (/ energy mass))
       ))))

(defun estimate-oobf-debug (sim)
  (let ((oobf 0d0)
        (nmax 0d0)
        (dmax 0d0)
        (oobf-norm 0d0)
        (lock (sb-thread:make-mutex))
        )
    (cl-mpm::iterate-over-nodes
     (cl-mpm:sim-mesh sim)
     (lambda (node)
       (with-accessors ((active cl-mpm/mesh::node-active)
                        (agg cl-mpm/mesh::node-agg)
                        (f-ext cl-mpm/mesh::node-external-force)
                        (f-int cl-mpm/mesh::node-internal-force)
                        (f-damp cl-mpm/mesh::node-damping-force)
                        (f-ghost cl-mpm/mesh::node-ghost-force)
                        (node-oobf cl-mpm/mesh::node-oobf)
                        )
           node
         (when (and active
                    (not agg))
           (when t;(> (cl-mpm/fastmaths::mag-squared f-ext) 0d0)
             (sb-thread:with-mutex (lock)
               (let ((inc (*
                           (expt (cl-mpm/mesh:node-mass node) 1)
                           ;; (expt (/ (cl-mpm/mesh::node-volume node) (cl-mpm/mesh::node-volume-true node)) 2)
                           (cl-mpm/fastmaths::mag
                            (reduce #'cl-mpm/fastmaths::fast-.+-vector
                                    (list
                                     ;; residual
                                     f-ext
                                     f-int
                                     ;; ;; f-damp
                                     ;; f-ghost
                                     )
                                    )))))
                 (incf node-oobf inc)
                 (setf nmax (+
                             nmax
                             inc)
                       dmax (+
                             dmax
                             (*
                              (expt (cl-mpm/mesh:node-mass node) 1)
                              ;; (expt (/ (cl-mpm/mesh::node-volume node) (cl-mpm/mesh::node-volume-true node)) 2)
                              (cl-mpm/fastmaths::mag
                               f-ext)))))))))))
    (cl-mpm::iterate-over-nodes
     (cl-mpm:sim-mesh sim)
     (lambda (node)
       (with-accessors ((active cl-mpm/mesh::node-active)
                        (agg cl-mpm/mesh::node-agg)
                        (node-oobf cl-mpm/mesh::node-oobf))
           node
         (when (and active (not agg))
           (when t;(> (cl-mpm/fastmaths::mag-squared f-ext) 0d0)
             (sb-thread:with-mutex (lock)
               (setf node-oobf
                     (if (> dmax 0d0)
                         (/ node-oobf dmax)
                         0d0
                         ))
               ))))))
    (if (> dmax 0d0)
      (setf oobf (/ nmax dmax))
      ;;Very odd case, we have external force but no internal forces
      (setf oobf (if (> nmax 0d0) sb-ext:double-float-positive-infinity 0d0)))
    oobf))
(defun estimate-oobf-prod (sim)
(let ((oobf 0d0)
        (nmax 0d0)
        (dmax 0d0)
        (oobf-norm 0d0)
        (lock (sb-thread:make-mutex))
        )
    (cl-mpm::iterate-over-nodes
     (cl-mpm:sim-mesh sim)
     (lambda (node)
       (with-accessors ((active cl-mpm/mesh::node-active)
                        (f-ext cl-mpm/mesh::node-external-force)
                        (f-int cl-mpm/mesh::node-internal-force)
                        (f-damp cl-mpm/mesh::node-damping-force)
                        )
           node
         (when active
           (when t;(> (cl-mpm/fastmaths::mag-squared f-ext) 0d0)
             (sb-thread:with-mutex (lock)
               (setf nmax (+
                           nmax
                           (*
                            (expt (cl-mpm/mesh:node-mass node) 2)
                            ;; (expt (/ (cl-mpm/mesh::node-volume node) (cl-mpm/mesh::node-volume-true node)) 2)
                            (cl-mpm/fastmaths::mag-squared
                             (reduce #'cl-mpm/fastmaths::fast-.+-vector
                                     (list
                                      f-ext
                                      f-int
                                      ;; f-damp
                                      )
                                     ))))
                     dmax (+
                           dmax
                           (*
                            (expt (cl-mpm/mesh:node-mass node) 2)
                            ;; (expt (/ (cl-mpm/mesh::node-volume node) (cl-mpm/mesh::node-volume-true node)) 2)
                            (cl-mpm/fastmaths::mag-squared
                             f-ext))))))))))
    (if (> dmax 0d0)
      (setf oobf (sqrt (/ nmax dmax)))
      ;;Very odd case, we have external force but no internal forces
      (setf oobf (if (> nmax 0d0) sb-ext:double-float-positive-infinity 0d0))
      )
    oobf)
  )


(defun calculate-ke (sim)
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (dt cl-mpm:sim-dt))
      sim
    (let ((ke 0d0))
      (setf
       ke
       (cl-mpm::reduce-over-nodes
        mesh
        (lambda (node)
          (if (and (cl-mpm/mesh:node-active node)
                   (not (cl-mpm/mesh::node-agg node)))
              (* (cl-mpm/mesh::node-mass node)
                 (cl-mpm/fastmaths::mag-squared
                  (cl-mpm/mesh:node-velocity node)))
              0d0))
        #'+))

      (when (cl-mpm/aggregate::sim-enable-aggregate sim)
        (cl-mpm/aggregate::iterate-over-dimensions-serial
         (cl-mpm/mesh::mesh-nd mesh)
         (lambda (d)
           (let* ((vi (cl-mpm/aggregate::assemble-internal-vec sim #'cl-mpm/mesh::node-velocity d)))
             (incf ke
                   (* 0.5d0 (cl-mpm/fastmaths::dot vi (cl-mpm/aggregate::@-mass-matrix-vec sim vi d))))))))
      ke)))

(defgeneric estimate-oobf (sim))
(defmethod estimate-oobf (sim)
  "With better reporting"
  )
(defmethod estimate-oobf (sim)
  (estimate-oobf-debug sim))

(defun estimate-strain-energy (sim)
  (let* ((energy
           (cl-mpm::reduce-over-mps
            (cl-mpm:sim-mps sim)
            (lambda (mp)
              (with-accessors ((volume cl-mpm/particle::mp-volume)
                               (stress cl-mpm/particle::mp-stress-kirchoff)
                               (damage-inc cl-mpm/particle::mp-damage-increment)
                               (strain cl-mpm/particle::mp-strain))
                  mp
                (* 0.5d0 volume (cl-mpm/fastmaths:dot stress strain))))
            #'+)))
    energy))

(defun estimate-static-oobf-mass-scaled (sim)
  (let ((oobf 0d0)
        (nmax 0d0)
        (dmax 0d0)
        (oobf-norm 0d0)
        (lock (sb-thread:make-mutex)))
    (cl-mpm::iterate-over-nodes
     (cl-mpm:sim-mesh sim)
     (lambda (node)
       (with-accessors ((active cl-mpm/mesh::node-active)
                        (agg cl-mpm/mesh::node-agg)
                        (interior cl-mpm/mesh::node-interior)
                        ;; ( cl-mpm/mesh::node-agg)
                        (f-ext cl-mpm/mesh::node-external-force)
                        (f-int cl-mpm/mesh::node-internal-force)
                        (f-damp cl-mpm/mesh::node-damping-force)
                        (f-ghost cl-mpm/mesh::node-ghost-force)
                        (node-oobf cl-mpm/mesh::node-oobf)
                        )
           node
         (when (and active
                    ;; t
                    (or
                     (not agg)
                     interior))
           (when t;(> (cl-mpm/fastmaths::mag-squared f-ext) 0d0)
             (sb-thread:with-mutex (lock)
               (let ((inc (*
                           (expt (cl-mpm/mesh:node-mass node) 1)
                           ;; (expt (/ (cl-mpm/mesh::node-volume node) (cl-mpm/mesh::node-volume-true node)) 2)
                           (cl-mpm/fastmaths::mag
                            (reduce #'cl-mpm/fastmaths::fast-.+-vector
                                    (list
                                     ;; residual
                                     f-ext
                                     f-int
                                     ;; ;; f-damp
                                     ;; f-ghost
                                     )
                                    )))))
                 (incf node-oobf inc)
                 (setf nmax (+
                             nmax
                             inc)
                       dmax (+
                             dmax
                             (*
                              (expt (cl-mpm/mesh:node-mass node) 1)
                              ;; (expt (/ (cl-mpm/mesh::node-volume node) (cl-mpm/mesh::node-volume-true node)) 2)
                              (cl-mpm/fastmaths::mag
                               f-ext)))))))))))
    (if (> dmax 0d0)
      (setf oobf (/ nmax dmax))
      ;;Very odd case, we have external force but no internal forces
      (setf oobf (if (> nmax 0d0) sb-ext:double-float-positive-infinity 0d0)))
    oobf))
(defun estimate-static-oobf-aggregated (sim)
  (let ((oobf 0d0)
        (nmax 0d0)
        (dmax 0d0)
        (oobf-norm 0d0)
        (lock (sb-thread:make-mutex)))
    (cl-mpm::iterate-over-nodes
     (cl-mpm:sim-mesh sim)
     (lambda (node)
       (with-accessors ((active cl-mpm/mesh::node-active)
                        (agg cl-mpm/mesh::node-agg)
                        (interior cl-mpm/mesh::node-interior)
                        (f-ext cl-mpm/mesh::node-external-force)
                        (f-int cl-mpm/mesh::node-internal-force)
                        (f-ghost cl-mpm/mesh::node-ghost-force)
                        (node-oobf cl-mpm/mesh::node-oobf))
           node
         (when (and active (not agg))
           (sb-thread:with-mutex (lock)
             (let ((inc
                     (cl-mpm/fastmaths::mag-squared
                      (cl-mpm/fastmaths::fast-.+
                       f-ext
                       (cl-mpm/fastmaths::fast-.+
                        f-int
                        f-ghost
                        ))
                      )))
               (incf node-oobf inc)
               (setf nmax (+
                           nmax
                           inc)
                     dmax (+
                           dmax
                           (cl-mpm/fastmaths::mag-squared f-ext)))))))))
    (with-accessors ((mesh cl-mpm:sim-mesh))
        sim
      (when (cl-mpm/aggregate::sim-enable-aggregate sim)
        (cl-mpm/aggregate::iterate-over-dimensions-with-mutex
         (cl-mpm/mesh::mesh-nd mesh)
         (lambda (d mut)
           (let* ((f-ext (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-external-force d))
                  (f-int (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-internal-force d))
                  (f-ghost (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-ghost-force d)))
             (let ((d-nmax (cl-mpm/fastmaths::mag-squared
                            (cl-mpm/aggregate::aggregate-vec
                             sim
                             (cl-mpm/fastmaths::fast-.+
                              f-ghost
                              (cl-mpm/fastmaths:fast-.+ f-ext f-int))
                             d)))
                   (d-dmax (cl-mpm/fastmaths::mag-squared
                            (cl-mpm/aggregate::aggregate-vec
                             sim
                             f-ext
                             d))))
               (sb-thread:with-mutex (mut)
                 (incf nmax d-nmax)
                 (incf dmax d-dmax))))))))
    (if (> dmax 0d0)
        (setf oobf (sqrt (/ nmax dmax)))
      ;;Very odd case, we have external force but no internal forces
      (setf oobf (if (> nmax 0d0) sb-ext:double-float-positive-infinity 0d0)))
    oobf))

(declaim (notinline true-intertial-criteria))
(defun true-intertial-criteria (sim loadstep-dt)
  (if (> loadstep-dt 0d0)
      (destructuring-bind (inertia-norm ext-norm)
          (cl-mpm::reduce-over-nodes
           (cl-mpm:sim-mesh sim)
           (lambda (node)
             (if (and (cl-mpm/mesh:node-active node)
                      (or
                       (not (cl-mpm/mesh::node-agg node))
                       ;; (cl-mpm/mesh::node-interior node)
                       )
                      )
                 (with-accessors ((active cl-mpm/mesh::node-active)
                                  (f-ext cl-mpm/mesh::node-external-force)
                                  ;; (f-int cl-mpm/mesh::node-residual)
                                  (res cl-mpm/mesh::node-residual)
                                  (node-oobf cl-mpm/mesh::node-oobf)
                                  (mass cl-mpm/mesh::node-mass)
                                  (volume cl-mpm/mesh::node-volume)
                                  (volume-t cl-mpm/mesh::node-volume-true)
                                  (vel cl-mpm/mesh::node-velocity)
                                  (disp cl-mpm/mesh::node-displacment)
                                  (true-mass cl-mpm/mesh::node-true-mass)
                                  )
                     node
                   (declare (double-float mass))
                   (list
                    (*
                     (* true-mass true-mass)
                     (cl-mpm/fastmaths::mag-squared
                      (cl-mpm/fastmaths:fast-scale-vector
                       disp
                       (expt (/ 1d0 loadstep-dt) 2))))
                    (cl-mpm/fastmaths::mag-squared f-ext)))
                 (list 0d0 0d0)))
           (lambda (a b) (mapcar (lambda (x y) (declare (double-float x y)) (+ x y)) a b)))
        (if (> ext-norm 0d0)
            (sqrt (/ inertia-norm ext-norm))
            (if (> inertia-norm 0d0) sb-ext:double-float-positive-infinity 0d0)))))

(defgeneric estimate-static-oobf (sim))

(defmethod estimate-static-oobf ((sim cl-mpm::mpm-sim))
  (estimate-static-oobf-mass-scaled sim)
  ;; (estimate-oobf sim)
  )

(defmethod estimate-static-oobf ((sim cl-mpm/aggregate::mpm-sim-aggregated))
  (estimate-static-oobf-aggregated sim)
  ;; (estimate-oobf sim)
  )


(defmethod cl-mpm::update-dynamic-stats ((sim cl-mpm:mpm-sim))
  (with-accessors ((stats-energy cl-mpm::sim-stats-energy)
                   (stats-oobf cl-mpm::sim-stats-oobf)
                   (stats-power cl-mpm::sim-stats-power)
                   (stats-work cl-mpm::sim-stats-work))
      sim
    (multiple-value-bind (e o p) (combi-stats sim)
      (setf stats-energy e
            stats-oobf o
            stats-power p)
      (incf stats-work p))))


(defmethod cl-mpm::update-dynamic-stats ((sim cl-mpm/dynamic-relaxation::mpm-sim-dr-ul))
  (with-accessors ((stats-energy cl-mpm::sim-stats-energy)
                   (stats-oobf cl-mpm::sim-stats-oobf)
                   (stats-power cl-mpm::sim-stats-power)
                   (stats-work cl-mpm::sim-stats-work))
      sim
    (multiple-value-bind (e o p) (cl-mpm/dynamic-relaxation::combi-stats-aggregated sim)
      (setf stats-energy e
            stats-oobf o
            stats-power p)
      (incf stats-work p))
    ;; (if (cl-mpm/aggregate::sim-enable-aggregate sim)
    ;;    ;;Other
    ;;    ;; (progn)
    ;;     ;; (multiple-value-bind (e o p) (cl-mpm/dynamic-relaxation::combi-stats sim)
    ;;     ;;   (setf stats-energy e
    ;;     ;;         stats-oobf o
    ;;     ;;         stats-power p)
    ;;     ;;   (incf stats-work p))
    ;;     )
    ))

(defmethod cl-mpm::update-dynamic-stats ((sim cl-mpm/aggregate::mpm-sim-aggregated))
  (with-accessors ((stats-energy cl-mpm::sim-stats-energy)
                   (stats-oobf cl-mpm::sim-stats-oobf)
                   (stats-power cl-mpm::sim-stats-power)
                   (stats-work cl-mpm::sim-stats-work))
      sim
    (multiple-value-bind (e o p) (cl-mpm/dynamic-relaxation::combi-stats-aggregated sim)
      (setf stats-energy e
            stats-oobf o
            stats-power p)
      (incf stats-work p))
    ;; (if (cl-mpm/aggregate::sim-enable-aggregate sim)
    ;;     (multiple-value-bind (e o p) (cl-mpm/dynamic-relaxation::combi-stats-aggregated sim)
    ;;       (setf stats-energy e
    ;;             stats-oobf o
    ;;             stats-power p)
    ;;       (incf stats-work p))
    ;;     (multiple-value-bind (e o p) (cl-mpm/dynamic-relaxation::combi-stats-mass-factor sim)
    ;;       (setf stats-energy e
    ;;             stats-oobf o
    ;;             stats-power p)
    ;;       (incf stats-work p))
    ;;     )
    ;; (setf stats-oobf (res-norm-aggregated sim))
    ))

(defun df-to-jacobian (sim df)
  (let* ((h (the double-float (cl-mpm/mesh:mesh-resolution (cl-mpm:sim-mesh sim))))
         (ddf (cl-mpm/fastmaths::fast-scale! (cl-mpm/fastmaths:fast-.- df (cl-mpm/utils:matrix-eye 1d0)) (/ 1d0 h))))
    (cl-mpm/fastmaths:fast-.+ (cl-mpm/utils:matrix-eye 1d0) ddf)))


(defun compute-max-deformation-2d (sim)
  (cl-mpm::reduce-over-cells
   (cl-mpm:sim-mesh sim)
   (lambda (c)
     (if (and (cl-mpm/mesh::cell-active c)
              (not (cl-mpm/mesh::cell-partial c)))
         (let* ((df (cl-mpm/mesh::cell-deformation-gradient c))
                (lens (magicl:@ df (cl-mpm/utils:vector-from-list (list 1d0 1d0 0d0)))))
           (let ((lens-2d (list (cl-mpm/utils:varef lens 0)
                                (cl-mpm/utils:varef lens 1))))
             (/ (reduce #'max lens-2d)
                (reduce #'min lens-2d))))
         0d0))
   #'max))

(defun compute-max-deformation-3d (sim)
  (cl-mpm::reduce-over-cells
   (cl-mpm:sim-mesh sim)
   (lambda (c)
     (if (and (cl-mpm/mesh::cell-active c)
              (not (cl-mpm/mesh::cell-partial c)))
         (let* ((df (cl-mpm/mesh::cell-deformation-gradient c))
                (lens (magicl:@ df (cl-mpm/utils:vector-from-list (list 1d0 1d0 1d0)))))
           (let ((lens-3d (list (cl-mpm/utils:varef lens 0)
                                (cl-mpm/utils:varef lens 1)
                                (cl-mpm/utils:varef lens 2))))
             (/ (reduce #'max lens-3d)
                (reduce #'min lens-3d))))
         ;; (multiple-value-bind (l v) (cl-mpm::eig (df-to-jacobian sim (cl-mpm/mesh::cell-deformation-gradient c)))
         ;;   (/ (the double-float (reduce #'max l))
         ;;      (the double-float (reduce #'min l))))
         0d0))
   #'max))

(defun compute-max-deformation (sim)
  ;; (/)
  (if (= (cl-mpm/mesh:mesh-nd (cl-mpm:sim-mesh sim)) 2)
          (compute-max-deformation-2d sim)
          (compute-max-deformation-3d sim))
  ;; 1d0
  ;; (cl-mpm/mesh:mesh-resolution (cl-mpm:sim-mesh sim))
  )

(defmethod print-max-deformation (sim)
  (let ((cmax 0d0)
        (fmax nil))
    (cl-mpm::iterate-over-cells-serial
     (cl-mpm:sim-mesh sim)
     (lambda (c)
       (if (and (cl-mpm/mesh::cell-active c)
                (not (cl-mpm/mesh::cell-partial c)))
           (let ((ct (multiple-value-bind (l v) (cl-mpm::eig (df-to-jacobian sim (cl-mpm/mesh::cell-deformation-gradient c)))
                      (/ (the double-float (reduce #'max l))
                         (the double-float (reduce #'min l))))))
             (when (> ct cmax)
               (setf cmax ct
                     fmax (df-to-jacobian sim (cl-mpm/mesh::cell-deformation-gradient c))))))))
    (format t "cmax ~E ~% f: ~A ~%" cmax fmax)
    ))

(defun criteria-deformation-gradient (sim &key (criteria 10d0))
  (%criteria-deformation-gradient sim criteria))
(defgeneric %criteria-deformation-gradient (sim criteria))
(defmethod %criteria-deformation-gradient (sim criteria)
  (>
   (compute-max-deformation sim)
   criteria))

(declaim (notinline res-norm-aggregated))
(defun vel-norm-aggregated (sim)
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (sim-agg cl-mpm/aggregate::sim-enable-aggregate))
      sim
    (let ((res-norm 0d0))
      (incf res-norm
            (cl-mpm::reduce-over-nodes
             mesh
             (lambda (node)
               (with-accessors ((active cl-mpm/mesh::node-active)
                                (agg cl-mpm/mesh::node-agg)
                                (internal cl-mpm/mesh::node-interior)
                                (res cl-mpm/mesh::node-force)
                                (mass cl-mpm/mesh::node-mass)
                                (vel cl-mpm/mesh::node-velocity))
                   node
                 (if (and
                      active
                      (or
                       internal
                       (not agg)))
                     (cl-mpm/fastmaths::mag-squared vel)
                     0d0)))
             #'+))
      (sqrt res-norm))))

(declaim (notinline res-norm-aggregated))
(defun res-norm-aggregated (sim)
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (sim-agg cl-mpm/aggregate::sim-enable-aggregate))
      sim
    (let ((res-norm 0d0))
      (incf res-norm
            (cl-mpm::reduce-over-nodes
             mesh
             (lambda (node)
               (with-accessors ((active cl-mpm/mesh::node-active)
                                (agg cl-mpm/mesh::node-agg)
                                (internal cl-mpm/mesh::node-interior)
                                (res cl-mpm/mesh::node-force)
                                (mass cl-mpm/mesh::node-mass)
                                (vel cl-mpm/mesh::node-velocity))
                   node
                 (if (and
                      (or
                       ;; internal
                       (not agg))
                      active)
                     ;; (loop for r across (cl-mpm/utils:fast-storage res)
                     ;;       for v across (cl-mpm/utils:fast-storage vel)
                     ;;       sum (* (abs r) (abs v)))
                     ;; (abs (cl-mpm/fastmaths:dot res vel))
                     ;; (/
                     ;;  (cl-mpm/fastmaths:mag (cl-mpm/fastmaths:fast-.- res res-prev))
                     ;;  (+ 1d-10 (cl-mpm/fastmaths:mag res)))
                     ;; (* ;mass
                     ;;  (cl-mpm/fastmaths::mag-squared vel))
                     (cl-mpm/fastmaths::mag-squared res)
                     ;; (cl-mpm/fastmaths::mag-squared vel)
                     0d0)))
             #'+))
      (when sim-agg
        (cl-mpm/aggregate::iterate-over-dimensions-with-mutex
         (cl-mpm/mesh::mesh-nd mesh)
         (lambda (d mut)
           (let* ((res (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-force d)))
             (let ((dres (cl-mpm/fastmaths::mag-squared
                          (cl-mpm/aggregate::aggregate-vec
                           sim
                           res
                           d))))
               (sb-thread:with-mutex (mut)
                 (incf res-norm dres)))))))

      (sqrt res-norm))))

(defun damage-increment-criteria-mesh (sim)
  (let ((damage-max 0d0))
    (cl-mpm:iterate-over-nodes
     (cl-mpm:sim-mesh sim)
     (lambda (n)
       (when (cl-mpm/mesh::node-active n)
         (setf (cl-mpm/mesh::node-damage n) 0d0))))
    (cl-mpm::iterate-over-mps
     (cl-mpm:sim-mps sim)
     (lambda (mp)
       (when (typep mp 'cl-mpm/particle::particle-damage)
         (cl-mpm:iterate-over-neighbours
          (cl-mpm:sim-mesh sim)
          mp
          (lambda (node svp grads fsvp fgrads)
            (sb-thread:with-mutex ((cl-mpm/mesh:node-lock node))
              (incf (cl-mpm/mesh::node-damage node)
                    (* svp
                       (cl-mpm/particle::mp-volume mp)
                       (cl-mpm/particle::mp-damage-increment mp)))))))))
    (cl-mpm:iterate-over-nodes
     (cl-mpm:sim-mesh sim)
     (lambda (n)
       (when (cl-mpm/mesh::node-active n)
         (setf (cl-mpm/mesh::node-damage n) (/ (cl-mpm/mesh::node-damage n) (cl-mpm/mesh::node-volume n))))))
    (cl-mpm:iterate-over-nodes
     (cl-mpm:sim-mesh sim)
     (lambda (n)
       (when (cl-mpm/mesh::node-active n)
         (setf damage-max (max damage-max (cl-mpm/mesh::node-damage n))))))
    damage-max)
  (cl-mpm/damage::g2p-damage sim))

(defun damage-increment-criteria-mp (sim)
  (cl-mpm::reduce-over-mps
   (cl-mpm:sim-mps sim)
   (lambda (mp)
     (if (typep mp 'cl-mpm/particle::particle-damage)
         (min 1d0 (cl-mpm/particle::mp-damage-increment mp))
         0d0))
   #'max))

(defgeneric damage-increment-criteria (sim)
  (:documentation "Damage criteria")
  )

(defmethod damage-increment-criteria ((sim t))
  0d0)
(defmethod damage-increment-criteria ((sim cl-mpm/dynamic-relaxation::mpm-sim-dr-ul))
  ;; (compute-max-damage-energy-crit sim)
  (damage-increment-criteria-mp sim)
  ;; (damage-increment-criteria-mesh sim)
  )

(declaim (notinline compute-damage-delta))
(defun compute-damage-delta (sim)
  (let* ((delta-ds
           (cl-mpm::reduce-over-mps
            (cl-mpm:sim-mps sim)
            (lambda (mp)
              (if (typep mp 'cl-mpm/particle::particle-damage)
                (with-accessors ((damage cl-mpm/particle::mp-damage)
                                 (damage-prev cl-mpm/particle::mp-damage-prev-trial)
                                 (inc cl-mpm/particle::mp-damage-increment)
                                 (mass cl-mpm/particle::mp-mass))
                    mp
                  (expt (* mass (- damage damage-prev)) 2))
                0d0))
            #'+))
         (delta-incs
           (cl-mpm::reduce-over-mps
            (cl-mpm:sim-mps sim)
            (lambda (mp)
              (if (typep mp 'cl-mpm/particle::particle-damage)
                  (with-accessors ((damage cl-mpm/particle::mp-damage)
                                   (damage-prev cl-mpm/particle::mp-damage-prev-trial)
                                   (inc cl-mpm/particle::mp-damage-increment)
                                   (mass cl-mpm/particle::mp-mass))
                      mp
                    (expt (* mass damage) 2))
                  0d0))
            #'+)))
    (if (> delta-incs 0d0)
        (sqrt (/ delta-ds delta-incs))
        0d0)))





(defun compute-max-damage-energy-crit (sim)
  (let* ((energy
           (cl-mpm::reduce-over-mps
            (cl-mpm:sim-mps sim)
            (lambda (mp)
              (if (typep mp 'cl-mpm/particle::particle-damage)
                  (with-accessors ((volume cl-mpm/particle::mp-volume)
                                   (stress cl-mpm/particle::mp-undamaged-stress)
                                   (damage-inc cl-mpm/particle::mp-damage-increment)
                                   (strain cl-mpm/particle::mp-strain))
                      mp
                    (* 0.5d0 volume damage-inc (cl-mpm/fastmaths:dot stress strain)))
                  0d0))
            #'+))
         (undamaged-energy
           (cl-mpm::reduce-over-mps
            (cl-mpm:sim-mps sim)
            (lambda (mp)
              (if (typep mp 'cl-mpm/particle::particle-damage)
                  (with-accessors ((volume cl-mpm/particle::mp-volume)
                                   (stress cl-mpm/particle::mp-undamaged-stress)
                                   (damage-n cl-mpm/particle::mp-damage-n)
                                   (damage cl-mpm/particle::mp-damage)
                                   (strain cl-mpm/particle::mp-strain))
                      mp
                    (* 0.5d0 volume (- 1d0 damage) (cl-mpm/fastmaths:dot stress strain)))
                  0d0))
            #'+)))
    ;; (format t "Energy reduction ~E - undamaged energy ~E ~%" energy undamaged-energy)
    (if (> undamaged-energy 0d0)
        (/ energy undamaged-energy)
        0d0)))
