(in-package :cl-mpm/dynamic-relaxation)
(declaim #.cl-mpm/settings:*optimise-setting*)
(defparameter *total-iter* 0)


(defgeneric convergence-criteria (sim))

(defmethod convergence-criteria ((sim cl-mpm::mpm-sim))
  t)


(defgeneric convergence-check (sim)
  (:documentation "A check to see if our converged configuration has failed some extra criteria"))

(defmethod convergence-check ((sim cl-mpm::mpm-sim))
  t)




(deftype plastic-damage-type () `(and
                                  cl-mpm/particle::particle-damage
                                  cl-mpm/particle::particle-plastic))

(defun set-mp-plastic-damage (sim &key (enable-damage t) (enable-plastic t))
  (cl-mpm:iterate-over-mps
   (cl-mpm:sim-mps sim)
   (lambda (mp)
     (typecase mp
       (plastic-damage-type
        (setf (cl-mpm/particle::mp-enable-damage mp) enable-damage
              (cl-mpm/particle::mp-enable-plasticity mp) enable-plastic))
       (cl-mpm/particle::particle-damage
        (setf (cl-mpm/particle::mp-enable-damage mp) enable-damage))
       (cl-mpm/particle::particle-plastic
        (setf (cl-mpm/particle::mp-enable-plasticity mp) enable-plastic)))
     ;; (when (typep mp 'cl-mpm/particle::particle-damage)
     ;;   (setf (cl-mpm/particle::mp-enable-damage mp) enable-damage))
     ;; (when (typep mp 'cl-mpm/particle::particle-plastic)
     ;;   (setf (cl-mpm/particle::mp-enable-plasticity mp) enable-plastic))
     )))

(defgeneric save-timestep-preamble (sim output-dir))
(defmethod save-timestep-preamble (sim output-dir)
  (with-open-file (stream (merge-pathnames output-dir "./timesteps.csv") :direction :output :if-exists :supersede)
    (cl-mpm:sim-format sim stream "steps,time,damage,plastic,energy,oobf,work,step-type,mass~%")))

(defun save-timestep (sim output-dir step type)
  (when (uiop:file-exists-p (merge-pathnames output-dir "timesteps.csv"))
    (with-open-file (stream (merge-pathnames "timesteps.csv" output-dir) :direction :output :if-exists :append)
      (cl-mpm:sim-format sim stream "~D,~f,~f,~f,~f,~f,~f,~A,~f~%"
              step
              (cl-mpm::sim-time sim)
              (get-damage sim)
              (get-plastic sim)
              (cl-mpm::sim-stats-energy sim)
              (cl-mpm::sim-stats-oobf sim)
              (cl-mpm::sim-stats-work sim)
              type
              0d0))))


(defgeneric save-vtks (sim output-dir step))
(defmethod save-vtks (sim output-dir step)
  (cl-mpm:sim-format sim t "Save vtks ~D~%" step)
  (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_~5,'0d.vtk" step)) sim)
  (cl-mpm/output::save-vtk-nodes (merge-pathnames output-dir (format nil "sim_nodes_~5,'0d.vtk" step)) sim)
  (cl-mpm/output::save-vtk-cells (merge-pathnames output-dir (format nil "sim_cells_~5,'0d.vtk" step)) sim)
  (cl-mpm/penalty:save-vtk-penalties (uiop:merge-pathnames* output-dir (format nil "sim_p_~5,'0d.vtk" step)) sim))


(defgeneric save-vtks-dr-step (sim output-dir step iter))
(defmethod save-vtks-dr-step (sim output-dir step iter)
  (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_step_~5,'0d_~5,'0d.vtk" step iter)) sim)
  (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_step_nodes_~5,'0d_~5,'0d.vtk" step iter)) sim)
  (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_step_cells_~5,'0d_~5,'0d.vtk" step iter)) sim)
  (cl-mpm/penalty:save-vtk-penalties (merge-pathnames output-dir (format nil "sim_step_p_~5,'0d_~5,'0d.vtk" step iter)) sim))

(defgeneric save-conv-preamble (sim output-dir))
(defmethod save-conv-preamble (sim output-dir)
  (with-open-file (stream (merge-pathnames output-dir "conv.csv") :direction :output :if-exists :supersede)
    (cl-mpm:sim-format sim stream "iter,step,real-time,plastic,damage,oobf,energy~%")))

(defun save-conv-step (sim output-dir total-iter step real-time oobf energy)
  (unless (uiop:file-exists-p (merge-pathnames output-dir "conv.csv"))
    (save-conv-preamble sim output-dir))
  (with-open-file (stream (merge-pathnames output-dir "conv.csv") :direction :output :if-exists :append)
    (cl-mpm:sim-format sim stream "~D,~D,~f,~f,~f,~f,~f~%" total-iter step real-time (get-plastic sim) (get-damage sim)
            (if (sb-ext:float-infinity-p oobf) 0d0 oobf) energy)))

(defgeneric save-conv (sim output-dir iter))

(defmethod save-conv (sim output-dir iter)
  (let ((oobf (cl-mpm::sim-stats-oobf sim))
        (energy (/ (cl-mpm::sim-stats-energy sim) (cl-mpm::sim-stats-work sim)))
        (real-time (cl-mpm::sim-time sim)))
    (with-open-file (stream (merge-pathnames output-dir "conv.csv") :direction :output :if-exists :append)
      (cl-mpm:sim-format sim stream "~D,~D,~f,~f,~f,~f,~f~%" iter 0 real-time (get-plastic sim) (get-damage sim)
              oobf energy))))

(defun get-damage (sim)
  (lparallel:pmap-reduce
   (lambda (mp)
     (if (typep mp 'cl-mpm/particle::particle-damage)
         (*
          (cl-mpm/particle::mp-mass mp)
          (cl-mpm/particle:mp-damage mp))
         0d0))
   #'+
   (cl-mpm:sim-mps sim)))
(defun get-plastic (sim)
  (lparallel:pmap-reduce
   (lambda (mp)
     (if (typep mp 'cl-mpm/particle::particle-plastic)
         (*
          (cl-mpm/particle::mp-mass mp)
          (cl-mpm/particle::mp-strain-plastic-vm mp))
         0d0))
   #'+
   (cl-mpm:sim-mps sim)))




(defparameter *max-deformation-gradient* 10d0)

(defun generalised-staggered-solve (sim
                                    &key
                                      (output-dir "./output/")
                                      (crit 1d-3)
                                      (dt-scale 1d0)
                                      (substeps 10)
                                      (post-iter-step (lambda (i e o)))
                                      (enable-damage t)
                                      (enable-plastic t)
                                      (max-damage-inc 0.6d0)
                                      (damping 1d0)
                                      (staggered-steps 10)
                                      (sub-conv-steps 50)
                                      (true-stagger nil))
  (let* ((damage-prev (get-damage sim))
         (damage damage-prev)
         (oobf-crit   crit)
         (energy-crit 1d0)
         (damage-crit crit)
         (dconv damage-crit)
         (total-i 0)
         (stagger-iters 0))
    (set-mp-plastic-damage sim :enable-damage enable-damage :enable-plastic enable-plastic)

    (setf (cl-mpm:sim-enable-damage sim) nil)
    (let ((additional-conv nil))
      (loop for i from 0 to 100
            while (not additional-conv)
            do
               (progn
                 (loop for stagger-i from 0 to staggered-steps
                       while (or (>= dconv damage-crit)
                                 ;; (not additional-conv)
                                 (>= (cl-mpm::sim-stats-oobf sim) (cl-mpm/dynamic-relaxation::sim-convergence-critera sim)))
                       do
                          (progn
                            (let ((iv 0))
                              (cl-mpm/dynamic-relaxation:converge-quasi-static
                               sim
                               :kinetic-damping nil
                               :oobf-crit oobf-crit
                               :energy-crit energy-crit
                               :dt-scale dt-scale
                               :substeps substeps
                               :convergance-criteria
                               (lambda (sim f o)
                                 (and
                                  (<= o (cl-mpm/dynamic-relaxation::sim-convergence-critera sim))
                                  (convergence-criteria sim)))
                               :conv-steps sub-conv-steps
                               :damping-factor damping
                               :post-iter-step
                               (lambda (i e o)
                                 (incf iv)
                                 (when nil
                                   (let ((max-def (compute-max-deformation sim)))
                                     (when (> max-def 10d0)
                                       (cl-mpm:sim-format sim t "Deformation gradient criteria exceeded~%")
                                       (error (make-instance 'non-convergence-error
                                                             :text "Deformation gradient J exceeded"
                                                             :ke-norm 0d0
                                                             :oobf-norm 0d0)))
                                     ;; (let ((true-intertia (true-intertial-criteria sim (sim-dt-loadstep sim))))
                                     ;;   (cl-mpm:sim-format sim t "True intertia ~E~%" true-intertia)
                                     ;;   (save-conv-step sim output-dir *total-iter* global-step
                                     ;;                   0d0
                                     ;;                   o
                                     ;;                   ;; true-intertia
                                     ;;                   max-def
                                     ;;                   )
                                     ;;   (setf inertia true-intertia)
                                     ;;   (when (> true-intertia 1d-4)
                                     ;;     (cl-mpm:sim-format sim t "Inertia criteria exceeded~%")
                                     ;;     (error (make-instance 'error-inertia-criteria
                                     ;;                           :text "True inertia exceeded"
                                     ;;                           :inertia-norm true-intertia))))
                                     ))
                                 (funcall post-iter-step i e o)
                                 (unless true-stagger
                                   (let ((damage-inc (damage-increment-criteria sim)))
                                     (when (> damage-inc max-damage-inc)
                                       (cl-mpm:sim-format sim t "Damage criteria failed~%")
                                       (error (make-instance 'non-convergence-error
                                                             :text "Damage criteria exeeded"
                                                             :ke-norm 0d0
                                                             :oobf-norm 0d0)))))))
                              (if (and
                                   enable-damage
                                   (typep sim 'cl-mpm/damage::mpm-sim-damage))
                                  (progn
                                    (let ((fast-trial-conv oobf-crit)
                                          (damage-iter t)
                                          (save-update nil))
                                      (loop for d from 0 to 100
                                            while (and
                                                   ;; (<= fast-trial-conv (sqrt oobf-crit))
                                                   damage-iter)
                                            do
                                               (setf (cl-mpm:sim-enable-damage sim) t)
                                               (if (<= d 5)
                                                   (cl-mpm/damage::calculate-damage sim (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim))
                                                   (dotimes (i 5)
                                                     (cl-mpm/damage::calculate-damage sim (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim))))
                                               (when true-stagger
                                                 (setf (cl-mpm:sim-enable-damage sim) nil))
                                               (setf damage (get-damage sim))

                                               (setf dconv (compute-damage-delta sim))
                                               (setf damage-prev damage)
                                               (unless (>= dconv damage-crit)
                                                 (setf damage-iter nil))
                                               (cl-mpm:sim-format sim t "step ~D/~D - d-conv ~E - ~E~%" stagger-i d dconv fast-trial-conv)
                                               (cl-mpm:sim-format sim t "Damage ~E - prev damage ~E ~%" damage damage-prev)
                                               (cl-mpm:sim-format sim t "step ~D/~D - d-conv ~E~%" stagger-i d dconv)
                                               (let ((damage-inc (damage-increment-criteria sim)))
                                                 (format t "Damage inc criteria ~E~%" damage-inc)
                                                 (when (> damage-inc max-damage-inc)
                                                   (cl-mpm:sim-format sim t "Damage criteria failed~%")
                                                   (funcall post-iter-step iv (cl-mpm::sim-stats-energy sim) (cl-mpm::sim-stats-oobf sim))
                                                   (error (make-instance 'non-convergence-error
                                                                         :text "Damage criteria exeeded"
                                                                         :ke-norm 0d0
                                                                         :oobf-norm 0d0))
                                                   ;; (save-vtks-dr-step sim output-dir step i)
                                                   ))
                                               (cl-mpm:sim-format sim t "Def crit ~E~%" (compute-max-deformation sim))
                                               (setf damage-prev damage))
                                      (when save-update
                                        (incf iv)
                                        (funcall post-iter-step iv (cl-mpm::sim-stats-energy sim) (cl-mpm::sim-stats-oobf sim))))
                                    (when t
                                      (dotimes (i 2)
                                        (cl-mpm:update-sim sim))
                                      (cl-mpm::update-dynamic-stats sim)))
                                  ;; No damage evolution -> instantly satisfy dconv
                                  (setf dconv 0d0)))
                            ;; (setf additional-conv (convergence-check sim))
                            ))
                 (setf additional-conv (convergence-check sim)))))
    (when (>= dconv damage-crit)
      (cl-mpm:sim-format sim t "Failed to converge damage during stagger~%")
      (error (make-instance 'non-convergence-error
                            :text "Failed to converge damage during stagger"
                            :ke-norm 0d0
                            :oobf-norm 0d0)))))

(declaim (notinline step-quasi-time))
(defun step-quasi-time (sim
                        global-step
                        &key (dt-scale 1d0)
                          (substeps 50)
                          (total-steps 0)
                          (damping 1d0)
                          (sub-conv-steps 50)
                          (conv-criteria 1d-3)
                          (conv-criteria-damage 1d-3)
                          (output-dir "./output/")
                          (save-vtk-dr t)
                          (enable-damage t)
                          (enable-plastic t)
                          (max-damage-inc 0.6d0)
                          (true-stagger nil)
                          (plotter (lambda (sim))))
  (let ((total-i 0))
    (handler-case
        (progn
          (let* ((damage-prev (get-damage sim))
                 (damage damage-prev)
                 (oobf-crit   conv-criteria)
                 (energy-crit
                   1d0
                   ;conv-criteria
                              )
                 (damage-crit conv-criteria-damage)
                 (dconv damage-crit)
                 (inertia 0d0)
                 (intertia-crit 1d-3)
                 (stagger-iters 0)
                 )
            (reset-mp-velocity sim)
            (set-mp-plastic-damage sim :enable-damage enable-damage :enable-plastic enable-plastic)
            (setf (cl-mpm:sim-enable-damage sim) nil)
            ;; (setf (cl-mpm:sim-enable-damage sim) enable-damage)
            (let ((alt-conv-crit nil))
              (loop for ac from 0 to 10
                    while (not alt-conv-crit)
                    do
                       (progn
                         (loop for stagger-i from 0 to 100
                               while (or (>= dconv damage-crit)
                                         (>= (cl-mpm::sim-stats-oobf sim) oobf-crit))
                               do
                                  (progn
                                    (when (> stagger-i 1)
                                      (setf true-stagger nil))
                                    (cl-mpm/dynamic-relaxation:converge-quasi-static
                                     sim
                                     :oobf-crit oobf-crit
                                     :energy-crit energy-crit
                                     :dt-scale dt-scale
                                     :substeps substeps
                                     :conv-steps sub-conv-steps
                                     :damping-factor damping
                                     :post-iter-step
                                     (lambda (i e o)
                                       (funcall plotter sim)
                                       (incf total-i)
                                       (when save-vtk-dr
                                         (when (= (mod i 1) 0)
                                           (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_step_~5,'0d_~5,'0d_~5,'0d.vtk" global-step *trial-iter* total-i)) sim)
                                           (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_step_nodes_~5,'0d_~5,'0d_~5,'0d.vtk" global-step *trial-iter* total-i)) sim)
                                           (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_step_cells_~5,'0d_~5,'0d_~5,'0d.vtk" global-step *trial-iter* total-i)) sim)
                                           ))
                                       (cl-mpm:sim-format sim t "Def crit ~E~%" (compute-max-deformation sim))
                                       (let ((max-def (compute-max-deformation sim)))
                                         (when (> max-def 10d0)
                                           (cl-mpm:sim-format sim t "Deformation gradient criteria exceeded~%")
                                           (error (make-instance 'non-convergence-error
                                                                 :text "Deformation gradient J exceeded"
                                                                 :ke-norm 0d0
                                                                 :oobf-norm 0d0)))
                                         (let ((true-intertia (true-intertial-criteria sim (sim-dt-loadstep sim))))
                                           (cl-mpm:sim-format sim t "True intertia ~E~%" true-intertia)
                                           (save-conv-step sim output-dir *total-iter* global-step
                                                           0d0
                                                           o
                                                           ;; true-intertia
                                                           max-def
                                                           )
                                           (setf inertia true-intertia)
                                           (when (sim-inertia-criteria sim)
                                               (when (> true-intertia (sim-inertia-criteria sim))
                                                 (cl-mpm:sim-format sim t "Inertia criteria exceeded~%")
                                                 (error (make-instance 'error-inertia-criteria
                                                                       :text "True inertia exceeded"
                                                                       :inertia-norm true-intertia))))))
                                       (unless true-stagger
                                         (let ((damage-inc (damage-increment-criteria sim)))
                                           (cl-mpm:sim-format sim t "Damage ~E - prev damage ~E - inc ~E~%" damage damage-prev damage-inc)
                                           (when (> damage-inc max-damage-inc)
                                             (cl-mpm:sim-format sim t "Damage criteria failed ~E~%" damage-inc)
                                             (error (make-instance 'error-damage-criteria
                                                                   :text "Damage criteria exeeded"
                                                                   :max-damage-inc 0d0)))))
                                       ;; (save-conv-step sim output-dir *total-iter* global-step 0d0 o 0d0)
                                       (incf *total-iter* substeps)))

                                    (let ((fast-trial-conv oobf-crit)
                                          (damage-iter t))
                                      (unless (typep sim 'cl-mpm/damage::mpm-sim-damage)
                                        (setf dconv 0d0))
                                      (when (typep sim 'cl-mpm/damage::mpm-sim-damage)
                                        ;; (loop for k from 0 to 10
                                        ;;       while (and
                                        ;;              (<= fast-trial-conv (sqrt oobf-crit))
                                        ;;              ;damage-iter
                                        ;;              )
                                        ;;       do)
                                        (loop for d from 0 to 100
                                              while (and
                                                     ;; (<= fast-trial-conv (sqrt oobf-crit))
                                                     damage-iter)
                                              do
                                                 (setf (cl-mpm:sim-enable-damage sim) t)
                                                 (if (<= d 5)
                                                     (cl-mpm/damage::calculate-damage sim (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim))
                                                     (dotimes (i 5)
                                                       (cl-mpm/damage::calculate-damage sim (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim))))
                                                 (when true-stagger
                                                   (setf (cl-mpm:sim-enable-damage sim) nil))
                                                 (setf damage (get-damage sim))
                                                 (setf dconv (compute-damage-delta sim))
                                                 (setf damage-prev damage)
                                                 (when (< dconv damage-crit)
                                                   (setf damage-iter nil))
                                                 (cl-mpm:sim-format sim t "step ~D/~D - d-conv ~E - ~E~%" stagger-i d dconv fast-trial-conv)
                                                 (let ((damage-inc (damage-increment-criteria sim)
                                                                   ;; (compute-max-damage-energy-crit sim)
                                                                   ))
                                                   (cl-mpm:sim-format sim t "Damage ~E - prev damage ~E - inc ~E~%" damage damage-prev damage-inc)
                                                   ;; (cl-mpm:sim-format sim t "Damage energy criterion ~E~%" (compute-max-damage-energy-crit sim))
                                                   (when (> damage-inc max-damage-inc)
                                                     (cl-mpm:sim-format sim t "Damage criteria failed ~E~%" damage-inc)
                                                     (when save-vtk-dr
                                                       (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_step_~5,'0d_~5,'0d_~5,'0d.vtk" global-step *trial-iter* total-i)) sim)
                                                       (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_step_nodes_~5,'0d_~5,'0d_~5,'0d.vtk" global-step *trial-iter* total-i)) sim)
                                                       (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_step_cells_~5,'0d_~5,'0d_~5,'0d.vtk" global-step *trial-iter* total-i)) sim))
                                                     (error (make-instance 'error-damage-criteria
                                                                           :text "Damage criteria exeeded"
                                                                           :max-damage-inc 0d0))))
                                                 ;; (when damage-iter
                                                 ;;   (dotimes (i 2)
                                                 ;;     (cl-mpm:update-sim sim))
                                                 ;;   (setf fast-trial-conv (cl-mpm::sim-stats-oobf sim))
                                                 ;;   (cl-mpm:sim-format sim t "fast trial ~E~%" fast-trial-conv))

                                                 (save-conv-step sim output-dir *total-iter* global-step
                                                                 0d0
                                                                 fast-trial-conv
                                                                 0d0
                                                                 )
                                                 (incf *total-iter*)
                                                 ;; (save-conv-step sim output-dir *total-iter* global-step
                                                 ;;                 0d0
                                                 ;;                 o
                                                 ;;                 0d0
                                                 ;;                 )

                                                 (incf total-i))
                                        (when t
                                          (dotimes (i 2)
                                            (cl-mpm:update-sim sim))
                                          (cl-mpm::update-dynamic-stats sim)
                                          (setf fast-trial-conv (cl-mpm::sim-stats-oobf sim))
                                          (cl-mpm:sim-format sim t "fast trial ~E~%" fast-trial-conv))
                           ))

                       (setf damage-prev damage)
                       (when save-vtk-dr
                         (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_step_~5,'0d_~5,'0d_~5,'0d.vtk" global-step *trial-iter* total-i)) sim)
                         (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_step_nodes_~5,'0d_~5,'0d_~5,'0d.vtk" global-step *trial-iter* total-i)) sim)
                         (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_step_cells_~5,'0d_~5,'0d_~5,'0d.vtk" global-step *trial-iter* total-i)) sim)
                         )
                       (incf stagger-iters)
                       ;; (when (> inertia intertia-crit)
                       ;;   (error (make-instance 'non-convergence-error
                       ;;                         :text "Quasi-time inertia was too large"
                       ;;                         :ke-norm inertia
                       ;;                         :oobf-norm oobf-crit)))
                       ))
                         (setf alt-conv-crit (convergence-check sim)))))
            (when (or (> (cl-mpm::sim-stats-oobf sim) oobf-crit)
                      (> dconv damage-crit))
              (cl-mpm:sim-format sim t "Staggered solve didn't converge ~E ~E~%" dconv (cl-mpm::sim-stats-oobf sim))
              (error (make-instance 'non-convergence-error
                                    :text "Staggered solve didn't converge ~E ~E"
                                    :ke-norm  dconv
                                    :oobf-norm  (cl-mpm::sim-stats-oobf sim))))

            (when save-vtk-dr
                (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_step_~5,'0d_~5,'0d_~5,'0d.vtk" global-step *trial-iter* total-i)) sim)
              (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_step_nodes_~5,'0d_~5,'0d_~5,'0d.vtk" global-step *trial-iter* total-i)) sim))
            (cl-mpm::finalise-loadstep sim)
            (save-timestep sim output-dir global-step :QUASI-STATIC)
            (values t stagger-iters)))
      (cl-mpm/errors:error-simulation (c)
        (princ c)
        (cl-mpm::reset-loadstep sim)
        (values nil 0))))
  )
(declaim (notinline step-real-time))
(defun step-real-time (sim
                       global-step
                       &key
                         (target-time 1d0)
                         (step-time 100d0)
                         (plotter (lambda (sim)))
                         (dt-scale 0.5)
                         (output-dir "./output/")
                         (max-steps 1000)
                         (damping 1d-4)
                         (damping-0 nil)
                         (enable-damage t)
                         (criteria 1d-3)
                         (enable-plastic t)
                         (enable-mass-scaling t)
                         (mass-scaler 1d1))

  (let ((state :dynamic))
    (setf (cl-mpm:sim-mass-scale sim) 1d0)
    (when enable-mass-scaling
        (setf
         state :accelerate
         (cl-mpm:sim-mass-scale sim) mass-scaler))
    (setf (cl-mpm:sim-dt sim) (* dt-scale (cl-mpm/setup:estimate-elastic-dt sim)))
    (setf (cl-mpm:sim-damping-factor sim) (* damping
                                             (if damping-0
                                                 damping-0
                                                 (cl-mpm/setup:estimate-critical-damping sim))))
    (set-mp-plastic-damage sim :enable-damage enable-damage :enable-plastic enable-plastic)
    (cl-mpm::update-stiffness-mps sim)
    (cl-mpm::reset-grid (cl-mpm:sim-mesh sim))
    (reset-mp-velocity sim)
    (setf (cl-mpm:sim-enable-damage sim) enable-damage)
    (let* ((e-crit    (* 0.5d0 criteria))
           (oobf-crit (* 0.5d0 criteria))
           (energy e-crit)
           (oobf oobf-crit)
           (work 0d0)
           (intertial-passed t)
           (dt-0 (* dt-scale (cl-mpm/setup:estimate-elastic-dt sim)))
           (substeps (max 1 (round target-time (cl-mpm:sim-dt sim)))))
      (cl-mpm:sim-format sim t "Substeps ~D~%" substeps)
      (cl-mpm:sim-format sim t "E crit ~E - OOBF crit ~E~%" e-crit oobf-crit)
      (time (loop for step from 0 to max-steps
                  while (and (cl-mpm::sim-run-sim sim)
                             (or (>= energy e-crit)
                                 (>= oobf oobf-crit)
                                 (not intertial-passed)
                                 (< step (/ step-time target-time))))
                  do
                     (let ((substeps (max 1 (round target-time (cl-mpm:sim-dt sim)))))
                       (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_real_~5,'0d_~5,'0d.vtk" global-step step)) sim)
                       (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_real_nodes_~5,'0d_~5,'0d.vtk" global-step step)) sim)
                       (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_real_cells_~5,'0d_~5,'0d.vtk" global-step step)) sim)
                       (setf energy 0d0)
                       (setf oobf 0d0)
                       (setf work 0d0)
                       (cl-mpm:sim-format sim t "Real time step ~d - substeps ~d - time ~E - dt ~E~%" step substeps target-time (cl-mpm:sim-dt sim))
                       (time
                        (dotimes (i substeps)
                          (cl-mpm::update-sim sim)
                          (setf (cl-mpm:sim-dt sim) (* dt-scale (cl-mpm::calculate-min-dt sim)))
                          (incf oobf (estimate-static-oobf sim))
                          (incf energy (cl-mpm::sim-stats-energy sim))
                          (incf work (estimate-strain-energy sim))
                          ;; (incf work (cl-mpm::sim-stats-power sim))
                          ))

                       (setf
                        energy (/ energy substeps)
                        oobf (/ oobf substeps)
                        work (/ work substeps)
                        )
                       (if (= work 0d0)
                           (setf energy 0d0)
                           (setf energy (abs (/ energy work))))

                       (let* ((hist 1d0)
                              (hist-power 0.5d0)
                              (hist-energy (* hist (expt e-crit hist-power)))
                              (hist-oobf (* hist (expt e-crit hist-power))))
                         (when (or (> energy hist-energy)
                                   (> oobf hist-oobf))
                           (cl-mpm:sim-format sim t "Inertia passed~%")
                           (setf intertial-passed t)))
                       (when enable-mass-scaling
                         (let* ((hist 2d0)
                                (hist-power 0.6d0)
                                (hist-energy (expt e-crit hist-power))
                                (hist-oobf (expt e-crit hist-power)))
                           (format t "Current state ~A - ~E ~E~%" state hist-energy hist-oobf)
                           (case state
                             (:accelerate
                              (when (or ;; (> energy (* hist-energy hist))
                                     (> oobf (* hist-oobf hist)))
                                (format t "Switched to dynamic timestep~%")
                                (setf
                                 state :dynamic
                                 (cl-mpm:sim-mass-scale sim) 1d0
                                 (cl-mpm:sim-dt sim) (/ (cl-mpm:sim-dt sim) (sqrt mass-scaler) ))))
                             (:dynamic
                              (when (and ;; (< energy (/ hist-energy hist))
                                     (< oobf (/ hist-oobf hist)))
                                (format t "Switched to accelerate timestep~%")
                                (reset-mp-velocity sim)
                                (setf
                                 state :accelerate
                                 (cl-mpm:sim-mass-scale sim) mass-scaler
                                 (cl-mpm:sim-dt sim) (* (cl-mpm:sim-dt sim) (sqrt mass-scaler))))))))
                       (cl-mpm:sim-format sim t "Residuals ~E ~E ~%" energy oobf)
                       (setf (cl-mpm::sim-stats-oobf sim) oobf)
                       (save-timestep sim output-dir global-step state)
                       (funcall plotter sim)
                       (swank.live:update-swank)))))))

(declaim (notinline run-multi-stage))
(defun run-multi-stage (sim
                        &key (output-dir "./output/")
                          (conv-load-steps 1)
                          (post-conv-step (lambda (sim)))
                          (plotter (lambda (sim)))
                          (dt-scale 1d0)
                          (damping-factor 1d0)
                          (explicit-dt-scale 0.9d0)
                          (explicit-damping-factor 1d-3)
                          (explicit-mass-scaling t)
                          (elastic-dt-margin 1000)
                          (elastic-dt nil)
                          (dt 1d0)
                          (steps nil)
                          (total-time 1d0)
                          (max-adaptive-steps 5)
                          (min-adaptive-steps -1)
                          (adaption-constant 2)
                          (conv-criteria 1d-3)
                          (explicit-conv-criteria nil)
                          (substeps 50)
                          (enable-damage t)
                          (enable-plastic t)
                          (save-vtk-dr t)
                          (save-vtk-loadstep t)
                          (max-damage-inc 0.6d0)
                          (min-damage-inc 0d0)
                          (setup-quasi-static (lambda (sim)))
                          (setup-dynamic (lambda (sim)))
                          (explicit-dynamic-solver 'cl-mpm::mpm-sim-usf))
  (let ((damping-0 (cl-mpm/setup::estimate-critical-damping sim)))
    (when steps
      (setf total-time (* dt steps)))
    (unless explicit-conv-criteria
      (setf explicit-conv-criteria conv-criteria))
    (uiop:ensure-all-directories-exist (list output-dir))
    (loop for f in (uiop:directory-files (uiop:merge-pathnames* output-dir)) do (uiop:delete-file-if-exists f))
    (cl-mpm/output::save-simulation-parameters (merge-pathnames output-dir "settings.json")
                                               sim
                                               (list :dt dt
                                                     :criteria-energy conv-criteria
                                                     :criteria-oobf conv-criteria
                                                     :criteria-hist 1d0))
    (save-timestep-preamble sim output-dir)
    (save-conv-preamble sim output-dir)
    (setf (cl-mpm::sim-dt sim) 0d0)
    (cl-mpm::update-sim sim)
    (format t "Estimated dt ~E~%" (* dt-scale (cl-mpm/setup:estimate-elastic-dt sim)))
    (format t "Computed dt ~E~%" (* dt-scale (cl-mpm::calculate-min-dt sim)))
    (setf (cl-mpm::sim-dt-scale sim) dt-scale)
    (setf (cl-mpm:sim-mass-scale sim) 1d0)
    (setf (cl-mpm:sim-damping-factor sim) 0d0)
    (setf (cl-mpm:sim-dt sim) (* dt-scale (cl-mpm::calculate-min-dt sim)))
    ;(setf (cl-mpm:sim-dt sim) (* dt-scale (cl-mpm/setup:estimate-elastic-dt sim)))
    (defparameter *total-iter* 0)
    (let ((quasi-static-solver (class-of sim))
          (load-steps conv-load-steps)
          (i 0))

      (reset-mp-velocity sim)
      (setf (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim) 0d0)
      (setf (cl-mpm::sim-velocity-algorithm sim) :QUASI-STATIC)
      (set-mp-plastic-damage sim :enable-plastic nil :enable-damage nil)
      (funcall setup-quasi-static sim)
      (loop for lstp from 1 to load-steps
            do
               (progn
                 (cl-mpm/dynamic-relaxation:converge-quasi-static
                  sim
                  :energy-crit 1d0;conv-criteria
                  :oobf-crit conv-criteria
                  :kinetic-damping nil
                  :dt-scale dt-scale
                  :conv-steps 1000
                  :substeps substeps
                  :damping-factor damping-factor
                  :post-iter-step
                  (lambda (j e o)
                    (incf i)
                    (save-conv-step sim output-dir *total-iter* 0 0d0 o e)
                    (incf *total-iter* substeps)
                    (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_conv_~5,'0d.vtk" i)) sim)
                    (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_conv_nodes__~5,'0d.vtk" i)) sim)
                    (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_conv_cells__~5,'0d.vtk" i)) sim)
                    ;; (cl-mpm/penalty::save-vtk-penalties (merge-pathnames output-dir (format nil "sim_conv_p_~5,'0d.vtk" i)) sim)
                    ))
                 (cl-mpm::finalise-loadstep sim)
                 ))
      (setf (cl-mpm::sim-time sim) 0d0)
      (cl-mpm/dynamic-relaxation::reset-mp-velocity sim)
      (reset-mp-velocity sim)
      (setf (cl-mpm::sim-velocity-algorithm sim) :QUASI-STATIC)

      (cl-mpm:iterate-over-mps
       (cl-mpm:sim-mps sim)
       (lambda (mp)
         (when (typep mp 'cl-mpm/particle::particle-damage)
           (setf (cl-mpm/particle::mp-enable-damage mp) enable-damage))
         (when (typep mp 'cl-mpm/particle::particle-plastic)
           (setf (cl-mpm/particle::mp-enable-plasticity mp) enable-plastic))))

      (funcall post-conv-step sim)
      (setf (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim) dt)
      (funcall setup-quasi-static sim)
      (let* ((current-adaptivity 0)
             (prev-steps-easy (list t t))
             (prev-step-iter 0)
             (elastic-dt (if elastic-dt elastic-dt (cl-mpm/setup::estimate-elastic-dt sim)))
             (max-steps (floor total-time (/ dt (expt adaption-constant max-adaptive-steps))))
             )
        (cl-mpm:sim-format sim t "Elastic dt ~E, override quasi-static at ~E~%" elastic-dt (* elastic-dt elastic-dt-margin))
        (loop for step from 1 to (+ 1 max-steps)
              while (and (cl-mpm::sim-run-sim sim)
                         (< (cl-mpm::sim-time sim) total-time))
              do
                 (let ((quasi-conv nil)
                       )
                   (cl-mpm:sim-format sim t "Quasi-timestep ~D, dt refine ~D - dt ~E~%" step current-adaptivity
                                      (/ dt (expt adaption-constant current-adaptivity)))
                   (defparameter *trial-iter* 0)
                   (let ((stagger-iters 0))
                     (loop for i from 0 to (- max-adaptive-steps min-adaptive-steps)
                           while (not quasi-conv)
                           do (progn
                                (let* ((adapted-dt (/ dt (expt adaption-constant current-adaptivity))))
                                  (setf (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim)
                                        (+ (min (- total-time (cl-mpm::sim-time sim)) adapted-dt) 1d-15))
                                  (cl-mpm:sim-format sim t "Trial step ~D, dt refine ~D - dt ~E ~%" i current-adaptivity (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim)))
                                (when (<= (sim-dt-loadstep sim) (* elastic-dt-margin elastic-dt))
                                  (cl-mpm:sim-format sim t "Quasi-time terminated as we got within ~E of the elastic dt~%" elastic-dt-margin)
                                  (setf quasi-conv nil)
                                  (loop-finish))

                                (setf *trial-iter* i)
                                (multiple-value-bind (conv inc-steps)
                                    (step-quasi-time sim step
                                                     :total-steps *total-iter*
                                                     :output-dir output-dir
                                                     :dt-scale dt-scale
                                                     :substeps substeps
                                                     :enable-damage enable-damage
                                                     :enable-plastic enable-plastic
                                                     :conv-criteria conv-criteria
                                                     :conv-criteria-damage conv-criteria
                                                     :max-damage-inc max-damage-inc
                                                     :save-vtk-dr save-vtk-dr)
                                  (setf quasi-conv conv
                                        stagger-iters inc-steps)
                                  (cl-mpm:sim-format sim t "Quasi-conv? ~A~%" quasi-conv)
                                  (unless quasi-conv
                                    (when (= current-adaptivity max-adaptive-steps)
                                      (cl-mpm:sim-format sim t "Quasi-time terminated as too many dt refinemets are required~%"))
                                    (when (<= (sim-dt-loadstep sim) (* elastic-dt-margin elastic-dt))
                                      (cl-mpm:sim-format sim t "Quasi-time terminated as we got within ~E of the elastic dt~%" elastic-dt-margin))
                                    (when (or (= current-adaptivity max-adaptive-steps)
                                              (<= (sim-dt-loadstep sim) (* elastic-dt-margin elastic-dt)))
                                      (loop-finish))
                                    (incf current-adaptivity)
                                    (when (> i 4)
                                      (cl-mpm:sim-format sim t "We've adaptive multiple sucessive times, double jump dt adaption~%")
                                      (incf i 1)))))
                           finally (progn
                                     (cl-mpm:sim-format sim t "Finished with ~D dt adaptions - stagger iters ~D - conv ~A~%" (- i 1) stagger-iters quasi-conv)
                                     (incf prev-step-iter)
                                     (when (> min-damage-inc 0d0)
                                       (format t "End of step max damage inc ~E~%" (damage-increment-criteria sim)))
                                     (if (and (= i 1)
                                              (if (> min-damage-inc 0d0)
                                                  (< (damage-increment-criteria sim) min-damage-inc)
                                                  (<= stagger-iters 3)))
                                         (progn
                                           (setf (nth (mod prev-step-iter (length prev-steps-easy)) prev-steps-easy) t)
                                           (cl-mpm:sim-format sim t "Potential adaption easy steps ~A~%" prev-steps-easy)
                                           (when (every #'identity prev-steps-easy)
                                             (setf current-adaptivity
                                                   (max min-adaptive-steps
                                                        (- current-adaptivity 1)))))
                                         (setf (nth (mod prev-step-iter 2) prev-steps-easy) nil)))))
                   (unless quasi-conv
                     ;;We've adapted down to a min
                     (cl-mpm:sim-format sim t "Start real-timestepping~%")
                     (let ((dt-loadstep (* 1d0 (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim))))
                       (cl-mpm/dynamic-relaxation::reset-mp-velocity sim)
                       (change-class sim explicit-dynamic-solver)
                       (setf (cl-mpm::sim-velocity-algorithm sim) :FLIP)
                       (funcall setup-dynamic sim)
                       (step-real-time sim step
                                       :output-dir output-dir
                                       :plotter plotter
                                       :dt-scale explicit-dt-scale
                                       :criteria explicit-conv-criteria
                                       :damping-0 damping-0
                                       :damping explicit-damping-factor
                                       :target-time (* 0.1d0 dt-loadstep)
                                       :step-time (* dt-loadstep adaption-constant)
                                       :enable-mass-scaling explicit-mass-scaling
                                       :enable-damage enable-damage
                                       :enable-plastic enable-plastic)
                       (change-class sim quasi-static-solver)
                       (cl-mpm:sim-format sim t "Finished real-timestepping~%")
                       (setf (cl-mpm::sim-velocity-algorithm sim) :QUASI-STATIC)
                       ;;De-refine our timestepping
                       (decf current-adaptivity)
                       (cl-mpm/dynamic-relaxation::reset-mp-velocity sim))
                     (funcall setup-quasi-static sim))

                   (funcall plotter sim)
                   ;; (plot sim)
                   ;; (vgplot:title (format nil "Step ~D" step))
                   (save-vtks sim output-dir step)
                   ;; (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_~5,'0d.vtk" step)) sim)
                   ;; (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_nodes_~5,'0d.vtk" step)) sim)
                   ;; (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_cells_~5,'0d.vtk" step)) sim)
                   (swank.live:update-swank)))))
    )
  (cl-mpm:sim-format sim t "Finished algorithm~%")
  )



;; (defun test-multi-step ()
;;   (setup :mps 2 :refine 0.5)
;;   (run-multi-stage
;;    :output-dir "./output/"
;;    :dt 0.5d0
;;    ;; :dt-scale (/ 0.8d0 (sqrt 1d0))
;;    ;; :load-steps 20
;;    )
;;   )


(defun save-test-vtks (sim &key (output-dir "./output/"))
  (cl-mpm/output:save-vtk (merge-pathnames "test.vtk" output-dir) sim)
  (cl-mpm/output:save-vtk-nodes (merge-pathnames "test_nodes_0.vtk" output-dir) sim)
  (cl-mpm/output:save-vtk-nodes (merge-pathnames "test_nodes_1.vtk" output-dir) sim)
  (cl-mpm/output:save-vtk-cells (merge-pathnames "test_cells.vtk" output-dir) sim)
  )






;; (defun converge-staggered (sim
;;                            criteria
;;                            damage-criteria
;;                            kinetic-damping
;;                            adaptive-damping
;;                            dt-scale
;;                            substeps
;;                            damping
;;                            enable-damage
;;                            enable-plasticity
;;                            step
;;                            output-dir
;;                            &key (save-vtk-dr nil)
;;                              (plotter (lambda (sim)))
;;                              )
;;   (let* ((damage-prev (get-damage sim))
;;          (damage-eval t)
;;          (damage damage-prev)
;;          (max-iter 1000)
;;          (dconv damage-criteria))
;;     (setf (cl-mpm::sim-enable-damage sim) nil)
;;     (cl-mpm/dynamic-relaxation:converge-quasi-static
;;      sim
;;      :oobf-crit criteria
;;      :energy-crit criteria
;;      :kinetic-damping kinetic-damping
;;      :damping-factor (if adaptive-damping damping nil)
;;      :dt-scale dt-scale
;;      :substeps substeps
;;      :conv-steps 1000
;;      :post-iter-step
;;      (lambda (i energy oobf)
;;        (incf *total-iter* substeps)
;;        (save-conv-step sim output-dir *total-iter* step 0d0 oobf energy)))
;;     (loop for i from 0 to max-iter
;;           while (>= dconv damage-criteria)
;;           do (progn
;;                (when (typep sim 'cl-mpm/damage::mpm-sim-damage)
;;                  (setf (cl-mpm::sim-enable-damage sim) damage-eval)
;;                  (cl-mpm/damage::calculate-damage sim (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim))
;;                  (setf damage (get-damage sim)))
;;                (if (= damage damage-prev)
;;                    (setf dconv 0d0)
;;                    (when (> damage damage-prev)
;;                      (setf dconv (if (> damage-prev 0d0) (/ (- damage damage-prev) damage-prev) sb-ext:double-float-positive-infinity))))
;;                (setf damage-prev damage)
;;                (setf (cl-mpm::sim-enable-damage sim) nil)
;;                (cl-mpm/dynamic-relaxation:converge-quasi-static
;;                 sim
;;                 :oobf-crit criteria
;;                 :energy-crit criteria
;;                 :kinetic-damping kinetic-damping
;;                 :damping-factor (if adaptive-damping damping nil)
;;                 :dt-scale dt-scale
;;                 :substeps substeps
;;                 :conv-steps 1000
;;                 :post-iter-step
;;                 (lambda (i energy oobf)
;;                   (incf *total-iter* substeps)
;;                   (save-conv-step sim output-dir *total-iter* step 0d0 oobf energy))
;;                 )
;;                (funcall plotter sim)
;;                (when save-vtk-dr
;;                  (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_~5,'0d_~5,'0d.vtk" step i)) sim)
;;                  (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_nodes_~5,'0d_~5,'0d.vtk" step i)) sim)
;;                  (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_cells_~5,'0d_~5,'0d.vtk" step i)) sim))

;;                ))))


(defun run-load-control (sim
                         &key (output-dir "./output/")
                           (loading-function nil)
                           (load-steps 10)
                           (initial-load 0d0)
                           (substeps 50)
                           (damping 1d0)
                           (kinetic-damping nil)
                           (criteria 1d-3)
                           (conv-steps 50)
                           (post-conv-step (lambda (sim)))
                           (post-iter-step (lambda (sub-iter oobf energy)))
                           (pre-step (lambda ()))
                           (plotter (lambda (sim)))
                           (enable-damage t)
                           (enable-plastic t)
                           (save-vtk-dr t)
                           (save-vtk-loadstep t)
                           (dt-scale 1d0))
  (uiop:ensure-all-directories-exist (list output-dir))
  (loop for f in (uiop:directory-files (uiop:merge-pathnames* output-dir)) do (uiop:delete-file-if-exists f))
  (save-conv-preamble sim output-dir)
  (cl-mpm/output::save-simulation-parameters (merge-pathnames output-dir "settings.json") sim)
  (funcall pre-step)
  ;; (save-conv-step sim output-dir 0 0 0d0 0d0)
  (defparameter *total-iter* 0)
  (save-vtks sim output-dir 0)
  (with-accessors ((mps cl-mpm:sim-mps))
      sim
    (let* ((load (cl-mpm:sim-gravity sim)))
      (unless loading-function
        (setf loading-function (lambda (percent)
                                 (cl-mpm:sim-format sim t "Loading factor ~E~%" percent)
                                 (setf (cl-mpm:sim-gravity sim)
                                       (* load percent)))))
      (setf (cl-mpm::sim-dt-scale sim) dt-scale)
      (let ((t0 (get-internal-real-time))
            (tunits internal-time-units-per-second))
        (loop for step from 1 to load-steps
              while (cl-mpm::sim-run-sim sim)
              do
                 (progn
                   (cl-mpm:sim-format sim t "Load step ~D~%" step)
                   (defparameter *ke-last* 0d0)
                   ;; (pprint step)
                   (let* ((percent (/ (float step) load-steps)))
                     ;; (declare (double-float percent initial-load))
                     (funcall loading-function (+ initial-load (* (- 1d0 initial-load) percent))))
                   (let ((iter-conv-steps 0)
                         (i 0))
                     ;; (when damping
                     ;;   (setf (cl-mpm::sim-damping-factor sim)
                     ;;         (* damping (cl-mpm/setup:estimate-critical-damping sim))))
                     (setf (cl-mpm/dynamic-relaxation::sim-damping-scale sim) damping)
                     (time
                      (;;cl-mpm/dynamic-relaxation:converge-quasi-static
                       generalised-staggered-solve
                       sim
                       :crit criteria
                       :enable-damage enable-damage
                       :enable-plastic enable-plastic
                       :dt-scale dt-scale
                       :substeps substeps
                       :damping damping
                       :sub-conv-steps conv-steps
                       :post-iter-step
                       (lambda (i energy oobf)
                         (funcall post-iter-step i energy oobf)
                         (setf iter-conv-steps (* substeps i))
                         (cl-mpm:sim-format sim t "Substep ~D~%" i)
                         (let ((i (+ 0 i)))
                           (when save-vtk-dr
                             (save-vtks-dr-step sim output-dir step i)))
                         (incf *total-iter* substeps)
                         (save-conv-step sim output-dir *total-iter* step 0d0 oobf energy)
                         (funcall plotter sim))))))

                 (cl-mpm::finalise-loadstep sim)
                 (funcall post-conv-step sim)
                 (save-vtks sim output-dir step)
                 (funcall plotter sim)
                 (swank.live:update-swank)
              )))))

;; (defun run-strength-reduction (sim
;;                                &key (output-dir "./output/")
;;                                  (loading-function nil)
;;                                  (load-steps 10)
;;                                  (substeps 50)
;;                                  (damping 1d-1)
;;                                  (kinetic-damping t)
;;                                  (adaptive-damping t)
;;                                  (criteria 1d-3)
;;                                  (post-conv-step (lambda (sim)))
;;                                  (plotter (lambda (sim)))
;;                                  (save-vtk-dr t)
;;                                  (save-vtk-loadstep t)
;;                                  (dt-scale 0.5d0))
;;   (uiop:ensure-all-directories-exist (list output-dir))
;;   (loop for f in (uiop:directory-files (uiop:merge-pathnames* output-dir)) do (uiop:delete-file-if-exists f))
;;   (save-conv-preamble sim output-dir)
;;   ;; (save-conv-step sim output-dir 0 0 0d0 0d0)
;;   (with-accessors ((mps cl-mpm:sim-mps))
;;       sim
;;     (let* ((load (cl-mpm/particle::mp-gravity (aref (cl-mpm:sim-mps sim) 0)))
;;            (total-iter 0))
;;       (unless loading-function
;;         (setf loading-function (lambda (percent)
;;                                  (cl-mpm:sim-format sim t "Loading factor ~E~%" percent)
;;                                  (cl-mpm:iterate-over-mps
;;                                   mps
;;                                   (lambda (mp)
;;                                     (setf (cl-mpm/particle:mp-gravity mp) (* load percent)))))))
;;       (setf (cl-mpm::sim-dt-scale sim) dt-scale)
;;       (let ((t0 (get-internal-real-time))
;;             (tunits internal-time-units-per-second)
;;             )
;;         (loop for step from 1 to load-steps
;;               while (cl-mpm::sim-run-sim sim)
;;               do
;;                  (progn
;;                    (cl-mpm:sim-format sim t "Load step ~D~%" step)
;;                    (defparameter *ke-last* 0d0)
;;                    ;; (pprint step)
;;                    (funcall loading-function (/ (float step) load-steps))
;;                    (let ((conv-steps 0)
;;                          (i 0))
;;                      (when damping
;;                        (setf (cl-mpm::sim-damping-factor sim)
;;                              (* damping (cl-mpm/setup:estimate-critical-damping sim))))
;;                      (time
;;                       (cl-mpm/dynamic-relaxation:converge-quasi-static
;;                        sim
;;                        :oobf-crit criteria
;;                        :energy-crit criteria
;;                        :kinetic-damping kinetic-damping
;;                        :damping-factor (if adaptive-damping damping nil)
;;                        :dt-scale dt-scale
;;                        :substeps substeps
;;                        :conv-steps 1000
;;                        :post-iter-step
;;                        (lambda (i energy oobf)
;;                          (setf conv-steps (* substeps i))
;;                          (vgplot:title (format nil "Step ~D - substep ~D - KE ~,3E - OOBF ~,3E - damp ~,3E"  step (* i substeps) energy oobf
;;                                                (/ (cl-mpm::sim-damping-factor sim)
;;                                                   (cl-mpm/setup:estimate-critical-damping sim))))
;;                          (cl-mpm:sim-format sim t "Substep ~D~%" i)
;;                          (let ((i (+ 0 i)))
;;                            (when save-vtk-dr
;;                              (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_~5,'0d_~5,'0d.vtk" step i)) sim)
;;                              (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_nodes_~5,'0d_~5,'0d.vtk" step i)) sim)
;;                              (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_cells_~5,'0d_~5,'0d.vtk" step i)) sim)))
;;                          (incf total-iter substeps)
;;                          (save-conv-step sim output-dir total-iter step (/ (- (get-internal-real-time) t0) tunits) oobf energy)
;;                          (setf t0 (get-internal-real-time))
;;                          (funcall plotter sim)
;;                          )))
;;                      (vgplot:title (format nil "Step ~D - ~D" step conv-steps))
;;                      ))
;;                  (funcall post-conv-step sim)
;;                  (when save-vtk-loadstep
;;                    (cl-mpm/output::save-vtk-nodes (merge-pathnames output-dir (format nil "sim_nodes_~5,'0d.vtk" step)) sim)
;;                    (cl-mpm/output::save-vtk-cells (merge-pathnames output-dir (format nil "sim_cells_~5,'0d.vtk" step)) sim))
;;                  (cl-mpm::finalise-loadstep sim)
;;                  (funcall plotter sim)
;;                  (vgplot:print-plot (merge-pathnames (format nil "outframes/frame_~5,'0d.png" step))
;;                                     :terminal "png size 1920,1080"
;;                                     )
;;                  (when save-vtk-loadstep
;;                    (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_~5,'0d.vtk" step)) sim)
;;                    (cl-mpm/penalty:save-vtk-penalties (uiop:merge-pathnames* output-dir (format nil "sim_p_~5,'0d.vtk" step)) sim ))
;;                  (sleep 0.1d0)
;;                  (swank.live:update-swank)
;;               )))))

(defun run-quasi-time (sim
                       &key (output-dir "./output/")
                         (post-conv-step (lambda (sim)))
                         (post-load-step (lambda (sim)))
                         (plotter (lambda (sim)))
                         (dt-scale 0.5d0)
                         (dt 1d0)
                         (total-time 1d0)
                         (substeps 50)
                         (enable-damage t)
                         (enable-plastic t)
                         (max-adaptive-steps 5)
                         (min-adaptive-steps -1)
                         (save-vtk-loadstep t)
                         (save-vtk-conv t)
                         (save-vtk-dr t)
                         (damping 1d0)
                         (max-damage-inc 0.5d0)
                         (elastic-solver 'mpm-sim-dr-ul)
                         (conv-criteria 1d-3))
  (let ((result t))
    (uiop:ensure-all-directories-exist (list output-dir))
    (loop for f in (uiop:directory-files (uiop:merge-pathnames* output-dir)) do (uiop:delete-file-if-exists f))
    (cl-mpm/output::save-simulation-parameters (merge-pathnames output-dir "settings.json")
                                               sim
                                               (list :dt dt
                                                     :criteria-energy conv-criteria
                                                     :criteria-oobf conv-criteria
                                                     :criteria-hist 1d0
                                                     ))
    (save-timestep-preamble sim output-dir)
    (save-conv-preamble sim output-dir)
    (setf (cl-mpm::sim-dt-scale sim) dt-scale)
    (setf (cl-mpm:sim-mass-scale sim) 1d0)
    (setf (cl-mpm:sim-dt sim) (* dt-scale (cl-mpm/setup:estimate-elastic-dt sim)))
    (setf (cl-mpm:sim-damping-factor sim) 0d0)
    (setf (cl-mpm:sim-enable-damage sim) nil)
    (defparameter *total-iter* 0)
    (let (;(substeps 50)
          (vel-algo (cl-mpm::sim-velocity-algorithm sim))
          (sim-type (class-of sim)))
      (when (not (subtypep (type-of sim) elastic-solver))
        (format t "Changed class from ~A to ~A~%" (type-of sim) elastic-solver)
        (change-class sim elastic-solver))
      (setf (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim) 0d0)
      (setf (cl-mpm::sim-velocity-algorithm sim) :QUASI-STATIC)
      (set-mp-plastic-damage sim :enable-plastic nil :enable-damage nil)
      ;; find initial quasi-static formation
      (cl-mpm/dynamic-relaxation:converge-quasi-static
       sim
       :energy-crit conv-criteria
       :oobf-crit conv-criteria
       :kinetic-damping nil
       :dt-scale dt-scale
       :conv-steps 10000
       :substeps substeps
       :damping-factor damping
       :post-iter-step
       (lambda (i e o)
         (save-conv-step sim output-dir *total-iter* 0 0d0 o e)
         (incf *total-iter* substeps)
         (when save-vtk-conv
           (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_conv_~5,'0d.vtk" i)) sim)
           (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_conv_nodes__~5,'0d.vtk" i)) sim)
           (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_conv_cells__~5,'0d.vtk" i)) sim))
         (funcall plotter sim)
         ))
      (cl-mpm::finalise-loadstep sim)
      (cl-mpm::reset-grid (cl-mpm:sim-mesh sim))
      (cl-mpm:sim-format sim t "Reset grid, finalise loadstep~%")
      (setf (cl-mpm::sim-time sim) 0d0)
      (cl-mpm/dynamic-relaxation::reset-mp-velocity sim)
      (setf (cl-mpm::sim-velocity-algorithm sim) vel-algo)
      (cl-mpm:sim-format sim t "Set plastic-damage~%")
      (set-mp-plastic-damage sim :enable-plastic enable-plastic :enable-damage enable-damage)
      (cl-mpm:sim-format sim t "Change class~%")
      (change-class sim sim-type)
      (cl-mpm:sim-format sim t "Call post-conv~%")
      (funcall post-conv-step sim)
      (cl-mpm:sim-format sim t "Start iter~%")
      (setf (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim) dt)
      (let* ((current-adaptivity 0)
             (max-steps (floor total-time (/ dt (expt 2 max-adaptive-steps))))
             (sim-time 0d0))
        (loop for step from 1 to (+ 1 max-steps)
              while (and (cl-mpm::sim-run-sim sim)
                         (< sim-time total-time))
              do
                 (let ((quasi-conv nil))
                   (cl-mpm:sim-format sim t "quasi-timestep ~d - time ~E, dt refine ~d~%" step sim-time current-adaptivity)
                   (defparameter *trial-iter* 0)
                   (let ((stagger-iters 0))
                     (loop for i from 0 to max-adaptive-steps
                           while (not quasi-conv)
                           do (progn
                                (let* ((adapted-dt (/ dt (expt 2 current-adaptivity))))
                                  (setf (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim)
                                        (+ (min (- total-time sim-time) adapted-dt) 1d-15))
                                  (cl-mpm:sim-format sim t "trial step ~d, dt refine ~d - dt ~E~%" i current-adaptivity (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim)))
                                (setf *trial-iter* i)
                                (multiple-value-bind (conv inc-steps)
                                    (step-quasi-time sim step
                                                     :total-steps *total-iter*
                                                     :plotter plotter
                                                     :output-dir output-dir
                                                     :dt-scale dt-scale
                                                     :substeps substeps
                                                     :enable-damage enable-damage
                                                     :damping damping
                                                     :save-vtk-dr save-vtk-dr
                                                     :conv-criteria conv-criteria
                                                     :conv-criteria-damage conv-criteria
                                                     :max-damage-inc max-damage-inc
                                                     :enable-plastic enable-plastic)
                                  (setf quasi-conv conv
                                        stagger-iters inc-steps)
                                  (unless quasi-conv
                                    (if (= current-adaptivity max-adaptive-steps)
                                        (progn
                                          (cl-mpm::reset-node-displacement sim)
                                          (cl-mpm:sim-format sim t "quasi-time terminated as too many dt refinemets are required~%")
                                          (loop-finish))
                                        (incf current-adaptivity)))))
                           finally (progn
                                     (cl-mpm:sim-format sim t "finished with ~d dt adaptions - stagger iters ~d~%" (- i 1) stagger-iters)
                                     (when (and (= i 1) (< stagger-iters 4))
                                       (setf current-adaptivity
                                             (max min-adaptive-steps
                                                  (- current-adaptivity 1)))))))
                   (unless quasi-conv
                     (setf (cl-mpm::sim-run-sim sim) nil
                           result nil))
                   (incf sim-time (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim))
                   (funcall plotter sim)
                   (funcall post-load-step sim)

                   (when save-vtk-loadstep
                     (save-vtks sim output-dir step))
                   ;; (when save-vtk-loadstep
                   ;;   (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_~5,'0d.vtk" step)) sim)
                   ;;   (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_nodes_~5,'0d.vtk" step)) sim)
                   ;;   (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_cells_~5,'0d.vtk" step)) sim))
                   (swank.live:update-swank)))))
    result))


(defun reset-mp-velocity (sim)
  (cl-mpm:iterate-over-mps
   (cl-mpm:sim-mps sim)
   (lambda (mp)
     (cl-mpm/fastmaths::fast-zero (cl-mpm/particle::mp-velocity-gradient mp))
     (cl-mpm/fastmaths:fast-zero (cl-mpm/particle::mp-velocity mp)))))

(defun reset-nominal-displacement (sim)
  (cl-mpm:iterate-over-mps
   (cl-mpm:sim-mps sim)
   (lambda (mp)
     (cl-mpm/fastmaths:fast-zero (cl-mpm/particle::mp-displacement mp)))))

(defun elastic-static-solution (sim &key (crit 1d-3)
                                      (elastic-solver 'cl-mpm/dynamic-relaxation::mpm-sim-quasi-static)
                                      (substeps 10)
                                      (dt-scale 1d0)
                                      (post-iter-step
                                       (lambda (i e o)
                                         (cl-mpm:sim-format sim t "Static step ~D - ~E~%" i o))))
  "Take a sim, switch it to implicit quasi-static, disable elastic and plastic and converge switch the class back to the original then enable damage and plastic"
  (let ((vel-algo (cl-mpm::sim-velocity-algorithm sim))
        (sim-type (class-of sim)))
    (unless (subtypep (type-of sim) elastic-solver)
      (format t "Changed class from ~A to ~A~%" (type-of sim) elastic-solver)
      (change-class sim elastic-solver))
    (setf (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim) 0d0)
    (setf (cl-mpm::sim-velocity-algorithm sim) :QUASI-STATIC)
    (set-mp-plastic-damage sim :enable-damage nil :enable-plastic nil)
    ;; Find initial quasi-static formation
    (cl-mpm/dynamic-relaxation:converge-quasi-static
     sim
     :energy-crit crit
     :oobf-crit crit
     :kinetic-damping nil
     :dt-scale dt-scale
     :conv-steps 100
     :substeps substeps
     :damping-factor 1d0
     :post-iter-step
     post-iter-step
     )
    (cl-mpm::finalise-loadstep sim)
    (set-mp-plastic-damage sim :enable-damage t :enable-plastic t)
    (setf (cl-mpm::sim-time sim) 0d0)
    (cl-mpm/dynamic-relaxation::reset-mp-velocity sim)
    (setf (cl-mpm::sim-velocity-algorithm sim) vel-algo)
    (change-class sim sim-type)))

(defun run-adaptive-load-control (sim
                         &key (output-dir "./output/")
                           (loading-function nil)
                           (load-steps 10)
                           (initial-load 0d0)
                           (substeps 50)
                           (sub-conv-steps 50)
                           (damping 1d0)
                           (kinetic-damping nil)
                           (criteria 1d-3)
                           (post-conv-step (lambda (sim)))
                           (post-iter-step (lambda (sub-iter oobf energy)))
                           (pre-step (lambda ()))
                           (plotter (lambda (sim)))
                           (enable-damage t)
                           (enable-plastic t)
                           (save-vtk-dr t)
                           (true-stagger nil)
                           (save-vtk-loadstep t)
                           (max-adaptive-steps 5)
                           (min-adaptive-steps 0)
                           (adaption-constant 2)
                           (max-damage-inc 0.3d0)
                           (min-damage-inc 0d0)
                           (dt-scale 1d0))
  (uiop:ensure-all-directories-exist (list output-dir))
  (loop for f in (uiop:directory-files (uiop:merge-pathnames* output-dir)) do (uiop:delete-file-if-exists f))
  (save-conv-preamble sim output-dir)
  (cl-mpm/output::save-simulation-parameters (merge-pathnames output-dir "settings.json") sim)
  (funcall pre-step)
  ;; (save-conv-step sim output-dir 0 0 0d0 0d0)
  (setf lparallel:*debug-tasks-p* nil)
  (cl-mpm:iterate-over-mps (cl-mpm::sim-mps sim) (lambda (mp)))
  (defparameter *total-iter* 0)
  (with-accessors ((mps cl-mpm:sim-mps))
      sim
    (let* ((load (cl-mpm:sim-gravity sim))
           (finished t))
      (unless loading-function
        (setf loading-function (lambda (percent)
                                 (cl-mpm:sim-format sim t "Loading factor ~E~%" percent)
                                 (setf (cl-mpm:sim-gravity sim)
                                       (* load percent)))))
      (setf (cl-mpm::sim-dt-scale sim) dt-scale)
      (let* ((initial-load-step-size (/ (- 1d0 initial-load) load-steps))
             (prev-steps-easy (list t t))
             (prev-step-iter 0)
             (load-step-size initial-load-step-size)
             (current-load initial-load)
             (current-adaptivity 0))
        (loop for step from 1; to load-steps
              while (and (cl-mpm::sim-run-sim sim)
                         (< (+ 1d-15 current-load) 1d0))
              do
                 (progn
                   (cl-mpm:sim-format sim t "Load step ~D~%" step)
                   (defparameter *ke-last* 0d0)
                   (let ((conv-steps 0)
                         (i-total 0))
                     (flet ((trial-solve ()
                              (handler-case
                                  (progn
                                    (cl-mpm:sim-format sim t "Load applied ~E~%" (min 1d0 (+ current-load load-step-size)))
                                    (funcall loading-function (+ current-load load-step-size))
                                    (time
                                     (;cl-mpm/dynamic-relaxation:converge-quasi-static
                                      generalised-staggered-solve
                                      sim
                                      :crit criteria
                                      :damping damping
                                      :output-dir output-dir
                                      :dt-scale dt-scale
                                      :substeps substeps
                                      :sub-conv-steps sub-conv-steps
                                      :enable-damage enable-damage
                                      :enable-plastic enable-plastic
                                      :max-damage-inc max-damage-inc
                                      :true-stagger true-stagger
                                      :post-iter-step
                                      (lambda (i-g energy oobf)
                                        (incf i-total)
                                        (let ((i i-total))
                                          (funcall post-iter-step i energy oobf)
                                          (setf conv-steps (* substeps i))
                                          (cl-mpm:sim-format sim t "Substep ~D~%" i)
                                          (let ((i (+ 0 i)))
                                            (when save-vtk-dr
                                              (save-vtks-dr-step sim output-dir step i)))

                                          (incf *total-iter* substeps)
                                          (save-conv-step sim output-dir *total-iter* step 0d0 oobf energy)
                                          (funcall plotter sim)))))
                                    (cl-mpm:sim-format sim t "Generalised solve passed~%")
                                    t)
                                (cl-mpm/errors:error-simulation (c)
                                  (princ c)
                                  (cl-mpm::reset-loadstep sim)
                                  (values nil 0)
                                  )
                                ;; (error (c)
                                ;;   (cl-mpm:sim-format sim t "A non simulation error was thrown!")
                                ;;   (princ c)
                                ;;   (cl-mpm::reset-loadstep sim)
                                ;;   (cl-mpm::sim-run-sim sim) nil
                                ;;   (return-from run-adaptive-load-control)
                                ;;   (values nil 0))
                                )))
                       (let ((quasi-conv nil))
                         (loop for i from 0 to max-adaptive-steps
                               while (not quasi-conv)
                               do (progn
                                    (setf load-step-size
                                          (min (- 1d0 current-load)
                                               (* initial-load-step-size (expt adaption-constant (- current-adaptivity)))))
                                    (cl-mpm:sim-format sim t "Load step size ~E adapted by ~D~%" load-step-size current-adaptivity)
                                    (setf quasi-conv (trial-solve))
                                    (unless quasi-conv
                                      (cl-mpm:sim-format sim t "Failed conv, adapting~%" )
                                      (incf current-adaptivity))
                                    (if (or (= current-adaptivity max-adaptive-steps))
                                        (progn
                                          (loop-finish))))
                               finally (progn
                                         (cl-mpm:sim-format sim t "Finished with ~D adaptions- conv ~A~%" (- i 1) quasi-conv)
                                         (when (> min-damage-inc 0d0)
                                           (format t "Easy damage inc criteria ~E true ~E~%" min-damage-inc (damage-increment-criteria sim)))
                                         (when (and (= i 1)
                                                    (if (> min-damage-inc 0d0)
                                                        (< (damage-increment-criteria sim) min-damage-inc)
                                                        t))
                                           (setf (nth (mod prev-step-iter (length prev-steps-easy)) prev-steps-easy) t)
                                           (cl-mpm:sim-format sim t "Potential adaption easy steps ~A~%" prev-steps-easy)
                                           (when (every #'identity prev-steps-easy)
                                             (setf current-adaptivity
                                                   (max min-adaptive-steps
                                                        (- current-adaptivity 1)))))
                                         ))
                         (unless quasi-conv;(>= current-adaptivity max-adaptive-steps)
                           (cl-mpm:sim-format sim t "Solve failed completly~%" )
                           (setf (cl-mpm::sim-run-sim sim) nil
                                 finished nil))
                         ))))
                 (incf current-load load-step-size)
                 (funcall post-conv-step sim)
                 (cl-mpm::finalise-loadstep sim)
                 (save-vtks sim output-dir step)
                 (funcall plotter sim)
                 (swank.live:update-swank)))
      finished)))

(defun run-time (sim
                 &key (output-dir "./output/")
                   (post-conv-step (lambda (sim)))
                   (post-iter-step (lambda (sim)))
                   (plotter (lambda (sim)))
                   (dt-scale 0.5d0)
                   (dt 1d0)
                   (total-time 1d0)
                   (substeps 50)
                   (enable-damage t)
                   (enable-plastic t)
                   (mass-scale 1d0)
                   ;; (max-adaptive-steps 5)
                   ;; (min-adaptive-steps -1)
                   (save-vtk-dr t)
                   (save-vtk-loadstep t)
                   (damping 1d0)
                   (initial-quasi-static t)
                   (initial-lstps 1)
                   (elastic-solver 'mpm-sim-dr-ul)
                   (adaptive-mass-enabled nil)
                   (adaptive-mass-scale 1d0)
                   (adaptive-crit 1d-3)
                   (adaptive-hist 1d0)
                   (conv-criteria 1d-3))
  (let ((result t))
    (uiop:ensure-all-directories-exist (list output-dir))
    (loop for f in (uiop:directory-files (uiop:merge-pathnames* output-dir)) do (uiop:delete-file-if-exists f))
    (cl-mpm/output::save-simulation-parameters (merge-pathnames output-dir "settings.json")
                                               sim
                                               (list :dt dt
                                                     :criteria-energy conv-criteria
                                                     :criteria-oobf conv-criteria
                                                     :criteria-hist 1d0
                                                     ))
    (save-timestep-preamble sim output-dir)
    (save-conv-preamble sim output-dir)
    (defparameter *total-iter* 0)
    (when initial-quasi-static
      (cl-mpm:iterate-over-mps
       (cl-mpm:sim-mps sim)
       (lambda (mp)
         (when (typep mp 'cl-mpm/particle::particle-damage)
           (setf (cl-mpm/particle::mp-enable-damage mp) nil))
         (when (typep mp 'cl-mpm/particle::particle-plastic)
           (setf (cl-mpm/particle::mp-enable-plasticity mp) nil))))

      (setf (cl-mpm::sim-dt-scale sim) dt-scale)
      (setf (cl-mpm:sim-mass-scale sim) 1d0)

      (setf (cl-mpm:sim-enable-damage sim) nil)
      (let (;(substeps 50)
            (vel-algo (cl-mpm::sim-velocity-algorithm sim))
            (sim-type (class-of sim)))
        (change-class sim elastic-solver)
        (setf (cl-mpm/dynamic-relaxation::sim-dt-loadstep sim) 0d0)
        (setf (cl-mpm::sim-velocity-algorithm sim) :QUASI-STATIC)
        ;; find initial quasi-static formation
        (dotimes (i initial-lstps)
          (cl-mpm/dynamic-relaxation:converge-quasi-static
           sim
           :energy-crit conv-criteria
           :oobf-crit conv-criteria
           :dt-scale 0.9d0
           :conv-steps 10000
           :substeps substeps
           :damping-factor (sqrt 2d0)
           :post-iter-step
           (lambda (i e o)
             (save-conv-step sim output-dir *total-iter* 0 0d0 o e)
             (incf *total-iter* substeps)
             (cl-mpm/output:save-vtk (merge-pathnames output-dir (format nil "sim_conv_~5,'0d.vtk" i)) sim)
             (cl-mpm/output:save-vtk-nodes (merge-pathnames output-dir (format nil "sim_conv_nodes__~5,'0d.vtk" i)) sim)
             (cl-mpm/output:save-vtk-cells (merge-pathnames output-dir (format nil "sim_conv_cells__~5,'0d.vtk" i)) sim)
             (funcall plotter sim)))
          (cl-mpm::finalise-loadstep sim))
        (cl-mpm::reset-grid (cl-mpm:sim-mesh sim))
        (setf (cl-mpm::sim-time sim) 0d0)
        (cl-mpm/dynamic-relaxation::reset-mp-velocity sim)
        (setf (cl-mpm::sim-velocity-algorithm sim) vel-algo)
        (change-class sim sim-type)))

    (setf (cl-mpm:sim-mass-scale sim) mass-scale)
    (setf (cl-mpm:sim-damping-factor sim) (*
                                           (sqrt mass-scale)
                                           damping (cl-mpm/setup:estimate-critical-damping sim)))
    (setf (cl-mpm:sim-enable-damage sim) enable-damage)
    (cl-mpm:iterate-over-mps
     (cl-mpm:sim-mps sim)
     (lambda (mp)
       (when (typep mp 'cl-mpm/particle::particle-damage)
         (setf (cl-mpm/particle::mp-enable-damage mp) enable-damage))
       (when (typep mp 'cl-mpm/particle::particle-plastic)
         (setf (cl-mpm/particle::mp-enable-plasticity mp) enable-plastic))))
    (funcall post-conv-step sim)
    (setf (cl-mpm::sim-dt-scale sim) dt-scale)
    (setf (cl-mpm:sim-dt sim) (* (cl-mpm/setup:estimate-elastic-dt sim :dt-scale dt-scale)))
    (let* ((sim-time 0d0))
      (let ((total-iter 0)
            (dt-accumulator 0d0))
        (let ((state :accelerate)
              (oobf 0d0)
              (energy 0d0)
              (work 0d0)
              (hist adaptive-hist)
              )
          (when adaptive-mass-enabled
            (setf (cl-mpm:sim-mass-scale sim) adaptive-mass-scale))
          (time (loop for steps from 0 to (round total-time dt)
                      while (and (cl-mpm::sim-run-sim sim)
                                 (< sim-time total-time))
                      do
                         (let ((substeps 0))
                           (cl-mpm:sim-format sim t "Step ~d ~%" steps)
                           (cl-mpm/dynamic-relaxation::save-vtks sim output-dir steps)
                           (save-timestep sim output-dir total-iter :DYNAMIC)
                           (incf dt-accumulator dt)
                           (cl-mpm:sim-format sim t "Estimated substeps ~d ~%" (round dt (cl-mpm::sim-dt sim)))
                           (time
                            (loop while (> dt-accumulator 0d0)
                                  do
                                     (progn
                                       (cl-mpm::update-sim sim)

                                       (when adaptive-mass-enabled 
                                         (incf oobf (estimate-static-oobf sim))
                                         (incf energy (cl-mpm::sim-stats-energy sim))
                                         (incf work (estimate-strain-energy sim))
                                         (incf substeps)
                                         )

                                       (incf total-iter)
                                       (decf dt-accumulator (cl-mpm::sim-dt sim))
                                       (setf (cl-mpm:sim-dt sim) (* dt-scale (cl-mpm::calculate-min-dt sim))))))
                           (funcall post-iter-step sim)
                           (funcall plotter sim)
                           (when save-vtk-loadstep
                             (save-vtks sim output-dir steps))
                           (when adaptive-mass-enabled 
                             (setf oobf (/ oobf substeps)
                                   energy (/ energy work))
                             (format t "~A - OOBF ~E - energy ~E~%" state oobf energy)
                             (case state
                               (:accelerate
                                (when (or (> energy (* hist adaptive-crit))
                                          (> oobf (* hist adaptive-crit)))
                                  (format t "Switched to dynamic timestep~%")
                                  (setf
                                   state :dynamic
                                   (cl-mpm:sim-mass-scale sim) 1d0
                                   (cl-mpm:sim-dt sim) (/ (cl-mpm:sim-dt sim) (sqrt adaptive-mass-scale)))))
                               (:dynamic
                                (when (and (< energy (/ adaptive-crit hist))
                                           (< oobf (/ adaptive-crit hist)))
                                  (format t "Switched to accelerate timestep~%")
                                  (cl-mpm/dynamic-relaxation::reset-mp-velocity sim)
                                  (setf
                                   state :accelerate
                                   (cl-mpm:sim-mass-scale sim) adaptive-mass-scale
                                   (cl-mpm:sim-dt sim) (* (cl-mpm:sim-dt sim) (sqrt adaptive-mass-scale)))))))
                           (swank.live:update-swank)))))))
    result))

(defun run-load-control-timed (sim
                               &key (output-dir "./output/")
                                 (loading-function nil)
                                 (load-steps 10)
                                 (initial-load 0d0)
                                 (substeps 50)
                                 (damping 1d0)
                                 (kinetic-damping nil)
                                 (criteria 1d-3)
                                 (conv-steps 50)
                                 (post-conv-step (lambda (sim)))
                                 (post-iter-step (lambda (sub-iter oobf energy)))
                                 (pre-step (lambda ()))
                                 (plotter (lambda (sim)))
                                 (enable-damage t)
                                 (enable-plastic t)
                                 (save-vtk-dr t)
                                 (save-vtk-loadstep t)
                                 (dt-scale 1d0))
  (uiop:ensure-all-directories-exist (list output-dir))
  (loop for f in (uiop:directory-files (uiop:merge-pathnames* output-dir)) do (uiop:delete-file-if-exists f))
  (save-conv-preamble sim output-dir)
  (cl-mpm/output::save-simulation-parameters (merge-pathnames output-dir "settings.json") sim)
  (funcall pre-step)
  ;; (save-conv-step sim output-dir 0 0 0d0 0d0)
  (defparameter *total-iter* 0)
  (when save-vtk-loadstep
    (save-vtks sim output-dir 0))
  (with-accessors ((mps cl-mpm:sim-mps))
      sim
    (let* ((load (cl-mpm:sim-gravity sim)))
      (unless loading-function
        (setf loading-function (lambda (percent)
                                 (cl-mpm:sim-format sim t "Loading factor ~E~%" percent)
                                 (setf (cl-mpm:sim-gravity sim)
                                       (* load percent)))))
      (setf (cl-mpm::sim-dt-scale sim) dt-scale)
      (let ((t0 (get-internal-real-time))
            (tunits internal-time-units-per-second))
        (declare (function loading-function))
        (loop for step from 1 to load-steps
              while (cl-mpm::sim-run-sim sim)
              do
                 (progn
                   (cl-mpm:sim-format sim t "Load step ~D~%" step)
                   (defparameter *ke-last* 0d0)
                   (let* ((percent (/ (float step) load-steps)))
                     (funcall loading-function (+ initial-load (* (- 1d0 initial-load) percent))))
                   (let ()
                     (setf (cl-mpm/dynamic-relaxation::sim-damping-scale sim) damping)
                     (time
                      (cl-mpm/dynamic-relaxation:converge-quasi-static
                       sim
                       :oobf-crit criteria
                       :energy-crit 1d0
                       :dt-scale dt-scale
                       :substeps substeps
                       :kinetic-damping nil
                       :damping-factor damping
                       :conv-steps conv-steps
                       :post-iter-step
                       (lambda (i energy oobf)
                         (funcall post-iter-step i energy oobf))))))
                 (cl-mpm::finalise-loadstep sim)
                 ;; (funcall post-conv-step sim)
                 ;; (funcall plotter sim)
                 ;; (swank.live:update-swank)
              )
        (let ((dt (/ (- (get-internal-run-time) t0) tunits)))
          dt
          (when save-vtk-loadstep
            (save-vtks sim output-dir 1))
          dt)))))
