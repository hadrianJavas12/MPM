(in-package :cl-mpm/dynamic-relaxation)
(declaim #.cl-mpm/settings:*optimise-setting*)


(defmacro optional-time (option &rest body)
  `(if ,option
       (time ,@body)
       (progn ,@body)))

(define-condition non-convergence-error (cl-mpm/errors:error-simulation)
  ((text :initarg :text :reader text)
   (ke-norm :initarg :ke-norm :reader ke-norm)
   (oobf-norm :initarg :oobf-norm :reader oobf-norm)))

(define-condition error-damage-criteria (non-convergence-error)
  ((max-damage-inc :initarg :max-damage-inc :reader max-damage-inc)))

(define-condition error-inertia-criteria (non-convergence-error)
  ((inertia-norm :initarg :inertia-norm :reader inertia-norm)))


(defparameter *run-convergance* t)
(declaim (notinline converge-quasi-static))
(defun converge-quasi-static (sim &key
                                    (energy-crit 1d-8)
                                    (oobf-crit 1d-8)
                                    (live-plot nil)
                                    (dt-scale 1d0)
                                    (substeps 50)
                                    (conv-steps 50)
                                    (post-iter-step nil)
                                    (convergance-criteria nil)
                                    (pic-update nil)
                                    (kinetic-damping nil)
                                    (damping-factor 1d-1))
  "Converge a simulation to a quasi-static solution via dynamic relaxation, whatever simulation is updated until it converges"
  (let ((current-vel (cl-mpm::sim-velocity-algorithm sim)))
    (when pic-update
      (setf (cl-mpm::sim-velocity-algorithm sim) :BLEND))
    (when (typep sim 'mpm-sim-dr)
      ;; (format t "Set damping scale~%")
      (setf (cl-mpm/dynamic-relaxation::sim-damping-scale sim)
            (if damping-factor
                damping-factor
                0d0))
      (setf (cl-mpm/dynamic-relaxation::sim-convergence-critera sim)
            oobf-crit))
    (restart-case
        (%converge-quasi-static sim energy-crit oobf-crit live-plot dt-scale substeps conv-steps post-iter-step convergance-criteria kinetic-damping damping-factor)
      (continue ())
      (retry-convergence ()
        (%converge-quasi-static sim energy-crit oobf-crit live-plot dt-scale substeps conv-steps post-iter-step convergance-criteria kinetic-damping damping-factor)
        ))
    (setf (cl-mpm::sim-velocity-algorithm sim) current-vel)))

(defgeneric %converge-quasi-static (sim
                                    energy-crit
                                    oobf-crit
                                    live-plot
                                    dt-scale
                                    substeps
                                    conv-steps
                                    post-iter-step
                                    convergance-criteria
                                    kinetic-damping
                                    damping-factor
                                    )
 )
(defparameter *work* 0d0)
(defmethod %converge-quasi-static ((sim cl-mpm::mpm-sim)
                                   energy-crit
                                   oobf-crit
                                   live-plot
                                   dt-scale
                                   substeps
                                   conv-steps
                                   post-iter-step
                                   convergance-criteria
                                   kinetic-damping
                                   damping-factor)
  (declare (double-float dt-scale))
  (setf *run-convergance* t)
  (with-accessors ((mps cl-mpm:sim-mps))
      sim
    (let* ((fnorm 0d0)
           (energy-total 0d0)
           (oobf 0d0)
           (load 0d0)
           (converged nil))

      (setf (cl-mpm::sim-dt-scale sim) dt-scale)
      (setf (cl-mpm:sim-dt sim) (cl-mpm/setup::estimate-elastic-dt sim :dt-scale dt-scale))
      (if damping-factor
          (setf (cl-mpm:sim-damping-factor sim)
              (* damping-factor (cl-mpm/setup::estimate-critical-damping sim)))
          (setf (cl-mpm:sim-damping-factor sim) 0d0))

      (format t "Substeps ~D~%" substeps)

      (let ((energy-first 0d0)
            (energy-last 0d0))
        (setf *work* 0d0)
        (setf (cl-mpm::sim-stats-work sim) 0d0)
        (loop for i from 0 to conv-steps
              while (and *run-convergance*
                         (cl-mpm::sim-run-sim sim)
                         (not converged))
              do
                 (progn
                   (setf fnorm 0d0)
                   (optional-time
                    nil
                    ;; t
                    (dotimes (j substeps)
                      (cl-mpm:update-sim sim)
                      ;; (let ((power (cl-mpm::sim-stats-power sim))
                      ;;       (energy (cl-mpm::sim-stats-energy sim)))
                      ;;   (incf *work* power)
                      ;;   (when kinetic-damping
                      ;;     (if (and
                      ;;          (> energy-last energy-first)
                      ;;          (> energy-last energy))
                      ;;         (progn
                      ;;           (format t "Peak found resetting KE - ~E ~E ~E~%" energy-first energy-last energy)
                      ;;           (cl-mpm::zero-grid-velocity (cl-mpm:sim-mesh sim))
                      ;;           (cl-mpm:iterate-over-mps
                      ;;            mps
                      ;;            (lambda (mp)
                      ;;              (cl-mpm/fastmaths:fast-zero (cl-mpm/particle:mp-velocity mp))))
                      ;;           (setf energy-first 0d0
                      ;;                 energy-last 0d0
                      ;;                 energy 0d0))
                      ;;         (progn
                      ;;           (setf energy-first energy-last)
                      ;;           (setf energy-last energy))))
                      ;;   )
                      ))
                   (cl-mpm::update-dynamic-stats sim)
                   (setf energy-total (cl-mpm::sim-stats-energy sim))
                   (if (= *work* 0d0)
                       (setf fnorm 0d0)
                       (setf fnorm (abs (/ energy-total *work*))))
                   (setf oobf (cl-mpm::sim-stats-oobf sim))
                   (format t "Conv step ~D - KE norm: ~E - Work: ~E - OOBF: ~E~%" i fnorm *work* oobf)
                   (when (if convergance-criteria
                             (funcall convergance-criteria sim fnorm oobf)
                             (and
                              (< fnorm energy-crit)
                              (< oobf oobf-crit)))
                     (format t "Took ~D steps to converge~%" i)
                     (setf converged t))
                   (when post-iter-step
                     (funcall post-iter-step i fnorm oobf))
                   (swank.live:update-swank))))
      (when (not converged)
        (error (make-instance 'non-convergence-error
                              :text "System failed to converge"
                              :ke-norm fnorm
                              :oobf-norm 0d0)))
      (values load fnorm oobf))))

(defmethod %converge-quasi-static ((sim cl-mpm/mpi:mpm-sim-mpi)
                                   energy-crit
                                   oobf-crit
                                   live-plot
                                   dt-scale
                                   substeps
                                   conv-steps
                                   post-iter-step
                                   convergance-criteria
                                   kinetic-damping
                                    damping-factor
                                   )
  (setf *run-convergance* t)
  (with-accessors ((mps cl-mpm:sim-mps))
      sim
    (let* ((fnorm 0d0)
           (oobf 0d0)
           (rank (cl-mpi:mpi-comm-rank))
           (load 0d0)
           (converged nil))

      (setf (cl-mpm::sim-dt-scale sim) dt-scale)
      (setf (cl-mpm:sim-dt sim) (cl-mpm/setup::estimate-elastic-dt sim :dt-scale dt-scale))

      (when (= rank 0)
        (format t "Substeps ~D~%" substeps))

      (setf *work* 0d0)
      (let ((power-last 0d0))
        (loop for i from 0 to conv-steps
              while (and *run-convergance*
                         (not converged))
              do
                 (progn
                   (dotimes (j substeps)
                     (setf cl-mpm/penalty::*debug-force* 0d0)
                     (cl-mpm:update-sim sim)
                     (let ((power (cl-mpm::sim-stats-power sim)))
                       (incf *work* power)))

                   (if (= *work* 0d0)
                       (setf fnorm 0d0)
                       (setf fnorm (abs (/ (cl-mpm::sim-stats-energy sim) *work*))))

                   (setf oobf (cl-mpm::sim-stats-oobf sim))

                   (when (= 0 rank)
                     (format t "Estimated dt ~E~%" (cl-mpm:sim-dt sim)))

                   (when (= 0 rank)
                     (format t "Conv step ~D - KE norm: ~E - Work: ~E - OOBF: ~E - Load: ~E~%" i fnorm *work* oobf load))

                   (when (and (< fnorm energy-crit)
                              (< oobf oobf-crit)
                              (if convergance-criteria (funcall convergance-criteria sim fnorm oobf) t))
                     (when (= 0 rank)
                       (format t "Took ~D steps to converge~%" i))
                     (setf converged t))
                   (when post-iter-step
                     (funcall post-iter-step i fnorm oobf))
                   (swank.live:update-swank))))
      (when (not converged)
        (error (make-instance 'non-convergence-error
                              :text "System failed to converge"
                              :ke-norm fnorm
                              :oobf-norm 0d0))
        (when (= 0 rank)
          (format t "System didn't converge~%"))
        )
      (values load fnorm oobf))))


(defgeneric dr-estimate-damping (sim))

(let ((work-pool (cl-mpm/utils::make-object-pool
                  :constructor (lambda ()
                                 (cl-mpm/utils:vector-zeros)))))
  (defmethod dr-estimate-damping ((sim cl-mpm::mpm-sim))
    (with-accessors ((mesh cl-mpm:sim-mesh)
                     (dt cl-mpm:sim-dt))
        sim
      (let ((num 0d0)
            (denom 0d0))
        (cl-mpm/utils::object-pool-ensure-size work-pool)
        (setf
         num
         (cl-mpm::reduce-over-nodes
          mesh
          (lambda (node)
            (if (and (cl-mpm/mesh:node-active node)
                     (not (cl-mpm/mesh::node-agg node)))
                (cl-mpm/fastmaths:dot
                 (cl-mpm/mesh:node-velocity node)
                 (cl-mpm/fastmaths::fast-.--vector
                  (cl-mpm/mesh::node-residual-prev node)
                  (cl-mpm/mesh::node-residual node)
                  (cl-mpm/utils::object-pool-grab-unsafe work-pool)
                  ))
                0d0))
          #'+))
        (setf
         denom
         (* dt
            (cl-mpm::reduce-over-nodes
             mesh
             (lambda (node)
               (if (and (cl-mpm/mesh:node-active node)
                        (not (cl-mpm/mesh::node-agg node)))
                   (*
                    (cl-mpm/mesh:node-mass node)
                      (cl-mpm/fastmaths::dot
                       (cl-mpm/mesh::node-velocity node)
                       (cl-mpm/mesh::node-velocity node)))
                   0d0))
             #'+)))
        (if (> num 0d0)
            (if (= denom 0d0)
                0d0
                (* (sqrt 2d0) (sqrt (/ num denom))))
            0d0)))))

(let ((work-pool (cl-mpm/utils::make-object-pool
                  :constructor (lambda ()
                                 (cl-mpm/utils:vector-zeros)))))
  (defmethod dr-estimate-damping ((sim cl-mpm/aggregate::mpm-sim-aggregated))
    (with-accessors ((mesh cl-mpm:sim-mesh))
        sim
      (let ((num 0d0)
            (denom 0d0)
            (dt 1d0))
        (declare (double-float denom num))
        (cl-mpm/utils::object-pool-ensure-size work-pool)
        (setf
         num
         (cl-mpm::reduce-over-nodes
          mesh
          (lambda (node)
            (if (and (cl-mpm/mesh:node-active node)
                     (not (cl-mpm/mesh::node-agg node)))
                (cl-mpm/fastmaths:dot
                 (cl-mpm/mesh:node-velocity node)
                 (cl-mpm/fastmaths:fast-.-
                  (cl-mpm/mesh::node-residual-prev node)
                  (cl-mpm/mesh::node-residual node)
                  (cl-mpm/utils::object-pool-grab-unsafe work-pool)
                  ))
                0d0))
          #'+))
        (setf
         denom
         (* dt
            (the double-float
                 (cl-mpm::reduce-over-nodes
                  mesh
                  (lambda (node)
                    (the double-float
                         (if (and (cl-mpm/mesh:node-active node)
                                  (not (cl-mpm/mesh::node-agg node)))
                             (*
                              (the double-float (cl-mpm/mesh:node-mass node))
                              (the double-float (cl-mpm/fastmaths::mag-squared
                                                 (cl-mpm/mesh::node-velocity node))))
                             0d0)))
                  #'+))))

        (when (cl-mpm/aggregate::sim-enable-aggregate sim)
          (cl-mpm/aggregate::iterate-over-dimensions-with-mutex
           (cl-mpm/mesh::mesh-nd mesh)
           (lambda (d mut)
             (let* ((res (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-residual d))
                    (res-prev (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-residual-prev d))
                    (ma (cl-mpm/aggregate::assemble-global-scalar sim #'cl-mpm/mesh::node-mass))
                    (vi (cl-mpm/aggregate::assemble-internal-vec sim #'cl-mpm/mesh::node-velocity d))
                    (vglobal
                      (cl-mpm/aggregate::extend-vec
                       sim
                       vi
                       d)))
               (let ((dnum (cl-mpm/fastmaths:dot
                            (cl-mpm/fastmaths::fast-.- res-prev res)
                            vglobal
                            ))
                     (ddenom (* dt (cl-mpm/fastmaths:dot vglobal
                                                         (cl-mpm/fastmaths::fast-.*
                                                          ma
                                                          vglobal)))))
                 (declare (double-float num dnum denom ddenom))
                 (sb-thread::with-mutex (mut)
                   (incf num dnum)
                   (incf denom ddenom))))
             ;; (let* ((res (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-residual d))
             ;;        (res-prev (cl-mpm/aggregate::assemble-global-vec sim #'cl-mpm/mesh::node-residual-prev d))
             ;;        (vi (cl-mpm/aggregate::assemble-internal-vec sim #'cl-mpm/mesh::node-velocity d)))
             ;;   (let ((dnum (cl-mpm/fastmaths:dot
             ;;                vi
             ;;                (cl-mpm/aggregate::aggregate-vec
             ;;                 sim
             ;;                 (cl-mpm/fastmaths::fast-.- res-prev res)
             ;;                 d)))
             ;;         (ddenom (* dt (cl-mpm/fastmaths:dot vi (cl-mpm/aggregate::@-mass-matrix-vec sim vi d)))))
             ;;     (declare (double-float num dnum denom ddenom))
             ;;     (sb-thread::with-mutex (mut)
             ;;       (incf num dnum)
             ;;       (incf denom ddenom))))
             )))
        (min 1.9d0
             (max 0d0
                  (* (the double-float (cl-mpm/dynamic-relaxation::sim-damping-scale sim))
                     (if (> num 0d0)
                         (if (= denom 0d0)
                             0d0
                             (the double-float
                                  (* (sqrt 2d0)
                                     (the double-float
                                          (sqrt (max 0d0 (the double-float (/ num denom))))))))
                         0d0))))))))

(defun compute-condition (sim)
  (/ 1d0 (expt (/ (dr-estimate-damping sim) 2) 2)))


(defun reset-mp-velocity (sim)
  (cl-mpm:iterate-over-mps
   (cl-mpm:sim-mps sim)
   (lambda (mp)
     (cl-mpm/fastmaths::fast-zero (cl-mpm/particle::mp-velocity-gradient mp))
     (cl-mpm/fastmaths::fast-zero (cl-mpm/particle:mp-velocity mp)))))


(defmethod cl-mpm::finalise-loadstep ((sim mpm-sim-dr))
  ;;DR algorithm requires that finalisation is called once
  (incf (cl-mpm::sim-time sim) (sim-dt-loadstep sim))
  ;; (cl-mpm::reset-node-displacement sim)
  (cl-mpm::new-loadstep sim))


(declaim (ftype (function (cl-mpm/particle::particle fixnum)
                          double-float)
                estimate-ul-enhancement)
         (inline estimate-ul-enhancement))
(defun estimate-ul-enhancement (particle nd)
  (declare (cl-mpm/particle::particle particle)
           (fixnum nd))
  (let ((df-inv (cl-mpm/particle::mp-deformation-gradient-increment-inverse particle)))
    (max 1d0
         (ecase nd
           (1
            (cl-mpm::UL-push-cached 1d0 0d0 0d0 df-inv nd))
           (2
            (cl-mpm::UL-push-cached 1d0 1d0 0d0 df-inv nd))
           (3
            (cl-mpm::UL-push-cached 1d0 1d0 1d0 df-inv nd))))))





