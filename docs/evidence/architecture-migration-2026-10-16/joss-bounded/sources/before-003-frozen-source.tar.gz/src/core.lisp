;    #:make-shape-function
(in-package :cl-mpm)

;(declaim (optimize (debug 3) (safety 3) (speed 0)))
;; (declaim (optimize (debug 3) (safety 3) (speed 0)))
;; (declaim (optimize (debug 0) (safety 0) (speed 3)))
(declaim #.cl-mpm/settings:*optimise-setting*)

(eval-when (:compile-toplevel :load-toplevel :execute)
  #+cl-mpm-special (print "Compiled with special hooks")
  #-cl-mpm-special (print "Compiled without special hooks")
  (format t "Compiled with optimize ~A~%" (sb-ext:restrict-compiler-policy))
  (defparameter *git-hash* "NO-HASH")
  (defun read-current-git-hash ()
    (with-open-file (fs (asdf:system-relative-pathname :cl-mpm "./config/git-commit-version.txt") :direction :input)
      (defparameter *git-hash* (read fs)))
    (format t "Git commit ~A~%" cl-mpm::*git-hash*))
  (read-current-git-hash)
  (defun build-git-hash ()
    (format t "Git commit ~A~%" cl-mpm::*git-hash*)))

(defun FLIP-status ()
  #+cl-mpm-pic (print "Compiled with PIC")
  #-cl-mpm-pic (print "Compiled with FLIP")
  )

(declaim (notinline check-mps))
(defun check-mps (sim)
  "Function to check that stresses and positions are sane, deleting mps moving very fast"
  (with-accessors ((mps cl-mpm:sim-mps)
                   (mesh cl-mpm:sim-mesh)
                   (split-depth sim-max-split-depth)
                   (removal-factor sim-mp-removal-size))
      sim
  (with-accessors ((h cl-mpm/mesh::mesh-resolution))
      mesh
    (when removal-factor
      (let ((h (* h removal-factor)))
        (remove-mps-func
         sim
         (lambda (mp)
           (with-accessors ((damage cl-mpm/particle:mp-damage)
                            (def cl-mpm/particle::mp-deformation-gradient))
               mp
             (or
              (> (cl-mpm/particle::mp-split-depth mp) split-depth)
              (if removal-factor
                  (gimp-removal-criteria mp h)
                  nil))))))))))

(defun check-single-mps (sim)
  "Function to check and remove single material points"
  (with-accessors ((mps cl-mpm:sim-mps)
                   (mesh cl-mpm:sim-mesh))
      sim
  (with-accessors ((h cl-mpm/mesh::mesh-resolution))
      mesh
    (iterate-over-mps
     mps
     (lambda (mp)
       (setf (cl-mpm/particle::mp-single-particle mp)
             (single-particle-criteria mesh mp))))
    (remove-mps-func
     sim
     #'cl-mpm/particle::mp-single-particle))))


(defgeneric update-sim (sim)
  (:documentation "Update an mpm simulation by one timestep"))



(defun update-node (node dt)
  "Calculate velocity from momentum on a single node"
  (when (cl-mpm/mesh:node-active node)
    (with-accessors ((vel   node-velocity)
                     (disp   cl-mpm/mesh::node-displacment))
        node
      (cl-mpm/fastmaths:fast-fmacc disp vel dt))))

(defun get-cell-df (mesh point)
  (let ((dF (cl-mpm/utils:matrix-eye 1d0)))
    (cl-mpm::iterate-over-neighbours-point-linear
     mesh
     point
     (lambda (mesh node weight grads)
       (when (cl-mpm/mesh::node-active node)
         (cl-mpm/shape-function::@-combi-assemble-dstretch-3d grads (cl-mpm/mesh::node-displacment node) df))))
    dF))

(defun filter-cell (mesh cell dt)
  (with-accessors ((mp-count cl-mpm/mesh::cell-mp-count)
                   (active cl-mpm/mesh::cell-active)
                   (partial cl-mpm/mesh::cell-partial)
                   (neighbours cl-mpm/mesh::cell-neighbours)
                   (index cl-mpm/mesh::cell-index)
                   (nodes cl-mpm/mesh::cell-nodes)
                   (df cl-mpm/mesh::cell-deformation-gradient)
                   (disp cl-mpm/mesh::cell-displacement)
                   (centroid cl-mpm/mesh::cell-centroid)
                   (trial-pos cl-mpm/mesh::cell-trial-centroid)
                   )
      cell
    ;;Old depricated
    (setf mp-count t)
    ;;Are any nodes active
    (setf active nil)
    ;;False only if all nodes active
    (setf partial t)
    (loop for n across nodes
          do
             (let ((oc (cl-mpm/mesh:node-active n)))
               (setf mp-count (and mp-count oc))
               (setf partial (and partial oc))
               (setf active (or active oc))))
    (setf mp-count (if mp-count 1 0)
          partial (not partial))))

(defgeneric filter-cells (sim))
(defmethod filter-cells ((sim mpm-sim))
  (with-accessors ((mesh sim-mesh)
                   (dt sim-dt))
      sim
    (iterate-over-cells
     mesh
     (lambda (cell)
       (filter-cell mesh cell dt)))))

(defun update-cell (mesh cell dt)
  "Update cell data, useful for ghost penalty"
  (when (and
         (cl-mpm/mesh::cell-active cell)
         (not
          (cl-mpm/mesh::cell-partial cell)))
    (with-accessors ((mp-count cl-mpm/mesh::cell-mp-count)
                     (active cl-mpm/mesh::cell-active)
                     (partial cl-mpm/mesh::cell-partial)
                     (neighbours cl-mpm/mesh::cell-neighbours)
                     (index cl-mpm/mesh::cell-index)
                     (nodes cl-mpm/mesh::cell-nodes)
                     (df cl-mpm/mesh::cell-deformation-gradient)
                     (disp cl-mpm/mesh::cell-displacement)
                     (centroid cl-mpm/mesh::cell-centroid)
                     (trial-pos cl-mpm/mesh::cell-trial-centroid))
        cell
      (cl-mpm/fastmaths:fast-zero disp)
      (cl-mpm/fastmaths:fast-zero df)
      (setf (varef df 0) 1d0
            (varef df 4) 1d0
            (varef df 8) 1d0)
      (let ((w 0d0))
        (declare (double-float w))
        (cl-mpm::iterate-over-neighbours-point-linear
         mesh
         centroid
         (lambda (mesh node weight grads)
           (declare (double-float weight))
           (when (cl-mpm::node-active node)
             ;; (incf w weight)
             (let ((ndisp (cl-mpm/mesh::node-displacment node)))
               (incf (cl-mpm/mesh::cell-volume-current cell) (* weight (cl-mpm/mesh::node-volume node)))
               (cl-mpm/shape-function::@-combi-assemble-dstretch-3d grads ndisp df)
               (cl-mpm/fastmaths:fast-fmacc
                disp
                ndisp weight))))))
      (cl-mpm/fastmaths:fast-.+ centroid disp trial-pos))))

(defgeneric update-cells (sim))
(defmethod update-cells ((sim mpm-sim))
  (with-accessors ((mesh sim-mesh)
                   (dt sim-dt))
      sim
    (iterate-over-cells
     mesh
     (lambda (cell)
       (filter-cell mesh cell dt)
       (update-cell mesh cell dt)))))

(defgeneric update-filtered-cells (sim))
(defmethod update-filtered-cells (sim)
  (with-accessors ((mesh sim-mesh)
                   (dt sim-dt))
      sim
    (iterate-over-cells
     mesh
     (lambda (cell)
       (update-cell mesh cell dt)))))

(defgeneric update-nodes (sim))
(defmethod update-nodes (sim)
  (with-accessors ((mesh sim-mesh)
                   (dt sim-dt))
      sim
    (iterate-over-nodes
     mesh
     (lambda (node)
       (when (cl-mpm/mesh:node-active node)
         (update-node node dt))))))

(defun reset-nodes-force (sim)
  (cl-mpm::iterate-over-nodes
   (cl-mpm:sim-mesh sim)
   (lambda (n)
     (when (cl-mpm/mesh::node-active n)
       (cl-mpm/mesh::reset-node-force n)))))


(defgeneric pre-particle-update-hook (particle dt))
(defmethod pre-particle-update-hook (particle dt))

(defgeneric special-update-node (mesh dt node damping)
  (:documentation "Update node method")
  (:method (mesh dt node damping)))

(defmethod special-update-node (mesh dt (node cl-mpm/mesh::node-thermal) damping)
  (with-accessors ((mass  node-mass)
                   (temp node-temperature)
                   (dtemp node-dtemp))
      node
    (progn
      (setf temp (+ (/ temp mass) (* dtemp dt)))
      )))

(defun integrate-vel-euler (vel acc mass mass-scale dt damping)
  (declare (double-float mass mass-scale dt damping))
  ;; (cl-mpm/fastmaths:fast-fmacc vel acc dt)
  ;; Better integration of damping but whatever
  (unless (= dt 0d0)
    (cl-mpm/fastmaths:fast-fmacc vel acc dt)
    ;; (if (= damping 0d0))
    ;; (let ((exp-fac (exp (- (* damping dt)))))
    ;;   (declare (double-float exp-fac))
    ;;   (cl-mpm/fastmaths:fast-scale! vel exp-fac)
    ;;   (cl-mpm/fastmaths:fast-fmacc vel acc (* (/ 1d0 damping) (- 1d0 exp-fac)))
    ;;   )
    ))

(declaim (inline calculate-forces)
         (ftype (function (cl-mpm/mesh::node double-float double-float double-float) (vaules)) calculate-forces))
(defun calculate-forces (node damping dt mass-scale)
  "Update forces and nodal velocities with viscous damping"
  (with-accessors ((mass node-mass)
                   (vel node-velocity)
                   (force node-force)
                   (force-ext cl-mpm/mesh::node-external-force)
                   (force-int cl-mpm/mesh::node-internal-force)
                   (force-damp cl-mpm/mesh::node-damping-force)
                   (force-ghost cl-mpm/mesh::node-ghost-force)
                   (residual cl-mpm/mesh::node-residual)
                   (residual-prev cl-mpm/mesh::node-residual-prev)
                   (acc node-acceleration))
      node
    (declare (double-float mass dt damping mass-scale))
    (progn
      (cl-mpm/fastmaths::fast-zero-vector acc)
      ;;Set acc to f/m
      (cl-mpm/fastmaths::fast-.+-vector force-int force force)
      (cl-mpm/fastmaths::fast-.+-vector force-ext force force)
      ;;Include velocity prop damping
      (cl-mpm/fastmaths:fast-fmacc force-damp vel (* damping -1d0 mass))
      (cl-mpm/fastmaths::fast-.+-vector force-damp force force)
      ;; (cl-mpm/fastmaths::fast-.+-vector force-ghost force force)
      (when (> mass 0d0)
        (cl-mpm/fastmaths:fast-fmacc acc force (/ 1d0 (* mass mass-scale))))
      (integrate-vel-euler vel acc mass mass-scale dt 0d0)
      ;; (cl-mpm/utils::vector-copy-into residual residual-prev)
      ;; (cl-mpm/utils::vector-copy-into force residual)
      ))
  (values))



(declaim (inline integrate-vel-midpoint)
         (ftype (function (magicl::matrix/double-float
                           magicl::matrix/double-float
                           double-float double-float double-float double-float) (vaules)) integrate-vel-midpoint))
(defun integrate-vel-midpoint (vel acc mass mass-scale dt damping)
  (declare (double-float mass mass-scale dt damping))
  (unless (= dt 0d0)
    (let ((damp-dt (/ (* dt damping) mass-scale)))
      (cl-mpm/fastmaths:fast-scale!
       vel
       (/ (- 2d0 damp-dt) (+ 2d0 damp-dt)))
      (cl-mpm/fastmaths:fast-fmacc
       vel
       acc
       (/ (* dt 2d0) (+ 2d0 damp-dt)))))
  (values))



(declaim (inline calculate-forces-midpoint)
         (ftype (function (cl-mpm/mesh::node double-float double-float double-float) (vaules)) calculate-forces-midpoint))
(defun calculate-forces-midpoint (node damping dt mass-scale)
  (declare (cl-mpm/mesh::node node)
           (double-float damping dt mass-scale))
  "Update forces and nodal velocities with viscous damping"
  (with-accessors ((mass node-mass)
                   (vel node-velocity)
                   (force node-force)
                   (force-ext cl-mpm/mesh::node-external-force)
                   (force-int cl-mpm/mesh::node-internal-force)
                   (force-damp cl-mpm/mesh::node-damping-force)
                   (force-ghost cl-mpm/mesh::node-ghost-force)
                   (residual cl-mpm/mesh::node-residual)
                   (residual-prev cl-mpm/mesh::node-residual-prev)
                   (acc node-acceleration))
      node
    (declare (double-float mass dt damping mass-scale))
    (progn
      (cl-mpm/fastmaths::fast-zero-vector acc)
      ;;Set acc to f/m
      (cl-mpm/fastmaths::fast-.+-vector force-int force force)
      (cl-mpm/fastmaths::fast-.+-vector force-ext force force)
      (cl-mpm/fastmaths::fast-.+-vector force-damp force force)
      (cl-mpm/fastmaths::fast-.+-vector force-ghost force force)
      (when (> mass 0d0)
        (cl-mpm/fastmaths:fast-fmacc acc force (/ 1d0 (* mass mass-scale))))
      (cl-mpm/utils::vector-copy-into residual residual-prev)
      (cl-mpm/utils::vector-copy-into force residual)
      ))
  (values))

(defun calculate-forces-psudo-viscous (node damping dt mass-scale)
  "Update forces and nodal velocities with viscous damping - except without scaling by mass
This allows for a non-physical but viscous damping scheme that is robust to GIMP domains "
  (when (cl-mpm/mesh:node-active node)
    (with-accessors ( (mass  node-mass)
                     (vel   node-velocity)
                     (force node-force)
                     (force-ext cl-mpm/mesh::node-external-force)
                     (force-int cl-mpm/mesh::node-internal-force)
                     (acc   node-acceleration))
        node
      (declare (double-float mass dt damping mass-scale))
      (progn
        (magicl:scale! acc 0d0)
        ;;Set acc to f/m
        (cl-mpm/fastmaths::fast-.+-vector force-int force-ext force)
        (cl-mpm/fastmaths:fast-fmacc acc force (/ 1d0 (* mass mass-scale)))
        (cl-mpm/fastmaths:fast-fmacc acc vel (* damping -1d0))
        (cl-mpm/fastmaths:fast-fmacc vel acc dt)
        )))
  (values))

(defun calculate-forces-cundall (node damping dt mass-scale)
  "Apply cundall damping to the system"
  (when (cl-mpm/mesh:node-active node)
    (with-accessors ((mass  node-mass)
                     (vel   node-velocity)
                     (force node-force)
                     (force-ext cl-mpm/mesh::node-external-force)
                     (force-int cl-mpm/mesh::node-internal-force)
                     (acc   node-acceleration)
                     )
        node
      (declare (double-float mass dt damping mass-scale))
      (progn
        (magicl:scale! acc 0d0)
        ;;Set acc to f/m
        (cl-mpm/fastmaths::fast-.+-vector force-int force-ext force)
        (let* ((vel-sign (cl-mpm/utils:vector-zeros))
               (f-s (magicl::matrix/double-float-storage force))
               (v-s (magicl::matrix/double-float-storage vel))
               (fnorm (cl-mpm/fastmaths::mag force))
               (vs-s (magicl::matrix/double-float-storage vel-sign)))
          (loop for i from 0 to 2
                do
                   ;;Possible form of damping
                   (when t;(> (* (aref f-s i) (aref v-s i)) 0)
                     (incf (aref f-s i)
                           (*
                            (signum (aref v-s i))
                            (abs (aref f-s i))
                            damping
                            -1d0))))
          (cl-mpm/fastmaths:fast-fmacc acc force (/ 1d0 (* mass mass-scale))))
        (cl-mpm/fastmaths:fast-fmacc vel acc dt))))
  (values))
(defun calculate-forces-cundall-conservative (node damping dt mass-scale)
  "Apply cundall damping to the system only when doing negative work"
  (when (cl-mpm/mesh:node-active node)
    (with-accessors ((mass  node-mass)
                     (vel   node-velocity)
                     (force node-force)
                     (acc   node-acceleration)
                     )
        node
      (declare (double-float mass dt damping))
      (progn
        (magicl:scale! acc 0d0)
        ;;Set acc to f/m

        (let* ((vel-sign (cl-mpm/utils:vector-zeros))
               (f-s (magicl::matrix/double-float-storage force))
               (v-s (magicl::matrix/double-float-storage vel))
               (fnorm (cl-mpm/fastmaths::mag force))
               (vs-s (magicl::matrix/double-float-storage vel-sign)))
          (loop for i from 0 to 2
                do
                   ;;Possible form of damping
                   (when (> (* (aref f-s i) (aref v-s i)) 0)
                     (incf (aref f-s i)
                           (*
                            (signum (aref v-s i))
                            (abs (aref f-s i))
                            damping
                            -1d0)))
                )
          (cl-mpm/fastmaths:fast-fmacc acc force (/ 1d0 (* mass mass-scale))))
        (cl-mpm/fastmaths:fast-fmacc vel acc dt))))
  (values))

(declaim (notinline calculate-forces-water-viscous)
         (ftype (function (cl-mpm/mesh::node double-float double-float double-float double-float) (vaules)) calculate-forces-water-viscous))
(defun calculate-forces-water-viscous (node damping damping-water dt mass-scale)
  "Update forces and nodal velocities with viscous damping"
  (when (cl-mpm/mesh:node-active node)
    (with-accessors ((mass  node-mass)
                     (vel   node-velocity)
                     (boundary   cl-mpm/mesh::node-boundary-node)
                     (force node-force)
                     (force-ext cl-mpm/mesh::node-external-force)
                     (force-int cl-mpm/mesh::node-internal-force)
                     (acc   node-acceleration))
        node
      (declare (double-float mass dt damping mass-scale))
      (progn
        (cl-mpm/fastmaths:fast-zero acc)
        ;;Set acc to f/m
        ;; (cl-mpm/fastmaths:fast-fmacc force-ext vel (* -2d0 damping mass))
        (cl-mpm/fastmaths::fast-.+-vector force-int force-ext force)
        ;; (cl-mpm/fastmaths:fast-fmacc acc vel (/ (* damping -1d0) 1d0))
        (cl-mpm/fastmaths:fast-fmacc acc force (/ 1d0 (* mass mass-scale)))
        (cl-mpm/fastmaths:fast-fmacc acc vel (/ (* damping -1d0) mass-scale))
        (when boundary
          (cl-mpm/fastmaths:fast-fmacc acc vel (/ (* damping-water -1d0) mass-scale)))
        ;; (cl-mpm/fastmaths:fast-fmacc acc vel (/ (* damping -1d0) (sqrt mass-scale)))
        ;; (cl-mpm/fastmaths:fast-fmacc acc vel (* damping -1d0))
        (cl-mpm/fastmaths:fast-fmacc vel acc dt)
        )))
  (values))

(defun calculate-kinematics (node)
  "Calculate velocity from momentum on a single node"
  (when (cl-mpm/mesh:node-active node)
    (with-accessors ((mass  node-mass)
                     (vel   node-velocity)
                     (damage cl-mpm/mesh::node-damage)
                     (disp   cl-mpm/mesh::node-displacment)
                     (volume cl-mpm/mesh::node-volume)
                     )
        node
      (declare (double-float mass volume))
      (progn
        (setf damage (/ damage volume))
        (when (> mass 0d0)
          (cl-mpm/fastmaths::fast-scale! vel (/ 1.0d0 mass)))))))

(defgeneric update-node-kinematics (sim))
(defmethod update-node-kinematics ((sim mpm-sim))
  (with-accessors ((mesh cl-mpm:sim-mesh))
      sim
    (iterate-over-nodes
     mesh
     (lambda (node)
       (calculate-kinematics node)))))

(defun update-node-forces-standard (sim)
  (with-accessors ((damping sim-damping-factor)
                   (mass-scale sim-mass-scale)
                   (mesh sim-mesh)
                   (damping-algo sim-damping-algorithm)
                   (dt sim-dt))
      sim
    (iterate-over-nodes
     mesh
     (lambda (node)
       (when (cl-mpm/mesh:node-active node)
         (calculate-forces node damping dt mass-scale))))))

(defgeneric update-node-forces (sim)
  (:documentation "Update the acceleration from forces and apply any damping"))
(defmethod update-node-forces ((sim cl-mpm::mpm-sim))
  (update-node-forces-standard sim))



(defmethod update-node-forces ((sim mpm-sim-quasi-static))
  (with-accessors ((damping sim-damping-factor)
                   (mass-scale sim-mass-scale)
                   (mesh sim-mesh)
                   (dt sim-dt))
      sim
    (iterate-over-nodes
     mesh
     (lambda (node)
       (when (cl-mpm/mesh:node-active node)
         (calculate-forces-cundall node damping dt mass-scale))))))


(defgeneric apply-essential-bcs (sim))
(defmethod apply-essential-bcs ((sim mpm-sim))
  (with-accessors ((mesh sim-mesh)
                   (dt sim-dt)
                   (bcs sim-active-bcs))
      sim
    (declare ((vector cl-mpm/bc::bc *) bcs))
    (with-accessors ((nodes  mesh-nodes)
                     (nD     mesh-nD))
        mesh
      (cl-mpm/utils::bpdotimes
       (i (length bcs))
       (let ((bc (aref bcs i)))
         (when bc
           (with-accessors ((node cl-mpm/bc::bc-node)
                            (index cl-mpm/bc::bc-index))
               bc
             (if (or node
                     (not index))
                 (cl-mpm/bc:apply-bc bc node mesh dt)
                 (progn
                   (setf node (cl-mpm/mesh:get-node mesh index))
                   (if node
                       (cl-mpm/bc:apply-bc bc node mesh dt)
                       (error "BC attempted to get a nil node ~A ~A" bc index)))))))))))

(defmethod compute-reaction-force ((sim mpm-sim))
  (with-accessors ((mesh sim-mesh)
                   (dt sim-dt))
      sim
    (cl-mpm::iterate-over-nodes
      mesh
      (lambda (n)
        (when (cl-mpm/mesh::node-bcs n)
          (loop for bc across (cl-mpm/utils::fast-storage (cl-mpm/mesh::node-bcs n))
                for f across (cl-mpm/utils::fast-storage (cl-mpm/mesh::node-force n))
                for i from 0
                do
                   (incf (cl-mpm/utils::varef (cl-mpm/mesh::node-reaction-force n) i) (* (- 1d0 bc) f))))))))
(defgeneric apply-force-bcs (sim dt))
(defmethod apply-force-bcs ((sim mpm-sim) dt)
  (with-accessors ((mesh sim-mesh)
                   (dt sim-dt)
                   (bcs-list sim-bcs-force-list)
                   (bcs-force sim-bcs-force)
                   )
      sim
    (cl-mpm::apply-bcs mesh bcs-force dt)
    (loop for bcs in bcs-list
          do ;; (cl-mpm/utils::bpdotimes (i (length bcs)))
             (loop for bc across bcs
                   do (let ()
                        (cl-mpm/bc::apply-sim-bc sim bc dt))))))

(defun apply-bcs (mesh bcs dt)
  "Apply all normal bcs onto the mesh"
  (declare (cl-mpm/mesh::mesh mesh))
  (with-accessors ((nodes  mesh-nodes)
                   (nD     mesh-nD))
      mesh
    (cl-mpm/utils::bpdotimes (i (length bcs))
      (let ((bc (aref bcs i)))
        (when bc
          (with-accessors ((node cl-mpm/bc::bc-node)
                           (index cl-mpm/bc::bc-index))
              bc
            (if (or node
                    (not index))
                (cl-mpm/bc:apply-bc bc node mesh dt)
                (progn
                  (setf node (cl-mpm/mesh:get-node mesh index))
                  (if node
                      (cl-mpm/bc:apply-bc bc node mesh dt)
                      (error "BC attempted to get a nil node ~A ~A" bc index))))))))))




(defun rotation-matrix (degrees)
  (let ((angle (/ (* pi degrees) 180)))
    (magicl:from-list (list (cos angle) (- (sin angle))
                            (sin angle) (cos angle))
                      '(2 2)
                      :type 'double-float
                      )))

(defun map-jacobian (mesh mp dt)
  (with-accessors ((stretch-tensor cl-mpm/particle::mp-stretch-tensor)
                   (volume cl-mpm/particle:mp-volume)
                   (def cl-mpm/particle:mp-deformation-gradient))
      mp
    (let* ((df (cl-mpm/utils::matrix-from-list '(1d0 0d0 0d0
                                                 0d0 1d0 0d0
                                                 0d0 0d0 1d0))))
      (cl-mpm/fastmaths::fast-.+ df stretch-tensor df)
      (let ((j-inc (cl-mpm/fastmaths:det-3x3 df))
            (j-n
              1d0
              ;; (cl-mpm/fastmaths:det-3x3 def)
              ))
        (iterate-over-neighbours
         mesh mp
         (lambda (node svp grads fsvp fgrads)
           (with-accessors ((node-active cl-mpm/mesh:node-active)
                            (node-j-inc cl-mpm/mesh::node-jacobian-inc)
                            (node-volume cl-mpm/mesh::node-volume)
                            (node-svp cl-mpm/mesh::node-svp-sum)
                            (node-lock cl-mpm/mesh::node-lock))
               node
             (declare (double-float node-j-inc svp volume j-inc j-n node-volume))
             (when node-active
               (sb-thread:with-mutex (node-lock)
                 ;(incf node-j-inc (* svp j-inc j-n (/ volume node-volume)))
                 (incf node-j-inc (* j-inc j-n (/ svp node-svp)))
                 )))))))))


(defun update-particle-kirchoff (mesh mp dt)
  (with-accessors ((disp cl-mpm/particle::mp-displacement)
                   (disp-inc cl-mpm/particle::mp-displacement-increment)
                   (pos cl-mpm/particle::mp-position)
                   (pos-trial cl-mpm/particle::mp-position-trial)
                   (nc cl-mpm/particle::mp-cached-nodes)
                   (contact-step cl-mpm/particle::mp-penalty-contact-step)
                   (friction-force cl-mpm/particle:mp-penalty-frictional-force)
                   (friction-force-prev cl-mpm/particle::mp-penalty-frictional-force-prev)
                   (normal-force cl-mpm/particle::mp-penalty-normal-force)
                   (contact cl-mpm/particle::mp-penalty-contact)
                   )
      mp
    (setf (fill-pointer nc) 0)
    (cl-mpm/fastmaths::fast-.+-vector pos disp-inc pos)
    (cl-mpm/fastmaths::fast-.+-vector disp disp-inc disp)
    (cl-mpm/utils::vector-copy-into pos pos-trial)
    (setf contact-step contact)
    (unless contact
      (cl-mpm/fastmaths:fast-zero friction-force)
      (cl-mpm/fastmaths:fast-zero friction-force-prev)
      (setf normal-force 0d0))
    (setf (cl-mpm/particle::mp-penalty-stiffness mp) 0d0)
    (setf contact nil)))

(defgeneric update-particle (mesh mp dt)
  (:documentation "End of step update"))
(defmethod update-particle (mesh (mp cl-mpm/particle:particle) dt)
  (update-particle-kirchoff mesh mp dt)
  (cl-mpm::update-domain-polar mesh mp dt)
  ;; (update-domain-corner mesh mp dt)
  ;; (update-domain-stretch mesh mp dt)
  ;; (cl-mpm::scale-domain-size mesh mp)
  )

(defun update-particles (sim)
  "Map particle momentum to the grid"
  (with-accessors ((mps sim-mps)
                   (mesh sim-mesh)
                   (dt sim-dt))
      sim
    (iterate-over-mps
     mps
     (lambda (mp)
       (update-particle mesh mp dt)))))



(declaim (ftype (function (cl-mpm/mesh::mesh
                           (vector cl-mpm/particle:particle *)
                           double-float
                           &optional boolean) (values)) update-stress))
(defun update-stress (mesh mps dt &optional (fbar nil))
  "Update all stresses, with optional f-bar"
  (declare ((vector cl-mpm/particle:particle *) mps) (cl-mpm/mesh::mesh mesh))
  ;; (iterate-over-mps
  ;;  mps
  ;;  (lambda (mp)
  ;;    (calculate-strain-rate mesh mp dt)
  ;;    (map-jacobian mesh mp dt)))
  (iterate-over-mps
   mps
   (lambda (mp)
     (update-stress-mp mesh mp dt fbar)
     ;; (post-stress-step mesh mp dt)
     ))
  (values))




(defgeneric update-stress-mp (mesh mp dt fbar)
  (:documentation "A mp dependent stress update scheme"))
(defmethod update-stress-mp (mesh (mp cl-mpm/particle::particle) dt fbar)
  (update-stress-kirchoff mesh mp dt fbar))

(defmethod update-stress-mp (mesh (mp cl-mpm/particle::particle-linear-elastic) dt fbar)
  (update-stress-linear mesh mp dt fbar))

(defgeneric post-stress-step (mesh mp dt)
  (:documentation "Mp dependent step called after full stress update"))
(defmethod post-stress-step (mesh (mp cl-mpm/particle::particle) dt)
  (declare (ignore mesh mp dt)))

(declaim (notinline reset-grid))
(defun reset-grid (mesh &key (reset-displacement t))
  "Reset all nodes on the grid"
  (declare (cl-mpm/mesh::mesh mesh))
  (iterate-over-nodes
   mesh
   (lambda (node)
     (when (cl-mpm/mesh:node-active node)
       (when reset-displacement
         (cl-mpm::fast-zero (cl-mpm/mesh::node-displacment node)))
       (cl-mpm/mesh:reset-node node)))))
(declaim (notinline reset-grid-velocity))
(defun reset-grid-velocity (mesh)
  "Reset all velocity map on grid for MUSL"
  (declare (cl-mpm/mesh::mesh mesh))
  (iterate-over-nodes
   mesh
   (lambda (node)
     (when (cl-mpm/mesh:node-active node)
       (cl-mpm/mesh::reset-node-velocity node)))))

(defun reset-grid-acceleration (mesh)
  "Reset all velocity map on grid for MUSL"
  (declare (cl-mpm/mesh::mesh mesh))
  (iterate-over-nodes
   mesh
   (lambda (node)
     (when (cl-mpm/mesh:node-active node)
       (cl-mpm/fastmaths:fast-zero (cl-mpm/mesh::node-acceleration node))))))

(defun zero-grid-velocity (mesh)
  "Reset all velocity map on grid for MUSL"
  (declare (cl-mpm/mesh::mesh mesh))
  (iterate-over-nodes
   mesh
   (lambda (node)
     (when (cl-mpm/mesh:node-active node)
       (cl-mpm/fastmaths::fast-zero (cl-mpm/mesh::node-velocity node))))))


(defun filter-grid (mesh mass-thresh)
  "Filter out nodes with very small massess"
  (declare (cl-mpm/mesh::mesh mesh) (double-float mass-thresh))
  (iterate-over-nodes
   mesh
   (lambda (node)
     (when (and (cl-mpm/mesh:node-active node)
                (<= (cl-mpm/mesh:node-mass node) mass-thresh))
       (cl-mpm/mesh:reset-node node)))))

(defun filter-grid-velocity (mesh mass-thresh)
  "Filter out nodes with very small massess"
  (declare (cl-mpm/mesh::mesh mesh) (double-float mass-thresh))
  (iterate-over-nodes
   mesh
   (lambda (node)
     (when (and (cl-mpm/mesh:node-active node)
                (<= (cl-mpm/mesh:node-mass node) mass-thresh))
       (cl-mpm/mesh::reset-node-velocity node)))))

(defun filter-grid-volume (mesh volume-ratio)
  (declare (cl-mpm/mesh::mesh mesh) (double-float volume-ratio))
  (let ((nodes (cl-mpm/mesh:mesh-nodes mesh)))
    (dotimes (i (array-total-size nodes))
      (let ((node (row-major-aref nodes i)))
        (when (and (cl-mpm/mesh:node-active node)
                   (< (the double-float (cl-mpm/mesh:node-mass node))
                      (* volume-ratio (the double-float (cl-mpm/mesh::node-volume-true node)))))
          (setf (cl-mpm/mesh::node-active node) nil)
          (cl-mpm/mesh:reset-node node)
          )))))

(defgeneric sim-add-mp (sim mp)
  (:documentation "A function to append an mp to a simulation"))

(defmethod sim-add-mp (sim mp)
  (with-accessors ((uid-counter sim-unique-index-counter)
                   (lock sim-unique-index-lock))
    sim
      (sb-thread:with-mutex (lock)
        (setf (cl-mpm/particle::mp-unique-index mp) uid-counter)
        (incf uid-counter))
    (vector-push-extend mp (cl-mpm:sim-mps sim))))

(defgeneric remove-mps-func (sim func)
  (:documentation "A function for removing mps from a sim"))

(defmethod remove-mps-func (sim func)
  (with-accessors ((mps cl-mpm:sim-mps))
      sim
    (declare ((vector cl-mpm/particle::particle) mps))
    (when (> (length mps) 0)
      ;; (delete-mps-func mps func)
      (setf mps
            (delete-if func mps)))
    ;;Sometimes when compacting the array; sbcl will just discard make and unadjustable array in place which is a bit wild
    (when (and (not (adjustable-array-p mps))
               (= (length mps) 0))
      (setf mps (make-array 0 :adjustable t :fill-pointer 0)))
    )
  (values))

(defun remove-material-damaged (sim)
  "Remove material points that have strain energy density exceeding fracture toughness"
  (with-accessors ((mps cl-mpm:sim-mps)
                   (mesh cl-mpm:sim-mesh)
                   (instant-damage-removal cl-mpm::sim-mp-damage-removal-instant)
                   (damage-crit cl-mpm::sim-mp-damage-removal-criteria))
      sim
    (let ((h (cl-mpm/mesh:mesh-resolution mesh))
          )
      (remove-mps-func
       sim
       (lambda (mp)
         (with-accessors ((damage cl-mpm/particle:mp-damage)
                          (def cl-mpm/particle::mp-deformation-gradient))
             mp
           (and (>= damage damage-crit)
                (or instant-damage-removal
                    (damage-removal-criteria mp h) )
                )))))
    ))

(defun damage-removal-criteria (mp h)
  "Some criteria for when we should remove fully damaged MPs"
  (with-accessors ((def cl-mpm/particle:mp-deformation-gradient)
                   (lens cl-mpm/particle::mp-domain-size)
                   (strain cl-mpm/particle::mp-strain)
                   (lens-0 cl-mpm/particle::mp-domain-size-0)
                   ;; (ft cl-mpm/particle::mp-initiation-stress)
                   ;; (ductility cl-mpm/particle::mp-ductility)
                   ;; (E cl-mpm/particle::mp-e)
                   )
      mp
    ;; (multiple-value-bind (l v) (cl-mpm/utils::eig (cl-mpm/utils:voigt-to-matrix strain)))
    (let* ((l-factor 2.00d0)
           ;; (e0 (/ ft E))
           ;; (ef (/ (* ft (+ ductility 1d0)) (* 2d0 E)))
           ;; (ef (* ef 50d0))
           ;; (e_max (reduce #' max l))
           )
      (cond
        ;; ((< ef e_max) :x)
        ;; ((< ef (tref strain 0 0)) :x)
        ;; ((< ef (tref strain 1 0)) :y)
        ;; ((< ef (tref strain 2 0)) :z)
        ((< (* l-factor (varef lens-0 0)) (varef lens 0)) :x)
        ((< (* l-factor (varef lens-0 1)) (varef lens 1)) :y)
        ;; ((and (< (* l-factor (tref lens-0 2 0)) (tref lens 2 0))
        ;;       (> (tref lens-0 2 0) 0d0)
        ;;       ) :z)
        (t nil)
        ))))

(defun split-criteria (mp h)
  "Some numerical splitting estimates"
  (with-accessors ((def cl-mpm/particle:mp-deformation-gradient)
                   (lens cl-mpm/particle::mp-domain-size)
                   (lens-0 cl-mpm/particle::mp-domain-size-0)
                   (split-depth cl-mpm/particle::mp-split-depth)
                   )
      mp
    (when t;(< split-depth *max-split-depth*)
      (let ((l-factor 1.00d0)
            (h-factor (* 0.55d0 h))
            (s-factor 1.5d0))
        (cond
          ((< h-factor (varef lens 0)) :x)
          ((< h-factor (varef lens 1)) :y)
          ((< h-factor (varef lens 2)) :z)
          ;; ((< (* l-factor (tref lens-0 0 0)) (tref lens 0 0)) :x)
          ;; ((< (* l-factor (tref lens-0 1 0)) (tref lens 1 0)) :y)
          ;; ((< (* l-factor (tref lens-0 2 0)) (tref lens 2 0)) :z)
          ;; ((< l-factor (/ (tref lens 0 0) (tref lens-0 0 0))) t)
          ;; ((< l-factor (/ (tref lens 1 0) (tref lens-0 1 0))) t)
                                        ;((< 2.0d0 (tref def 1 1)) t)
                                        ;((> 1.5d0 (tref def 0 0)) t)
          (t nil)
          )))))

(defun single-particle-criteria (mesh mp)
  "Criteria for checking if material point is unconnected to another MP"
  ;; (let ((svp-sum 0d0)
  ;;       (alone t))
  ;;   (iterate-over-neighbours
  ;;     mesh mp
  ;;     (lambda (node svp grads fsvp fgrads)
  ;;       (declare
  ;;         (cl-mpm/mesh::node node)
  ;;         (cl-mpm/particle:particle mp)
  ;;         (type double-float svp))
  ;;       (with-accessors ((node-svp cl-mpm/mesh::node-svp-sum)
  ;;                        (node-active cl-mpm/mesh:node-active)
  ;;                        ) node
  ;;         (when node-active
  ;;           (incf svp-sum node-svp)))))
  ;;   (and (< svp-sum 2d0) (not (= svp-sum 0d0)))
  ;;   ;; (setf alone t)
  ;;   ;; alone
  ;;   )
  nil
  )
(defun gimp-removal-criteria (mp h)
  "Criteria for removal of gimp mps based on domain length"
  (with-accessors ((lens cl-mpm/particle::mp-domain-size))
      mp
    (declare (double-float h))
    (let ((h-factor h)
          (aspect 0.1d0)
          (l-max nil)
          (l-min nil))
      (loop for i from 0 to 2
            do
            (let ((l (varef lens i)))
              (when (> l 0d0)
                (when (or (not l-max) (and (> l l-max)))
                  (setf l-max l))
                (when (or (not l-min) (and (< l l-min)))
                  (setf l-min l)))))
      (cond
        ((< h-factor (the double-float (varef lens 0))) :x)
        ((< h-factor (the double-float (varef lens 1))) :y)
        ((< h-factor (the double-float (varef lens 2))) :z)
        ((and l-min l-max (< l-min (* l-max aspect))) :xy)
        ;; ((= (the double-float (varef lens 0)) 0d0) :x)
        ;; ((= (the double-float (varef lens 1)) 0d0) :y)
        ;; ((= (the double-float (varef lens 2)) 0d0) :z)
        ;; ((> aspect (/ (the double-float (varef lens 0))
        ;;               (the double-float (varef lens 1))
        ;;               )) :x)
        ;; ((> aspect (/ (the double-float (varef lens 1))
        ;;               (the double-float (varef lens 0))
        ;;               )) :x)
        (t nil)
        ))))

(defgeneric calculate-min-dt-mps (sim)
  (:documentation "A function for calculating an approximate stable timestep based on MPs"))
(defmethod calculate-min-dt-mps ((sim mpm-sim))
  "Estimate minimum p-wave modulus"
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (mass-scale cl-mpm::sim-mass-scale))
      sim
    (let ((inner-factor most-positive-double-float)
          (h (cl-mpm/mesh:mesh-resolution mesh)))
      (declare (double-float inner-factor mass-scale))
      (setf inner-factor
            (reduce-over-nodes
             mesh
             (lambda (node)
               (if (and (cl-mpm/mesh::node-active node)
                        (or (not (cl-mpm/mesh::node-agg node))
                            (cl-mpm/mesh::node-interior node)))
                   (with-accessors ((node-active  cl-mpm/mesh:node-active)
                                    (pmod cl-mpm/mesh::node-pwave)
                                    (mass cl-mpm/mesh::node-mass)
                                    (svp-sum cl-mpm/mesh::node-svp-sum)
                                    (vol cl-mpm/mesh::node-volume)
                                    (vel cl-mpm/mesh::node-velocity)
                                    ) node
                     (if (and (> vol 0d0)
                              (> pmod 0d0)
                              (> svp-sum 0d0))
                         (let ((nf (/ mass pmod)))
                           nf
                           ;; (* (abs
                           ;;     (/ (cl-mpm/mesh::node-volume node)
                           ;;        (cl-mpm/mesh::node-volume-true node)))
                           ;;    nf)
                           ;; (break)
                           )
                         ;; (let ((nf (/ mass (* (expt h 2) (+ (/ pmod svp-sum))))))
                         ;;   nf)
                         most-positive-double-float))
                   most-positive-double-float))
             #'min))
      (if (< inner-factor most-positive-double-float)
          (* (sqrt mass-scale) (sqrt inner-factor) h)
          (cl-mpm:sim-dt sim)))))

(defgeneric calculate-min-dt-bcs (sim))
(defmethod calculate-min-dt-bcs (sim)
  (let ((min-dt nil))
    (cl-mpm::iterate-over-bcs-force-serial
     sim
     (lambda (bc)
       (let ((dt-req (cl-mpm/bc::calculate-min-dt-bc sim bc)))
         (when (and
                dt-req
                (if min-dt
                 (< dt-req min-dt)
                 t))
           (setf min-dt dt-req)))))
    (if min-dt
        min-dt
        sb-ext::most-positive-double-float)))


(defgeneric calculate-min-dt (sim)
  (:documentation "A function for calculating an approximate stable timestep"))
(defmethod calculate-min-dt ((sim mpm-sim))
  ;; (let ((dt-req (calculate-min-dt-mps sim)))
  ;;   (let ((bc-min-dt (calculate-min-dt-bcs sim)))
  ;;     (when bc-min-dt
  ;;       (setf dt-req (min dt-req bc-min-dt))))
  ;;   dt-req)
  (min
   (calculate-min-dt-bcs sim)
   (calculate-min-dt-mps sim)))

(defun calculate-adaptive-time (sim target-time &key (dt-scale 1d0))
  "Given that the system has previously been mapped to, caluclate an estimated dt and substep for a given target time
The value dt-scale allows for the estimated dt to be scaled up or down
This modifies the dt of the simulation in the process
"
  (let* ((dt-e (* dt-scale (calculate-min-dt sim)))
         (substeps-e (floor target-time dt-e)))
    ;; (format t "CFL dt estimate: ~f~%" dt-e)
    ;; (format t "CFL step count estimate: ~D~%" substeps-e)
    (setf (cl-mpm:sim-dt sim) dt-e)
    ;; (setf substeps substeps-e)
    (values dt-e substeps-e)
    )
  )


(defgeneric add-mps (sim mps-array))
(defmethod add-mps (sim mps-array)
  (with-accessors ((mps cl-mpm:sim-mps))
      sim
      (if (> (length mps) 0)
          (progn
            (loop for mp across mps-array
                  do (sim-add-mp sim mp)))
          (progn
            (setf (cl-mpm:sim-mps sim) (make-array (length mps-array) :adjustable t :fill-pointer 0))
            (loop for mp across mps-array
                  do (sim-add-mp sim mp))))))

(defun add-bcs (sim new-bcs)
  "Add nodal essential bcs"
  (with-accessors ((bcs cl-mpm:sim-bcs))
      sim
    (typecase new-bcs
      (array
       (if (> (length bcs) 0)
           (progn
             (loop for bc across new-bcs
                   do (vector-push-extend bc bcs)))
           (setf bcs new-bcs)))
      (cl-mpm/bc::bc
       (vector-push-extend new-bcs bcs)))))
(defun add-bcs-force-list (sim new-bcs)
  "Add bcs that apply forces, ordered in a FILO"
  (with-accessors ((bcs-force-list cl-mpm:sim-bcs-force-list))
      sim
    ;; (when (= (length bcs-force-list 0)))
    (typecase new-bcs
      (list
       ;;Common case, we have a list, or arrays of BCs, running bcs in serial down the list, but in parrallel over the array
       (setf bcs-force-list (nconc new-bcs bcs-force-list)))
      (array
       ;;We have an array of bcs, that we want to add to the list -> add it to the back in its own list
       (setf bcs-force-list (nconc (list new-bcs) bcs-force-list)))
      (cl-mpm/bc::bc
       ;;Uncommon case we have a singluar bc we wish to add, so double wrap it
       (setf bcs-force-list (nconc (list (cl-mpm/bc:make-bcs-from-list (list new-bcs))) bcs-force-list)))
      (t (error "BCs must be a list, array or singluar bc")))))

(defun get-mp (sim index)
  (aref (sim-mps sim) index))



(defgeneric update-dynamic-stats (sim))
(defmethod update-dynamic-stats (sim))

(defmethod update-node-forces ((sim mpm-sim-sd))
  (with-accessors ((damping sim-damping-factor)
                   (mass-scale sim-mass-scale)
                   (mesh sim-mesh)
                   (mesh-p sim-mesh-p)
                   (dt sim-dt))
      sim
    (iterate-over-nodes
     mesh
     (lambda (node)
       (when (cl-mpm/mesh:node-active node)
         (calculate-forces node damping dt mass-scale))))))


(defgeneric finalise-loadstep (sim)
  )
(defmethod finalise-loadstep ((sim mpm-sim))
  ;;Standard MPM do not need to do anything fancy for finalisation as we set each step as a new loadstep anyway
  ;; (incf (sim-time sim) (cl-mpm:sim-dt sim))
  )

(defgeneric reset-loadstep (sim)
  )
(defmethod reset-loadstep ((sim mpm-sim))
  (cl-mpm:iterate-over-mps
   (cl-mpm:sim-mps sim)
   (lambda (mp)
     (cl-mpm/particle::reset-loadstep-mp mp)))
  ;; (when (cl-mpm::sim-allow-mp-split sim)
  ;;   (split-mps sim))
  ;; (check-mps sim)
  (reset-node-displacement sim)
  (reset-grid-velocity (cl-mpm:sim-mesh sim)))

(defgeneric new-loadstep (sim)
  )

(defun reset-node-displacement (sim)
  (cl-mpm::iterate-over-cells
   (cl-mpm:sim-mesh sim)
   (lambda (cell)
     (cl-mpm/fastmaths:fast-zero (cl-mpm/mesh::cell-displacement cell))))
  (cl-mpm:iterate-over-nodes
   (cl-mpm:sim-mesh sim)
   (lambda (node)
     (cl-mpm/fastmaths:fast-zero (cl-mpm/mesh::node-displacment node)))))

(defmethod new-loadstep ((sim mpm-sim))
  (update-particles sim)
  (cl-mpm::iterate-over-mps
   (cl-mpm:sim-mps sim)
   (lambda (mp)
     (cl-mpm/particle::new-loadstep-mp mp)))
  (when (cl-mpm::sim-allow-mp-split sim)
    (split-mps sim))
  (check-mps sim)
  ;; (check-single-mps sim)
  ;; (cl-mpm/ghost::reset-ghost-cache sim)
  ;; (reset-node-displacement sim)
  )

(defun gradient-push-forwards (grads df)
  (let* ((df-inv (cl-mpm/fastmaths::fast-inv-3x3 df)))
    (let ((dx (cl-mpm/utils::gradients-dx grads))
          (dy (cl-mpm/utils::gradients-dy grads))
          (dz (cl-mpm/utils::gradients-dz grads)))
      (declare (double-float dx dy dz))
      (let ((x (+ (* dx (mtref df-inv 0 0))
                  (* dy (mtref df-inv 1 0))
                  (* dz (mtref df-inv 2 0))))
            (y
              (+ (* dx (mtref df-inv 0 1))
                 (* dy (mtref df-inv 1 1))
                 (* dz (mtref df-inv 2 1)))
              )
            (z
              (+ (* dx (mtref df-inv 0 2))
                 (* dy (mtref df-inv 1 2))
                 (* dz (mtref df-inv 2 2))))
            )
        (cl-mpm/utils::make-gradients x y z)))))

(declaim (inline UL-push-cached)
         (ftype (function (double-float double-float double-float
                                        magicl::matrix/double-float
                                        fixnum
                                        )
                          double-float
                          )
                UL-push-cached))
(defun UL-push-cached (dx dy dz df-inv nd)
  (declare (double-float dx dy dz))
  (let ((x
          (the double-float
               (expt
                (the double-float
                     (+ (the double-float (* dx (cl-mpm/utils::mtref-3x3 df-inv 0 0)))
                        (the double-float (* dy (cl-mpm/utils::mtref-3x3 df-inv 1 0)))
                        (the double-float (* dz (cl-mpm/utils::mtref-3x3 df-inv 2 0)))))
                2)))
        (y
          (the double-float
               (expt
                (the double-float
                     (+ (the double-float (* dx (cl-mpm/utils::mtref-3x3 df-inv 0 1)))
                        (the double-float (* dy (cl-mpm/utils::mtref-3x3 df-inv 1 1)))
                        (the double-float (* dz (cl-mpm/utils::mtref-3x3 df-inv 2 1)))))
                2)))
        (z
          (the double-float
               (expt
                (the double-float
                     (+ (the double-float (* dx (cl-mpm/utils::mtref-3x3 df-inv 0 2)))
                        (the double-float (* dy (cl-mpm/utils::mtref-3x3 df-inv 1 2)))
                        (the double-float (* dz (cl-mpm/utils::mtref-3x3 df-inv 2 2)))))
                2))))
    (ecase nd
      (1 (* 2d0 x))
      (2 (max x y))
      (3 (max x y z)))))

(defun gradient-push-forwards-cached (grads df-inv)
  ;; Correct
  (let ((dx (cl-mpm/utils::gradients-dx grads))
        (dy (cl-mpm/utils::gradients-dy grads))
        (dz (cl-mpm/utils::gradients-dz grads)))
    (declare (double-float dx dy dz))
    (let ((x (+ (* dx (mtref df-inv 0 0))
                (* dy (mtref df-inv 1 0))
                (* dz (mtref df-inv 2 0))))
          (y
            (+ (* dx (mtref df-inv 0 1))
               (* dy (mtref df-inv 1 1))
               (* dz (mtref df-inv 2 1)))
            )
          (z
            (+ (* dx (mtref df-inv 0 2))
               (* dy (mtref df-inv 1 2))
               (* dz (mtref df-inv 2 2)))))
      (cl-mpm/utils::make-gradients x y z))))

(defun update-stiffness-mps (sim)
  (cl-mpm:iterate-over-mps
   (cl-mpm:sim-mps sim)
   (lambda (mp)
     (setf (cl-mpm/particle::mp-p-modulus mp) (cl-mpm/particle::estimate-stiffness mp)))))

(defun filter-nodes (sim filter)
  (let ((nodes (cl-mpm/mesh::mesh-nodes (cl-mpm:sim-mesh sim))))
    ;; (remove-if-not filter (make-array (array-total-size nodes) :displaced-to nodes))
    (lparallel:premove-if-not filter (make-array (array-total-size nodes) :displaced-to nodes))))

(defun filter-array-cells (sim filter)
  (let ((nodes (cl-mpm/mesh::mesh-cells (cl-mpm:sim-mesh sim))))
    (lparallel:premove-if-not filter (make-array (array-total-size nodes) :displaced-to nodes))))

(defun filter-bcs (sim filter)
  (let ((nodes (cl-mpm:sim-bcs sim)))
    (lparallel:premove-if-not filter nodes)))

(defun morton-to-index-2d (id)
  (let ((x 0)
        (y 0))
    (loop for b from 0 to 16
          do (progn
               (incf x (if (logbitp (* 2 b) id)      (expt 2 b) 0))
               (incf y (if (logbitp (1+ (* 2 b)) id) (expt 2 b) 0))))
    (list x y 0)))
(defun morton-to-index-3d (id)
  (let ((x 0)
        (y 0)
        (z 0))
    (loop for b from 0 to 10
          do (progn
               (incf x (if (logbitp (* 3 b) id) (expt 2 b) 0))
               (incf y (if (logbitp (+ 1 (* 3 b)) id) (expt 2 b) 0))
               (incf z (if (logbitp (+ 2 (* 3 b)) id) (expt 2 b) 0))
               ))
    (list x y z)))
(defun morton-to-index (id nD)
  (ecase nd
    (1 (list id 0 0))
    (2 (morton-to-index-2d id))
    (3 (morton-to-index-3d id))))


(defun domain-sort-mps (sim)
  (let ((mesh (cl-mpm:sim-mesh sim)))
    (let* ((node-count (array-total-size (cl-mpm/mesh::mesh-nodes mesh)))
           (node-mp-list (make-array node-count :initial-contents (loop repeat node-count collect nil))))
      (cl-mpm:iterate-over-mps
       (cl-mpm:sim-mps sim)
       (lambda (mp)
         (let ((index (cl-mpm/mesh::position-to-index-round mesh (cl-mpm/particle:mp-position mp))))
           (if (cl-mpm/mesh::in-bounds mesh index)
               (sb-thread::with-mutex ((cl-mpm/mesh::node-lock (cl-mpm/mesh:get-node mesh index)))
                 (let ((id (cl-mpm/mesh::index-to-id mesh index)))
                   (if (aref node-mp-list id)
                       (vector-push-extend mp (aref node-mp-list id))
                       (setf (aref node-mp-list id) (make-array 1 :initial-element mp :adjustable t :fill-pointer 1)))))
               (error "MP out of bounds during domain sort ~A ~A~%" mp index)))))
      (let ((sorted-mps (make-array (length (cl-mpm:sim-mps sim)) :adjustable t :fill-pointer 0))
            (nd (cl-mpm/mesh:mesh-nD mesh))
            (new-id 0))
        (loop for i from 0 to (round (expt
                                      (expt 2 (+ 0
                                                 (ceiling
                                                  (log (reduce #'max (cl-mpm/mesh::mesh-count mesh)) 2)))) nd))
              do
                 (let ((trial-index (morton-to-index i nd)))
                   (when (cl-mpm/mesh::in-bounds mesh trial-index)
                     (let ((id (cl-mpm/mesh::index-to-id mesh trial-index)))
                       (when (aref node-mp-list id)
                         (loop for mp across (aref node-mp-list id)
                               do (progn (vector-push-extend mp sorted-mps)
                                         (setf (cl-mpm/particle::mp-index mp) new-id)
                                         (incf new-id))))))))

        (setf (cl-mpm::sim-mps sim) sorted-mps)))))

(defun reset-mesh-active (sim)
  (let ((mesh (sim-mesh sim)))
    (setf (cl-mpm/mesh::mesh-active-nodes mesh)
          (make-array (array-total-size (cl-mpm/mesh::mesh-nodes mesh))
                      :element-type 'cl-mpm/mesh::node
                      :displaced-to (cl-mpm/mesh::mesh-nodes mesh)))))

(defun compact-mesh-active (sim)
  (when nil
    (reset-mesh-active sim)
    (let* ((mesh (sim-mesh sim))
           (node-active (filter-nodes sim #'cl-mpm/mesh:node-active))
           (nodes-sorted (make-array (length node-active) :fill-pointer 0)))
      (let ((nd (cl-mpm/mesh:mesh-nD mesh))
            (id 0))
        (loop for i from 0 to (round (expt (expt 2 (+ 0 (ceiling (log (reduce #'max (cl-mpm/mesh::mesh-count mesh)) 2)))) nd))
              do
                 (let ((trial-index (morton-to-index i nd)))
                   (when (cl-mpm/mesh::in-bounds mesh trial-index)
                     ;; (setf (aref nodes-sorted id) (cl-mpm/mesh::get-node mesh trial-index))
                     (vector-push-extend (cl-mpm/mesh::get-node mesh trial-index) nodes-sorted)
                     (incf id))))
        )
      (setf (cl-mpm/mesh::mesh-active-nodes mesh)
            nodes-sorted))))
