;; (defpackage :cl-mpm/models/plastic
;;   (:use :cl
;;    :cl-mpm/utils)
;;   (:export
;;    )
;;   )
;; (in-package :cl-mpm/models/plastic)
(in-package :cl-mpm/particle)
(declaim #.cl-mpm/settings:*optimise-setting*)

(defclass particle-plastic (particle)
  ((enable-plasticity
    :accessor mp-enable-plasticity
    :initarg :enable-plasticity
    :initform t
    )
   (strain-plastic-vm-1
    :accessor mp-strain-plastic-vm-1
    :type DOUBLE-FLOAT
    :initform 0d0)
   (strain-plastic-vm
    :accessor mp-strain-plastic-vm
    :type DOUBLE-FLOAT
    :initform 0d0)
   (strain-plastic-vm-inc
    :accessor mp-strain-plastic-vm-inc
    :type DOUBLE-FLOAT
    :initform 0d0)
   (strain-plastic
    :accessor mp-strain-plastic
    :type MAGICL:MATRIX/DOUBLE-FLOAT
    :initarg :strain-plastic
    :initform (cl-mpm/utils:voigt-zeros))
   (yield-func
    :accessor mp-yield-func
    :type double-float
    :initform 0d0)
   (softening
    :accessor mp-softening
    :initarg :softening
    :initform 0d0)
   (plastic-iterations
    :accessor mp-plastic-iterations
    :initform 0)))

(defclass particle-vm (particle-elastic particle-plastic)
  ((rho
    :accessor mp-rho
    :initarg :rho
    )
   (rho-0
    :accessor mp-rho-0
    :initarg :rho
    )
   (rho-r
    :accessor mp-rho-r
    :initarg :rho-r
    )
   (yield-func
    :accessor mp-yield-func
    :type double-float
    :initform 0d0))
  (:documentation "A vm perfectly plastic material point"))

(defclass particle-vm-implicit (particle-vm)
  ()
  (:documentation "A vm perfectly plastic material point, except stores the algorithmic tangent"))

(defclass particle-vm-hardening (particle-vm)
  ()
  (:documentation "A VM plastic material point, with a secant hardening/softening algorithm"))

(defclass particle-mc (particle-elastic particle-plastic)
  ((phi
    :accessor mp-phi
    :initarg :phi
    :initform 0d0
    )
   (psi
    :accessor mp-psi
    :initarg :psi
    :initform 0d0
    )
   (c
    :accessor mp-c
    :initarg :c
    :initform 0d0
    )
   (phi-0
    :accessor mp-phi-0
    :initarg :phi
    :initform 0d0
    )
   (psi-0
    :accessor mp-psi-0
    :initarg :psi
    :initform 0d0
    )
   (c-0
    :accessor mp-c-0
    :initarg :c
    :initform 0d0
    )
   (phi-r
    :accessor mp-phi-r
    :initarg :phi-r
    :initform 0d0
    )
   (psi-r
    :accessor mp-psi-r
    :initarg :psi-r
    :initform 0d0
    )
   (c-r
    :accessor mp-c-r
    :initarg :c-r
    :initform 0d0
    )
   )

  (:documentation "A mohr-coloumb perfectly plastic material point"))

(defclass particle-dp (particle-mc)
  ())

(defmethod constitutive-model ((mp particle-vm) strain dt)
  "Strain intergrated elsewhere, just using elastic tensor"
  (with-accessors ((de mp-elastic-matrix)
                   (dep mp-tangent-stiffness)
                   (stress mp-stress)
                   (rho mp-rho)
                   (soft mp-softening)
                   (plastic-strain mp-strain-plastic)
                   (ps-vm mp-strain-plastic-vm)
                   (ps-vm-1 mp-strain-plastic-vm-1)
                   (ps-vm-inc mp-strain-plastic-vm-inc)
                   (strain mp-strain)
                   (strain-n mp-strain-n)
                   (yield-func mp-yield-func)
                   (def mp-deformation-gradient)
                   (p-mod mp-p-modulus-0)
                   (E mp-e)
                   (nu mp-nu)
                   (enable-plasticity mp-enable-plasticity))
      mp
    (declare (double-float soft))
    ;;Train elastic strain - plus trail kirchoff stress
    (cl-mpm/constitutive::linear-elastic-mat strain de stress)
    (setf p-mod (cl-mpm/particle::compute-p-modulus mp))
    ;; (setf dep de)
    (when enable-plasticity
      (progn
        (multiple-value-bind (sig eps-e f inc pmod) (cl-mpm/ext::constitutive-vm stress strain de e nu rho)
          (declare (double-float f inc pmod ps-vm-1 ps-vm-inc))
          (setf stress sig
                ;; plastic-strain (cl-mpm/fastmaths:fast-.- strain eps-e plastic-strain)
                p-mod pmod
                yield-func f)
          (setf ps-vm-inc inc)
          (setf strain eps-e)
          (setf ps-vm (+ ps-vm-1 ps-vm-inc))
          ))
      )
    (when (> soft 0d0)
      (with-accessors ((rho-r mp-rho-r)
                       (rho-0 mp-rho-0))
          mp
        (declare (double-float rho-0 rho-r))
        (setf
         rho (+ rho-r (* (- rho-0 rho-r) (exp (- (* soft ps-vm))))))))
    stress))

(defmethod constitutive-model ((mp particle-vm-hardening) strain dt)
  "Strain intergrated elsewhere, just using elastic tensor"
  (with-accessors ((de mp-elastic-matrix)
                   (dep mp-tangent-stiffness)
                   (stress mp-stress)
                   (rho mp-rho)
                   (soft mp-softening)
                   (plastic-strain mp-strain-plastic)
                   (ps-vm mp-strain-plastic-vm)
                   (ps-vm-1 mp-strain-plastic-vm-1)
                   (ps-vm-inc mp-strain-plastic-vm-inc)
                   (strain mp-strain)
                   (strain-n mp-strain-n)
                   (yield-func mp-yield-func)
                   (def mp-deformation-gradient)
                   (p-mod mp-p-modulus-0)
                   (E mp-e)
                   (nu mp-nu)
                   (rho-r mp-rho-r)
                   (rho-0 mp-rho-0)
                   (enable-plasticity mp-enable-plasticity))
      mp
    (declare (double-float soft))
    ;;Train elastic strain - plus trail kirchoff stress
    (cl-mpm/constitutive::linear-elastic-mat strain de stress)
    (setf p-mod (cl-mpm/particle::compute-p-modulus mp))
    ;; (setf dep de)
    (when enable-plasticity
      (let ((new-stress (cl-mpm/utils:voigt-zeros))
            (new-strain (cl-mpm/utils:voigt-zeros)))
        (labels ((plastic (plastic-vm)
                   ;; (setf
                   ;;  rho (+ rho-r (* (- rho-0 rho-r) (exp (- (* soft plastic-vm))))))
                   (setf
                    rho (+ rho-0 (* soft plastic-vm)))
                   (cl-mpm/utils:voigt-copy-into stress new-stress)
                   (cl-mpm/utils:voigt-copy-into strain new-strain)
                   (multiple-value-bind (sig eps-e f inc pmod)
                       (cl-mpm/ext::constitutive-vm
                        new-stress
                        new-strain
                        de e nu rho)
                     (setf
                      new-stress sig
                      new-strain eps-e
                      p-mod pmod
                      yield-func f
                      ps-vm-inc inc
                      ps-vm (+ ps-vm-1 inc))
                     inc)))
          (cl-mpm/constitutive::secant-hardening
           #'plastic
           ps-vm-1
           #'identity))
        (cl-mpm/utils::voigt-copy-into new-stress stress)
        (cl-mpm/utils::voigt-copy-into new-strain strain))

      ;; (progn
      ;;   (multiple-value-bind (sig eps-e f inc pmod) (cl-mpm/ext::constitutive-vm stress strain de e nu rho)
      ;;     (declare (double-float f inc pmod ps-vm-1 ps-vm-inc))
      ;;     (setf stress sig
      ;;           ;; plastic-strain (cl-mpm/fastmaths:fast-.- strain eps-e plastic-strain)
      ;;           p-mod pmod
      ;;           yield-func f)
      ;;     (setf ps-vm-inc inc)
      ;;     (setf strain eps-e)
      ;;     (setf ps-vm (+ ps-vm-1 ps-vm-inc))
      ;;     ))
      )
    stress))

(defun diff-tangent (func strain)
  (let ())
  (let ((stress-0 (funcall func (voigt-copy strain)))
        (de (cl-mpm/utils::tensor-voigt-4th-zeros))
        (eps 1d-9))
    (loop for i from 0 below 6
          do (loop for j from 0 below 6
                   do (labels ((probe (eps)
                                 (let ((tstrain (cl-mpm/utils::voigt-copy strain)))
                                   (incf (varef tstrain j) eps)
                                   (let ((stress (funcall func tstrain)))
                                     (- (varef stress-0 i) (varef stress i))))))
                        (setf (mtref de i j)
                              (/ (- (probe eps) (probe (- eps)))
                                 (* -2 eps))))))
    (let ((mapping-list (list 0 1 2 5 3 4))
          ;;Potentially corrected listing?
          ;; (mapping-list (list 0 1 2 5 5 3 3 4 4))
          (result (cl-mpm/utils::arb-matrix 9 9)))
      (loop for i from 0
            for im in mapping-list
            do
               (loop for j from 0
                     for jm in mapping-list
                     do (setf (magicl:tref result i j) (magicl:tref de im jm))))
      result)
    de))


(defmethod constitutive-model ((mp particle-vm-implicit) strain-in dt)
  "Strain intergrated elsewhere, just using elastic tensor"
  (with-accessors ((de mp-elastic-matrix)
                   (dep mp-tangent-stiffness)
                   (stress mp-stress-kirchoff)
                   (rho mp-rho)
                   (soft mp-softening)
                   (plastic-strain mp-strain-plastic)
                   (ps-vm mp-strain-plastic-vm)
                   (ps-vm-1 mp-strain-plastic-vm-1)
                   (ps-vm-inc mp-strain-plastic-vm-inc)
                   (strain mp-strain)
                   (strain-n mp-strain-n)
                   (yield-func mp-yield-func)
                   (def mp-deformation-gradient)
                   (p-mod mp-p-modulus-0)
                   (E mp-e)
                   (nu mp-nu)
                   (enable-plasticity mp-enable-plasticity))
      mp
    ;;Train elastic strain - plus trail kirchoff stress
    (cl-mpm/constitutive::linear-elastic-mat strain de stress)
    (if (equal dep de)
      (setf dep (cl-mpm/utils::deep-copy de))
      (cl-mpm/utils::copy-into de dep))
    (setf p-mod (cl-mpm/particle::compute-p-modulus mp))
    (if enable-plasticity
        (multiple-value-bind (sig eps-e f inc pmod) (cl-mpm/ext::constitutive-vm-tangent
                                                     stress
                                                     strain
                                                     de
                                                     e nu
                                                     rho
                                                     dep)
          (setf stress sig
                ;; plastic-strain (cl-mpm/fastmaths:fast-.- strain eps-e plastic-strain)
                p-mod pmod
                yield-func f)
          (let ((p-mod-elastic (* 1d-6 (cl-mpm/particle::compute-p-modulus mp)))
                (probe-vec (cl-mpm/utils::voigt-zeros)))
            (setf pmod p-mod-elastic)
            (loop for d from 0 below 2
                  do (progn
                       (setf p-mod
                             (max p-mod
                                  (cl-mpm/utils:varef (cl-mpm/fastmaths::fast-@-tensor-voigt dep probe-vec)
                                                      d))))))
          (setf ps-vm-inc inc)
          (setf strain eps-e)
          (setf ps-vm (+ ps-vm-1 ps-vm-inc)))
      (progn
        ;; (setf p-mod (cl-mpm/particle::compute-p-modulus mp))
        ))
    stress))

(defmethod constitutive-model ((mp particle-mc) strain dt)
  "Strain intergrated elsewhere, just using elastic tensor"
  (with-accessors ((de mp-elastic-matrix)
                   (stress mp-stress)
                   (E mp-E)
                   (nu mp-nu)
                   (phi mp-phi)
                   (psi mp-psi)
                   (c mp-c)
                   (plastic-strain mp-strain-plastic)
                   (ps-vm mp-strain-plastic-vm)
                   (ps-vm-1 mp-strain-plastic-vm-1)
                   (ps-vm-inc mp-strain-plastic-vm-inc)
                   (strain mp-strain)
                   (yield-func mp-yield-func)
                   (soft mp-softening)
                   (p-mod mp-p-modulus)
                   (def mp-deformation-gradient)
                   (enabled mp-enable-plasticity)
                   (p-wave-0 cl-mpm/particle::mp-p-modulus-0)
                   )
      mp
    (declare (double-float soft ps-vm ps-vm-1 ps-vm-inc E nu phi psi c))
    ;;Train elastic strain - plus trail kirchoff stress

    ;; (setf p-mod
    ;;       (* (expt (cl-mpm/fastmaths::det def) -2)
    ;;                (cl-mpm/particle::compute-p-modulus mp)))
    (setf p-wave-0 (cl-mpm/particle::compute-p-modulus mp))
    (setf stress (cl-mpm/constitutive::linear-elastic-mat strain de stress))
    (when enabled
      (let ((f-r t)
            (ps-inc-i 0d0))
        (loop for i from 0 to 0;to 50
              while (and f-r
                         ;; (if (= ps-inc-i 0d0)
                         ;;     t
                         ;;     (/ (abs (- ps-vm-inc ps-inc-i)) ps-inc-i))
                         )
              do
                 (progn
                   (setf ps-inc-i ps-vm-inc)
                   (multiple-value-bind (sig eps-e f inc pmod)
                       (cl-mpm/ext::constitutive-mohr-coulomb stress
                                                              de
                                                              strain
                                                              E
                                                              nu
                                                              phi
                                                              psi
                                                              c)
                       ;; (cl-mpm/constitutive::mc-plastic stress
                       ;;                                 de
                       ;;                                 strain
                       ;;                                 E
                       ;;                                 nu
                       ;;                                 phi
                       ;;                                 psi
                       ;;                                 c)
                     (declare (double-float f inc))
                     (setf f-r (> f 1d-5))
                     (setf
                      stress sig
                      strain eps-e
                      yield-func f
                      p-wave-0 pmod)
                     (setf ps-vm-inc inc)
                     (setf ps-vm (+ ps-vm-1 inc)))
                   (setf (mp-plastic-iterations mp) i)
                   ;; (let ((K (/ e (* 3 (- 1d0 (* 2 nu)))))
                   ;;       (G (/ e (* 2 (+ 1d0 nu)))))
                   ;;   (declare (double-float K G p-mod))
                   ;;   (when (> (cl-mpm/particle::mp-yield-func mp) 0d0)
                   ;;     (setf K (* K (cos (cl-mpm/particle::mp-phi mp))))
                   ;;     (setf G (* G (sin (cl-mpm/particle::mp-phi mp))))
                   ;;     (setf p-wave-0 (* (+ K (* 4/3 G))))))
                   (when soft
                     (unless (= soft 0d0)
                       (with-accessors ((c-0 mp-c-0)
                                        (phi-0 mp-phi-0)
                                        (psi-0 mp-psi-0)
                                        (c-r mp-c-r)
                                        (phi-r mp-phi-r)
                                        (psi-r mp-psi-r))
                           mp
                         (declare (double-float c-0 c-r phi-0 phi-r psi-0 psi-r))
                         (setf
                          c (+ c-r (* (- c-0 c-r) (exp (- (* soft ps-vm)))))
                          phi (atan (+ (tan phi-r) (* (- (tan phi-0) (tan phi-r)) (exp (- (* soft ps-vm))))))))
                       ))))))
    ;; (cl-mpm/particle::update-p-modulus mp)
    stress))

(defmethod cl-mpm/particle::reset-loadstep-mp ((mp particle-plastic))
  (with-accessors ((ps-vm-1 mp-strain-plastic-vm-1)
                   (ps-vm mp-strain-plastic-vm)
                   )
      mp
    (declare (double-float ps-vm ps-vm-1))
    (setf ps-vm ps-vm-1))
  (call-next-method))
(defmethod cl-mpm/particle::new-loadstep-mp ((mp particle-plastic))
  (with-accessors ((ps-vm-1 mp-strain-plastic-vm-1)
                   (ps-vm-inc mp-strain-plastic-vm-inc)
                   (ps-vm mp-strain-plastic-vm)
                   )
      mp
    (declare (double-float ps-vm ps-vm-1 ps-vm-inc))
    (setf ps-vm-1 ps-vm))
  (call-next-method))


(defmethod constitutive-model ((mp particle-dp) strain dt)
  "Strain intergrated elsewhere, just using elastic tensor"
  (with-accessors ((de mp-elastic-matrix)
                   (stress mp-stress)
                   (E mp-E)
                   (nu mp-nu)
                   (p-mod mp-p-modulus)
                   (def mp-deformation-gradient)
                   (phi mp-phi)
                   (psi mp-psi)
                   (c mp-c)
                   (plastic-strain mp-strain-plastic)
                   (ps-vm mp-strain-plastic-vm)
                   (strain mp-strain)
                   (yield-func mp-yield-func)
                   (soft mp-softening)
                   (enabled mp-enable-plasticity)
                   )
      mp
    (declare (double-float soft ps-vm E nu phi psi c))
    ;;Train elastic strain - plus trail kirchoff stress
    (cl-mpm/constitutive::linear-elastic-mat strain de stress)
    (when enabled
      (multiple-value-bind (sig eps-e f yield)
          (cl-mpm/constitutive::plastic-dp stress de strain E nu phi psi c)
          ;; (cl-mpm/ext::constitutive-drucker-prager strain de E nu phi psi c)
        (if yield
            (progn
              (setf stress sig
                    plastic-strain (cl-mpm/fastmaths:fast-.- strain eps-e)
                    yield-func f
                    )
              (setf strain eps-e))
          (progn
            (cl-mpm/fastmaths:fast-zero plastic-strain)
            (setf yield-func 0d0))))
      (incf ps-vm
            (multiple-value-bind (l v)
                (cl-mpm/utils:eig (cl-mpm/utils:voigt-to-matrix (cl-mpm/particle::mp-strain-plastic mp)))
              (destructuring-bind (s1 s2 s3) l
                (sqrt
                 (/ (+ (expt (- s1 s2) 2d0)
                       (expt (- s2 s3) 2d0)
                       (expt (- s3 s1) 2d0)
                       ) 2d0))))))
    (let ((K (/ e (* 3 (- 1d0 (* 2 nu)))))
          (G (/ e (* 2 (+ 1d0 nu)))))
      (declare (double-float K G p-mod))
      (when (> (cl-mpm/particle::mp-yield-func mp) 0d0)
        (setf K (* K (cos (cl-mpm/particle::mp-phi mp))))
        (setf G (* G (sin (cl-mpm/particle::mp-phi mp)))))
      (setf p-mod (* (expt (cl-mpm/fastmaths::det def) -2) (+ K (* 4/3 G)))))
    (when (> soft 0d0)
      (with-accessors ((c-0 mp-c-0)
                       (phi-0 mp-phi-0)
                       (psi-0 mp-psi-0)
                       (c-r mp-c-r)
                       (phi-r mp-phi-r)
                       (psi-r mp-psi-r))
          mp
        (declare (double-float c-0 c-r phi-0 phi-r psi-0 psi-r))
          (setf
           c (+ c-r (* (- c-0 c-r) (exp (- (* soft ps-vm)))))
           phi (atan (+ (tan phi-r) (* (- (tan phi-0) (tan phi-r)) (exp (- (* soft ps-vm)))))))))
    stress))

;; (defmethod new-loadstep-mp ((mp particle-plastic))
;;   (with-accessors ((strain cl-mpm/particle:mp-strain)
;;                    (strain-n cl-mpm/particle:mp-strain-n)
;;                    (disp cl-mpm/particle::mp-displacement)
;;                    (def    cl-mpm/particle:mp-deformation-gradient)
;;                    (def-0 cl-mpm/particle::mp-deformation-gradient-0)
;;                    (df-inc    cl-mpm/particle::mp-deformation-gradient-increment)
;;                    )
;;       mp
;;     (cl-mpm/utils:matrix-copy-into def def-0)
;;     (cl-mpm/utils:matrix-copy-into (cl-mpm/utils:matrix-eye 1d0) df-inc)
;;     (cl-mpm/utils:voigt-copy-into strain strain-n)
;;     (cl-mpm/fastmaths:fast-zero disp)
;;     (break)
;;     ))
