(in-package :cl-mpm)
;; (declaim #.cl-mpm/settings:*optimise-setting*)
(declaim #.cl-mpm/settings:*optimise-setting*)

(defgeneric special-g2p (mesh mp node svp grads)
  (:documentation "G2P behaviour for specific features")
  (:method (mesh mp node svp grads)))

(defmethod special-g2p (mesh (mp cl-mpm/particle::particle-thermal) node svp grads)
  (declare (ignore mesh))
  "Map grid to particle for one mp-node pair"
  (with-accessors ((node-temp cl-mpm/mesh:node-temperature)) node
    (with-accessors ((temp cl-mpm/particle::mp-temperature)) mp
      (progn
        (setf temp (+ temp (* node-temp svp)))))))

(defmethod special-g2p (mesh (mp cl-mpm/particle::particle-damage) node svp grads)
  (declare (ignore mesh))
  "Map grid to particle for one mp-node pair"
  (with-accessors ((node-damage cl-mpm/mesh::node-damage)
                   (node-temp cl-mpm/mesh::node-temp)) node
    (with-accessors ((temp cl-mpm/particle::mp-damage)) mp
      (progn
        (setf temp (+ temp (* node-temp svp)))
        ))))

(defgeneric reset-mps-g2p (mp)
  (:method (mp)))

(defmethod reset-mps-g2p ((mp cl-mpm/particle::particle-thermal))
  (with-accessors ((temp cl-mpm/particle::mp-temperature)) mp
      (setf temp 0d0)))

(declaim
 (notinline g2p-mp)
 (ftype (function (cl-mpm/mesh::mesh cl-mpm/particle:particle double-float) (values))
                g2p-mp))

;; (defun g2p-mp-tflip (mesh mp dt damping)
;;   (declare (cl-mpm/mesh::mesh mesh)
;;            (cl-mpm/particle:particle mp)
;;            (double-float dt))
;;   "Map one MP from the grid"
;;   (with-accessors ((vel mp-velocity)
;;                    (vel-grad cl-mpm/particle::mp-velocity-gradient)
;;                    (pos mp-position)
;;                    (pos-trial cl-mpm/particle::mp-position-trial)
;;                    (disp cl-mpm/particle::mp-displacement)
;;                    (df-inc-inv cl-mpm/particle::mp-deformation-gradient-increment-inverse)
;;                    (disp-inc cl-mpm/particle::mp-displacement-increment))
;;       mp
;;     (let* ((mapped-vel (cl-mpm/utils:vector-zeros))
;;            (acc (cl-mpm/utils:vector-zeros))
;;            (svp-sum 0d0))
;;       (declare (double-float svp-sum))
;;       (cl-mpm/fastmaths:fast-zero disp-inc)
;;       (cl-mpm/fastmaths:fast-zero vel-grad)
;;       ;; Map variables
;;       (iterate-over-neighbours
;;        mesh mp
;;        (lambda (node svp grads fsvp fgrads)
;;          (declare
;;           (ignore mp mesh fsvp fgrads)
;;           (cl-mpm/mesh::node node)
;;           (cl-mpm/particle:particle mp)
;;           (double-float svp))
;;          (with-accessors ((node-vel cl-mpm/mesh:node-velocity)
;;                           (node-acc cl-mpm/mesh:node-acceleration)
;;                           (node-disp cl-mpm/mesh::node-displacment)
;;                           (node-scalar cl-mpm/mesh::node-boundary-scalar)
;;                           (node-active cl-mpm/mesh:node-active)
;;                           ) node
;;            (declare (double-float node-scalar)
;;                     (boolean node-active))
;;            (when node-active
;;              (cl-mpm/fastmaths::fast-fmacc mapped-vel node-vel svp)
;;              (cl-mpm/fastmaths::fast-fmacc disp-inc node-disp svp)
;;              (cl-mpm/fastmaths::fast-fmacc acc node-acc svp)
;;              (cl-mpm/shape-function::@-combi-assemble-dstretch-3d (cl-mpm::gradient-push-forwards-cached grads df-inc-inv) node-vel vel-grad)
;;              (incf svp-sum svp)
;;              ))))
;;       (progn
;;         (cl-mpm/fastmaths:fast-.+ pos disp-inc pos-trial)
;;         (let ((pic-value 1d-3))
;;           (cl-mpm/fastmaths:fast-.+
;;            (cl-mpm/fastmaths:fast-scale-vector
;;             (cl-mpm/fastmaths:fast-.+
;;              vel
;;              (cl-mpm/fastmaths:fast-scale-vector acc dt))
;;             (- 1d0 pic-value))
;;            (cl-mpm/fastmaths:fast-scale-vector mapped-vel pic-value)
;;            vel))
;;         ;; (cl-mpm/fastmaths:fast-fmacc vel acc dt)
;;         ))))


(macrolet ((def-g2p-mp (name &body update)
             `(defun ,name (mesh mp dt damping)
                (declare (cl-mpm/mesh::mesh mesh)
                         (cl-mpm/particle:particle mp)
                         (double-float dt))
                "Map one MP from the grid"
                (with-accessors ((vel mp-velocity)
                                 (vel-grad cl-mpm/particle::mp-velocity-gradient)
                                 (pos mp-position)
                                 (pos-trial cl-mpm/particle::mp-position-trial)
                                 (disp cl-mpm/particle::mp-displacement)
                                 (df-inc-inv cl-mpm/particle::mp-deformation-gradient-increment-inverse)
                                 (disp-inc cl-mpm/particle::mp-displacement-increment))
                    mp
                  (let* ((mapped-vel (cl-mpm/utils:vector-zeros))
                         (acc (cl-mpm/utils:vector-zeros))
                         (svp-sum 0d0))
                    (declare (double-float svp-sum))
                    (cl-mpm/fastmaths:fast-zero disp-inc)
                    (cl-mpm/fastmaths:fast-zero vel-grad)
                    ;; Map variables
                    (iterate-over-neighbours
                     mesh mp
                     (lambda (node svp grads fsvp fgrads)
                       (declare
                        (ignore mp mesh fsvp fgrads)
                        (cl-mpm/mesh::node node)
                        (cl-mpm/particle:particle mp)
                        (double-float svp))
                       (with-accessors ((node-vel cl-mpm/mesh:node-velocity)
                                        (node-acc cl-mpm/mesh:node-acceleration)
                                        (node-disp cl-mpm/mesh::node-displacment)
                                        (node-scalar cl-mpm/mesh::node-boundary-scalar)
                                        (node-active cl-mpm/mesh:node-active)
                                        ) node
                         (declare (double-float node-scalar)
                                  (boolean node-active))
                         (when node-active
                           (cl-mpm/fastmaths::fast-fmacc mapped-vel node-vel svp)
                           (cl-mpm/fastmaths::fast-fmacc disp-inc node-disp svp)
                           (cl-mpm/fastmaths::fast-fmacc acc node-acc svp)
                           (incf svp-sum svp)
                           (cl-mpm/shape-function::@-combi-assemble-dstretch-3d
                            grads
                            node-vel vel-grad)
                           ;; (cl-mpm/shape-function::@-combi-assemble-dstretch-3d grads node-vel vel-grad)
                           ;;With special operations we want to include this operation
                           #+cl-mpm-special (special-g2p mesh mp node svp grads)
                           ))))
                    ;; (cl-mpm/fastmaths:fast-scale! mapped-vel (/ 1d0 svp-sum))
                    ;; (cl-mpm/fastmaths:fast-scale! disp-inc (/ 1d0 svp-sum))
                    ;; (cl-mpm/fastmaths:fast-scale! acc (/ 1d0 svp-sum))
                    ;;Update particle
                    (progn
                      ;;Invalidate shapefunction/gradient cache
                      ;; (update-particle mesh mp dt)
                      ,@update
                      )))))
           (def-g2p-trial-mp (name &body update)
             `(defun ,name (mesh mp dt damping)
                (declare (cl-mpm/mesh::mesh mesh)
                         (cl-mpm/particle:particle mp)
                         (double-float dt))
                "Map one MP from the grid"
                (with-accessors ((pos mp-position)
                                 (pos-trial cl-mpm/particle::mp-position-trial)
                                 (disp cl-mpm/particle::mp-displacement)
                                 (disp-inc cl-mpm/particle::mp-displacement-increment))
                    mp
                  (let* ((svp-sum 0d0))
                    (declare (double-float svp-sum))
                    (cl-mpm/fastmaths:fast-zero disp-inc)
                    ;; Map variables
                    (iterate-over-neighbours
                     mesh mp
                     (lambda (node svp grads fsvp fgrads)
                       (declare
                        (ignore mp mesh fsvp fgrads)
                        (cl-mpm/particle:particle mp)
                        (double-float svp))
                       (when (cl-mpm/mesh:node-active node)
                         (with-accessors ((node-disp cl-mpm/mesh::node-displacment)) node
                           (cl-mpm/fastmaths::fast-fmacc disp-inc node-disp svp)
                           (incf svp-sum svp)
                           ))))
                    (progn
                      ,@update)))))
           )

  (def-g2p-mp g2p-mp-flip
      (progn
        ;; (cl-mpm/utils::vector-copy-into mapped-vel disp-inc)
        ;; (cl-mpm/fastmaths:fast-scale! disp-inc dt)
        ;; (pprint acc)
        ;; (pprint mapped-vel)
        ;; (break)
        ;; (cl-mpm/utils:vector-copy acc (cl-mpm/particle::mp-acceleration mp))
        (cl-mpm/fastmaths:fast-.+ pos disp-inc pos-trial)
        (cl-mpm/fastmaths:fast-fmacc vel acc dt)))
  (def-g2p-mp g2p-mp-pic
      (progn
        ;; PIC update scheme
        (cl-mpm/utils::vector-copy-into mapped-vel vel)
        ;; (cl-mpm/utils::vector-copy-into mapped-vel disp-inc)
        ;; (cl-mpm/fastmaths:fast-scale! disp-inc dt)
        (cl-mpm/fastmaths:fast-.+ pos disp-inc pos-trial)
        nil
        ))
  (def-g2p-trial-mp g2p-mp-trial
      (progn
        (cl-mpm/fastmaths:fast-.+ pos disp-inc pos-trial)))
  (def-g2p-mp g2p-mp-quasi-static
      (progn
        ;; (declare (ignore mapped-vel acc))
        (cl-mpm/fastmaths::fast-zero vel)
        (cl-mpm/fastmaths:fast-.+ pos disp-inc pos-trial)))
  (def-g2p-mp g2p-mp-blend
      (let ((pic-value 1d-3))
        ;; (break)
        (cl-mpm/fastmaths:fast-.+ pos disp-inc pos-trial)
        (cl-mpm/fastmaths:fast-.+
         (cl-mpm/fastmaths:fast-scale-vector
          ;; FLIP value
          (cl-mpm/fastmaths:fast-.+
           vel
           (cl-mpm/fastmaths:fast-scale-vector acc dt))
          (- 1d0 pic-value))
         ;; PIC update
         (cl-mpm/fastmaths:fast-scale-vector mapped-vel pic-value)
         vel)))
  (def-g2p-mp g2p-mp-blend-2nd-order
      (let* ((pic-value (/ 1d-3 dt))
             (vel-inc
               (cl-mpm/fastmaths::fast-scale!
                (cl-mpm/fastmaths::fast-.--vector
                 acc
                 (cl-mpm/fastmaths:fast-scale!
                  (cl-mpm/fastmaths::fast-.--vector vel mapped-vel) pic-value))
                dt)))
        (cl-mpm/fastmaths::fast-.+-vector vel vel-inc vel)
        (let ((dx (cl-mpm/fastmaths::fast-.-
                   (cl-mpm/fastmaths:fast-scale-vector mapped-vel dt)
                   (cl-mpm/fastmaths:fast-scale-vector vel-inc (* 0.5d0 dt)))))
          (cl-mpm/fastmaths::fast-scale! disp-inc dt)))))

(declaim (notinline g2p))

(defun g2p (mesh mps dt damping &optional (update-type :FLIP))
  (declare (double-float dt damping))
  (ecase update-type
    (:TRIAL
     (iterate-over-mps
      mps
      (lambda (mp)
        (g2p-mp-trial mesh mp dt damping))))
    (:QUASI-STATIC
     (iterate-over-mps
      mps
      (lambda (mp)
        (g2p-mp-quasi-static mesh mp dt damping))))
    (:FLIP
     (iterate-over-mps
      mps
      (lambda (mp)
        (g2p-mp-flip mesh mp dt damping))))
    (:PIC
     (iterate-over-mps
      mps
      (lambda (mp)
        (g2p-mp-pic mesh mp dt damping))))
    (:BLEND
     (iterate-over-mps
      mps
      (lambda (mp)
        (g2p-mp-blend mesh mp dt damping))))
    (:TPIC
     (iterate-over-mps
      mps
      (lambda (mp)
        (g2p-mp-pic mesh mp dt damping))))
    (:TFLIP
     (iterate-over-mps
      mps
      (lambda (mp)
        (g2p-mp-flip mesh mp dt damping))))
    (:TBLEND
     (iterate-over-mps
      mps
      (lambda (mp)
        (g2p-mp-blend mesh mp dt damping))))
    (:BLEND-2ND-ORDER
     (iterate-over-mps
      mps
      (lambda (mp)
        (g2p-mp-blend-2nd-order mesh mp dt damping))))))
