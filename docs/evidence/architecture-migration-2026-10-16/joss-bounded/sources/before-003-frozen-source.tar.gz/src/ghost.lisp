(defpackage :cl-mpm/ghost
  (:use :cl
   :cl-mpm
   :cl-mpm/particle
   :cl-mpm/mesh
   :cl-mpm/utils
   :cl-mpm/fastmaths
   )
  (:import-from
   :magicl tref .+ .-)
  (:export
   #:apply-ghost
   #:apply-ghost-cached))
;; (declaim (optimize (debug 3) (safety 3) (speed 0)))
;; (declaim (optimize (debug 0) (safety 0) (speed 3)))
                                        ;    #:make-shape-function
(in-package :cl-mpm/ghost)
(declaim #.cl-mpm/settings:*optimise-setting*)


(defparameter *ghost-exp* 1)


(let ((ex (cl-mpm/utils:vector-from-list (list 1d0 0d0 0d0)))
      (ey (cl-mpm/utils:vector-from-list (list 0d0 1d0 0d0)))
      (ez (cl-mpm/utils:vector-from-list (list 0d0 0d0 1d0))))
  (defun basis-vec-2d (dim)
    (ecase dim
      (0 ey)
      (1 ex)))
  (defun basis-vec-3d (dim)
    (ecase dim
      (0 (list ey ez))
      (1 (list ex ez))
      (2 (list ex ey)))))

(defun get-basis-2d (mesh cell-a cell-b)
  (let ((index (mapcar #'abs
                       (mapcar #'-
                               (cl-mpm/mesh::cell-index cell-a)
                               (cl-mpm/mesh::cell-index cell-b)))))
    (let ((dim (position 1 index)))
      (basis-vec-2d dim))))

(defun get-basis-3d (mesh cell-a cell-b)
  (let ((index (mapcar #'abs
                       (mapcar #'-
                               (cl-mpm/mesh::cell-index cell-a)
                               (cl-mpm/mesh::cell-index cell-b)))))
    (let ((dim (position 1 index)))
      (basis-vec-3d dim))))

(defun get-root-node (mesh cell-a cell-b)
  (let* ((index (mapcar (lambda (a b) (round (+ a (max 0d0 (- b a)))))
                        (cl-mpm/mesh::cell-index cell-b)
                        (cl-mpm/mesh::cell-index cell-a))))
    index))

(defun iterate-over-face-gps (mesh cell-a cell-b func)
  (let ((nd (cl-mpm/mesh:mesh-nd mesh)))
    (ecase nd
        (2
         (iterate-over-face-gps-2d mesh cell-a cell-b func))
        (3
         (iterate-over-face-gps-3d mesh cell-a cell-b func)))))

(declaim (notinline get-face-displacement))
(defun get-face-displacement (mesh normal point)
  (let ((not-normal (cl-mpm/fastmaths:fast-.-
                     (cl-mpm/utils:vector-from-list (list 1d0 1d0 1d0))
                     normal))
        (dF (cl-mpm/utils:voigt-zeros))
        )
    (cl-mpm::iterate-over-neighbours-point-linear
     mesh
     point
     (lambda (mesh node weight grads)
       (cl-mpm/fastmaths::fast-.+
        (magicl:@
         (cl-mpm/shape-function::assemble-dsvp-3d grads)
         (cl-mpm/fastmaths:fast-.*
          not-normal
          (cl-mpm/mesh::node-displacment node)))
        dF
        dF)))
    (* (cl-mpm/mesh::mesh-resolution mesh) (+ 1d0 (cl-mpm/fastmaths::voight-det dF)))))

;; (defun get-face-df (mesh normal point)
;;   (let ((not-normal (cl-mpm/fastmaths:fast-.-
;;                      (cl-mpm/utils:vector-from-list (list 1d0 1d0 1d0))
;;                      normal))
;;         (dF (cl-mpm/utils:matrix-eye 1d0)))
;;     (iterate-over-gp-nodes
;;      mesh
;;      point
;;      normal
;;      (lambda (node weight grads dface dnorm)
;;        (cl-mpm/shape-function::@-combi-assemble-dstretch-3d grads (cl-mpm/mesh::node-displacment node) dF)))
;;     dF))

(defun get-node-trial-position (node)
  ;; (cl-mpm/mesh::node-position node)
  (cl-mpm/fastmaths:fast-.+ (cl-mpm/mesh::node-position node)
                            (cl-mpm/mesh::node-displacment node))
  )

(defun iterate-over-face-gps-2d (mesh cell-a cell-b func)
  (declare (function func))
  (let* ((h (cl-mpm/mesh:mesh-resolution mesh))
         (pos-a (cl-mpm/mesh::cell-centroid cell-a))
         (pos-b (cl-mpm/mesh::cell-centroid cell-b))
         (normal (cl-mpm/fastmaths:norm (cl-mpm/fastmaths:fast-.- pos-a pos-b)))
         (pos-trial-a (cl-mpm/mesh::cell-trial-centroid cell-a))
         (pos-trial-b (cl-mpm/mesh::cell-trial-centroid cell-b))
         (normal-trial (cl-mpm/fastmaths:norm (cl-mpm/fastmaths:fast-.- pos-trial-a pos-trial-b)))
         (face-basis (get-basis-2d mesh cell-a cell-b))
         (midpoint (cl-mpm/fastmaths::fast-scale! (cl-mpm/fastmaths:fast-.+ pos-a pos-b) 0.5d0))
         (root (get-root-node mesh cell-a cell-b))
         (end (mapcar #'+ root
                      (list
                       (round (varef face-basis 0))
                       (round (varef face-basis 1))
                       0)))
         (length (cl-mpm/fastmaths::diff-mag
                  (get-node-trial-position (cl-mpm/mesh:get-node mesh root))
                  (get-node-trial-position (cl-mpm/mesh:get-node mesh end))))
         )
    ;;2 GPs
    (let* ((nd (cl-mpm/mesh::mesh-nd mesh)))
      (loop for gp in (list -1d0 1d0)
            do (progn
                 (let ((gp-loc (cl-mpm/fastmaths:fast-.+
                                midpoint
                                (cl-mpm/fastmaths:fast-scale-vector face-basis (/ (* gp 0.5d0 h) (sqrt 3)))))
                       (gp-weight 1d0)
                       (detJ (/ length 2)))
                   ;;GP weigth * detJ
                   (funcall func gp-loc (* gp-weight detJ) normal normal-trial length)))))))

(defun iterate-over-face-gps-3d (mesh cell-a cell-b func)
  (declare (function func))
  (let* ((h (cl-mpm/mesh:mesh-resolution mesh))
         (pos-a (cl-mpm/mesh::cell-centroid cell-a))
         (pos-b (cl-mpm/mesh::cell-centroid cell-b))
         (normal (cl-mpm/fastmaths:norm (cl-mpm/fastmaths:fast-.- pos-a pos-b)))
         (pos-trial-a (cl-mpm/mesh::cell-trial-centroid cell-a))
         (pos-trial-b (cl-mpm/mesh::cell-trial-centroid cell-b))
         (normal-trial (cl-mpm/fastmaths:norm (cl-mpm/fastmaths:fast-.- pos-trial-a pos-trial-b)))

         (midpoint (cl-mpm/fastmaths::fast-scale! (cl-mpm/fastmaths:fast-.+ pos-a pos-b) 0.5d0))
         (root (get-root-node mesh cell-a cell-b))
         )
    (destructuring-bind (fb-1 fb-2) (get-basis-3d mesh cell-a cell-b)
      ;;2 GPs
      (let* (
             (end-1 (mapcar #'+ root
                            (list
                             (round (varef fb-1 0))
                             (round (varef fb-1 1))
                             (round (varef fb-1 2)))))
             (length-1 (sqrt
                        (max 0d0
                             (cl-mpm/fastmaths::diff-norm
                              (get-node-trial-position (cl-mpm/mesh:get-node mesh root))
                              (get-node-trial-position (cl-mpm/mesh:get-node mesh end-1))))))

             (end-2 (mapcar #'+ root
                            (list
                             (round (varef fb-2 0))
                             (round (varef fb-2 1))
                             (round (varef fb-2 2)))))
             (length-2 (sqrt
                        (max 0d0
                             (cl-mpm/fastmaths::diff-norm
                              (get-node-trial-position (cl-mpm/mesh:get-node mesh root))
                              (get-node-trial-position (cl-mpm/mesh:get-node mesh end-2)))))
                       )
             (length (max length-1 length-2))
             (area (* length-1 length-2))
             )
        (let* ((nd (cl-mpm/mesh::mesh-nd mesh))
               ;; (J (expt 2 (- nd 1)))
               )
          (loop for gp-1 in (list -1d0 1d0)
                do
                   (loop for gp-2 in (list -1d0 1d0)
                         do
                            (progn
                              (let ((gp-loc (cl-mpm/fastmaths:fast-.+
                                             midpoint
                                             (cl-mpm/fastmaths:fast-.+
                                              (cl-mpm/fastmaths:fast-scale-vector fb-1 (/ (* gp-1 0.5d0 h) (sqrt 3)))
                                              (cl-mpm/fastmaths:fast-scale-vector fb-2 (/ (* gp-2 0.5d0 h) (sqrt 3))))))
                                    (gp-weight 1d0)
                                    (detJ (/ area 4))
                                    )
                                (funcall func gp-loc (* gp-weight detJ) normal normal-trial length))))))))))


(defun iterate-over-cell-nodes (mesh cell func)
  (declare (function func)
           (cl-mpm/mesh::cell cell)
           (cl-mpm/mesh::mesh mesh))
  (with-accessors ((nodes cl-mpm/mesh::cell-nodes))
      cell
    (loop for node across nodes
          do (funcall func node))))
(defun iterate-over-face-nodes (mesh midpoint normal func)
  (iterate-over-face-nodes-2d
   mesh midpoint normal func))
(defun iterate-over-face-nodes-positive (mesh midpoint normal func)
  (iterate-over-face-nodes-2d
   mesh midpoint normal func
   '(-1 0)))

(defun iterate-over-face-nodes-2d (mesh midpoint normal func &optional (dnormal '(-1 0 1)))
  (let* ((root (cl-mpm/mesh::position-to-index mesh midpoint #'floor))
        (face-basis (list (if (< 1d-15 (abs (tref normal 0 0))) 0 1)
                          (if (< 1d-15 (abs (tref normal 1 0))) 0 1)
                          0))
        (normal-basis (list (if (< 1d-15 (abs (tref normal 0 0))) 1 0)
                            (if (< 1d-15 (abs (tref normal 1 0))) 1 0)
                            0
                            ))
        )
    (loop for dface in '(0 1)
          do
             (loop for dnorm in dnormal
                   do
                      (let* ((index (mapcar #'+
                                           root
                                           (mapcar (lambda (x) (* x dface)) face-basis)
                                           (mapcar (lambda (x) (* x dnorm)) normal-basis))))
                        (when (cl-mpm/mesh:in-bounds mesh index)
                          (let ((node (cl-mpm/mesh:get-node mesh index)))
                            (when (cl-mpm/mesh::node-active node)
                              (funcall func node dface dnorm)))))))))

;; (defun iterate-over-gp-nodes (mesh gp-point normal func)
;;   (let ((h (cl-mpm/mesh:mesh-resolution mesh)))
;;     (iterate-over-face-nodes
;;      mesh
;;      gp-point
;;      normal
;;      (lambda (node dface dnorm)
;;        (let* ((node-pos (cl-mpm/mesh::node-position node))
;;               (dist (cl-mpm/fastmaths::fast-.- gp-point node-pos))
;;               (weight-x (cl-mpm/shape-function::shape-linear (varef dist 0) h))
;;               (weight-y (cl-mpm/shape-function::shape-linear (varef dist 1) h))
;;               (weight (* weight-x weight-y))
;;               (grads (list
;;                       (*
;;                        (signum (varef dist 0))
;;                        (the double-float (cl-mpm/shape-function::shape-linear-dsvp (varef dist 0) h))
;;                        (the double-float weight-y))
;;                       (*
;;                        (signum (varef dist 1))
;;                        (the double-float (cl-mpm/shape-function::shape-linear-dsvp (varef dist 1) h))
;;                        (the double-float weight-x))
;;                       0d0)))
;;          (funcall func node weight grads dface dnorm))))))
;; (defun iterate-over-gp-nodes-positive (mesh gp-point normal func)
;;   (let ((h (cl-mpm/mesh:mesh-resolution mesh)))
;;     (iterate-over-face-nodes-positive
;;      mesh
;;      gp-point
;;      normal
;;      (lambda (node dface dnorm)
;;        (let* ((node-pos (cl-mpm/mesh::node-position node))
;;               (dist (cl-mpm/fastmaths::fast-.- gp-point node-pos))
;;               (weight-x (cl-mpm/shape-function::shape-linear (varef dist 0) h))
;;               (weight-y (cl-mpm/shape-function::shape-linear (varef dist 1) h))
;;               (weight (* weight-x weight-y))
;;               (grads (list
;;                       (*
;;                        (signum (varef dist 0))
;;                        (the double-float (cl-mpm/shape-function::shape-linear-dsvp (varef dist 0) h))
;;                        (the double-float weight-y))
;;                       (*
;;                        (signum (varef dist 1))
;;                        (the double-float (cl-mpm/shape-function::shape-linear-dsvp (varef dist 1) h))
;;                        (the double-float weight-x))
;;                       0d0)))
;;          (funcall func node weight grads dface dnorm))))))



(defun populate-cell-mp-count-volume (mesh mps)
  (let ((cells (cl-mpm/mesh::mesh-cells mesh)))
    (cl-mpm::iterate-over-cells
     mesh
     (lambda (cell)
       (setf (cl-mpm/mesh::cell-mp-count cell) 0
             (cl-mpm/mesh::cell-ghost-element cell) nil)))
    (cl-mpm::iterate-over-cells
     mesh
     (lambda (cell)
       (with-accessors ((mp-count cl-mpm/mesh::cell-mp-count)
                        (neighbours cl-mpm/mesh::cell-neighbours)
                        (index cl-mpm/mesh::cell-index)
                        (nodes cl-mpm/mesh::cell-nodes)
                        (centroid cl-mpm/mesh::cell-centroid))
           cell
         (when (every
                (lambda (n)
                  (and (cl-mpm/mesh:node-active n)
                       (> (cl-mpm/mesh:node-mass n) 0d0)))
                nodes)
           (setf mp-count 1)))))
    ))

(defun locate-ghost-elements (sim)
  (with-accessors ((mps cl-mpm:sim-mps)
                   (mesh cl-mpm:sim-mesh))
      sim
    (cl-mpm::iterate-over-cells
     mesh
     (lambda (cell)
       (with-accessors ((active cl-mpm/mesh::cell-active)
                        (partial cl-mpm/mesh::cell-partial)
                        (ghost cl-mpm/mesh::cell-ghost-element))
           cell
         (when active
           (setf ghost nil)))))
    (cl-mpm::iterate-over-cells
     mesh
     (lambda (cell)
       (with-accessors ((mp-count cl-mpm/mesh::cell-mp-count)
                        (neighbours cl-mpm/mesh::cell-neighbours)
                        (index cl-mpm/mesh::cell-index)
                        (nodes cl-mpm/mesh::cell-nodes)
                        (pruned cl-mpm/mesh::cell-pruned)
                        (active cl-mpm/mesh::cell-active)
                        (partial cl-mpm/mesh::cell-partial)
                        (ghost cl-mpm/mesh::cell-ghost-element)
                        (pos cl-mpm/mesh::cell-centroid))
           cell
         (when (and active (not partial))
           (let ((primary-ghost nil))
             (loop for neighbour in neighbours
                   while (not ghost)
                   do
                      (when (and
                             (cl-mpm/mesh::cell-active neighbour)
                             (cl-mpm/mesh::cell-partial neighbour))
                        (setf ghost t
                              primary-ghost t
                              )))
             (when primary-ghost
               (loop for neighbour in neighbours
                     do
                        (when (and
                               (cl-mpm/mesh::cell-active neighbour)
                               (not (cl-mpm/mesh::cell-partial neighbour)))
                          (setf (cl-mpm/mesh::cell-ghost-element neighbour) t))))
             )))))))

(defun iterate-over-bicell-nodes (mesh cell-a cell-b gp-loc func)
  (declare (function func))
  (cl-mpm::iterate-over-cell-shape-local
   mesh
   cell-a
   gp-loc
   (lambda (node weight grads) (funcall func cell-a node weight grads 1d0)))
  (cl-mpm::iterate-over-cell-shape-local
   mesh
   cell-b
   gp-loc
   (lambda (node weight grads) (funcall func cell-b node weight grads -1d0))))

(defparameter *write-lock* (sb-thread:make-mutex))

(defun apply-ghost-cells-undeformed (mesh cell-a cell-b ghost-factor)
  (when
      (and
       (and
        (cl-mpm/mesh::cell-active cell-a)
        (cl-mpm/mesh::cell-active cell-b))
       (not (cl-mpm/mesh::cell-partial cell-a))
       (not (cl-mpm/mesh::cell-partial cell-b))
       (and
        (cl-mpm/mesh::cell-ghost-element cell-a)
        (cl-mpm/mesh::cell-ghost-element cell-b)))
    (with-accessors ((h cl-mpm/mesh:mesh-resolution))
        mesh
      (let ((h (cl-mpm/mesh:mesh-resolution mesh)))
        (iterate-over-face-gps
         mesh
         cell-a
         cell-b
         (lambda (gp-loc gp-weight normal normal-trial face-length)
           (let* ((nx (varef normal 0))
                  (ny (varef normal 1))
                  (nz (varef normal 2))
                  (dsvp-adjuster (magicl:transpose (cl-mpm/utils::arb-matrix-from-list
                                                     (list
                                                      nx  0d0 0d0
                                                      0d0 ny  0d0
                                                      0d0 0d0 nz
                                                      0d0 nz  ny
                                                      nz  0d0 nx
                                                      ny  nx  0d0)
                                                     3
                                                     6)))
                  (gradient-terms (cl-mpm/utils:vector-zeros)))
             (cl-mpm/ghost::iterate-over-bicell-nodes
              mesh
              cell-a
              cell-b
              gp-loc
              (lambda (cell-p node weight grads fact)
                (when (cl-mpm/mesh::node-active node)
                  (with-accessors ((ghost cl-mpm/mesh::node-ghost-force)
                                   (f-int cl-mpm/mesh::node-internal-force)
                                   (f-ext cl-mpm/mesh::node-external-force)
                                   (node-lock cl-mpm/mesh::node-lock)
                                   (disp cl-mpm/mesh::node-displacment))
                      node
                    (let ((dsvp-p (fast-scale!
                                   (magicl:transpose
                                    (cl-mpm/shape-function::assemble-dsvp-3d
                                     grads))
                                   fact)))
                      (cl-mpm/fastmaths:fast-.+
                       (magicl:@
                        (magicl:transpose dsvp-adjuster)
                        (magicl:transpose dsvp-p)
                        disp)
                       gradient-terms
                       gradient-terms))))))
             (iterate-over-bicell-nodes
              mesh
              cell-a
              cell-b
              gp-loc
              (lambda (cell node weight grads fact)
                (when (cl-mpm/mesh::node-active node)
                  (with-accessors ((disp cl-mpm/mesh::node-displacment)
                                   (node-lock cl-mpm/mesh::node-lock)
                                   (ghost cl-mpm/mesh::node-ghost-force))
                      node
                    (let* ((dsvp
                             (fast-scale!
                              (magicl:transpose
                               (cl-mpm/shape-function::assemble-dsvp-3d
                                grads
                                ))
                              fact)))
                      (let ((ghost-force
                              (cl-mpm/fastmaths:fast-scale!
                               (magicl:@
                                dsvp
                                dsvp-adjuster
                                gradient-terms)
                               (*
                                -1d0
                                ghost-factor
                                (expt face-length *ghost-exp*)
                                gp-weight
                                ))))
                        (sb-thread:with-mutex (node-lock)
                          (cl-mpm/fastmaths:fast-.+
                           ghost-force
                           ghost
                           ghost))))))))
             )))))))


(defun apply-ghost-cells-new (mesh cell-a cell-b ghost-factor)
  (when
      (and
       (and
        (cl-mpm/mesh::cell-active cell-a)
        (cl-mpm/mesh::cell-active cell-b))
       (not (cl-mpm/mesh::cell-partial cell-a))
       (not (cl-mpm/mesh::cell-partial cell-b))
       (and
        (cl-mpm/mesh::cell-ghost-element cell-a)
        (cl-mpm/mesh::cell-ghost-element cell-b)))
    (with-accessors ((h cl-mpm/mesh:mesh-resolution))
        mesh
      (let ((h (cl-mpm/mesh:mesh-resolution mesh)))
        (iterate-over-face-gps
         mesh
         cell-a
         cell-b
         (lambda (gp-loc gp-weight normal normal-trial face-length)
           (let* ((nx (varef normal-trial 0))
                  (ny (varef normal-trial 1))
                  (nz (varef normal-trial 2))
                  (dsvp-adjuster (magicl:transpose (cl-mpm/utils::arb-matrix-from-list
                                                     (list
                                                      nx  0d0 0d0
                                                      0d0 ny  0d0
                                                      0d0 0d0 nz
                                                      0d0 nz  ny
                                                      nz  0d0 nx
                                                      ny  nx  0d0)
                                                     3
                                                     6)))
                  (gradient-terms (cl-mpm/utils:vector-zeros)))
             (cl-mpm/ghost::iterate-over-bicell-nodes
              mesh
              cell-a
              cell-b
              gp-loc
              (lambda (cell-p node weight grads fact)
                (when (cl-mpm/mesh::node-active node)
                  (with-accessors ((ghost cl-mpm/mesh::node-ghost-force)
                                   (f-int cl-mpm/mesh::node-internal-force)
                                   (f-ext cl-mpm/mesh::node-external-force)
                                   (node-lock cl-mpm/mesh::node-lock)
                                   (disp cl-mpm/mesh::node-displacment))
                      node
                    (let ((dsvp-p (fast-scale!
                                   (magicl:transpose
                                    (cl-mpm/shape-function::assemble-dsvp-3d
                                     ;; grads
                                     (cl-mpm::gradient-push-forwards
                                      grads
                                      (cl-mpm/mesh::cell-deformation-gradient cell-p))
                                     ))
                                   fact
                                   )))
                      (cl-mpm/fastmaths:fast-.+
                       (magicl:@
                        (magicl:transpose dsvp-adjuster)
                        (magicl:transpose dsvp-p)
                        disp)
                       gradient-terms
                       gradient-terms))))))
             (iterate-over-bicell-nodes
              mesh
              cell-a
              cell-b
              gp-loc
              (lambda (cell node weight grads fact)
                (when (cl-mpm/mesh::node-active node)
                  (with-accessors ((disp cl-mpm/mesh::node-displacment)
                                   (node-lock cl-mpm/mesh::node-lock)
                                   (ghost cl-mpm/mesh::node-ghost-force))
                      node
                    (let* ((dsvp
                             (fast-scale!
                              (magicl:transpose
                               (cl-mpm/shape-function::assemble-dsvp-3d
                                ;; grads
                                (cl-mpm::gradient-push-forwards
                                 grads
                                 (cl-mpm/mesh::cell-deformation-gradient cell))
                                ))
                              fact
                              )))
                      (let ((ghost-force
                              (cl-mpm/fastmaths:fast-scale!
                               (magicl:@
                                dsvp
                                dsvp-adjuster
                                gradient-terms)
                               (*
                                -1d0
                                1/3
                                ghost-factor
                                (expt face-length *ghost-exp*)
                                gp-weight))))
                        (sb-thread:with-mutex (node-lock)
                          (cl-mpm/fastmaths:fast-.+
                           ghost-force
                           ghost
                           ghost)))))))))))))))

(defun apply-ghost-cells-accel (mesh cell-a cell-b ghost-factor)
  (when
      (and
       (and
        (cl-mpm/mesh::cell-active cell-a)
        (cl-mpm/mesh::cell-active cell-b))
       (not (cl-mpm/mesh::cell-partial cell-a))
       (not (cl-mpm/mesh::cell-partial cell-b))
       (and
        (cl-mpm/mesh::cell-ghost-element cell-a)
        (cl-mpm/mesh::cell-ghost-element cell-b)))
    (with-accessors ((h cl-mpm/mesh:mesh-resolution))
        mesh
      (let ((h (cl-mpm/mesh:mesh-resolution mesh)))
        (iterate-over-face-gps
         mesh
         cell-a
         cell-b
         (lambda (gp-loc gp-weight normal normal-trial face-length)
           (let* ((nx (varef normal-trial 0))
                  (ny (varef normal-trial 1))
                  (nz (varef normal-trial 2))
                  (dsvp-adjuster (magicl:transpose (cl-mpm/utils::arb-matrix-from-list
                                                     (list
                                                      nx  0d0 0d0
                                                      0d0 ny  0d0
                                                      0d0 0d0 nz
                                                      0d0 nz  ny
                                                      nz  0d0 nx
                                                      ny  nx  0d0)
                                                     3
                                                     6)))
                  (gradient-terms (cl-mpm/utils:vector-zeros)))
             (cl-mpm/ghost::iterate-over-bicell-nodes
              mesh
              cell-a
              cell-b
              gp-loc
              (lambda (cell-p node weight grads fact)
                (when (cl-mpm/mesh::node-active node)
                  (with-accessors ((ghost cl-mpm/mesh::node-ghost-force)
                                   (f-int cl-mpm/mesh::node-internal-force)
                                   (f-ext cl-mpm/mesh::node-external-force)
                                   (node-lock cl-mpm/mesh::node-lock)
                                   (disp cl-mpm/mesh::node-acceleration))
                      node
                    (let ((dsvp-p (fast-scale!
                                   (magicl:transpose
                                    (cl-mpm/shape-function::assemble-dsvp-3d
                                     (cl-mpm::gradient-push-forwards
                                      grads
                                      (cl-mpm/mesh::cell-deformation-gradient cell-p))
                                     ;; grads
                                     ))
                                   fact
                                   )))
                      (cl-mpm/fastmaths:fast-.+
                       (magicl:@
                        (magicl:transpose dsvp-adjuster)
                        (magicl:transpose dsvp-p)
                        disp)
                       gradient-terms
                       gradient-terms))))))
             (iterate-over-bicell-nodes
              mesh
              cell-a
              cell-b
              gp-loc
              (lambda (cell node weight grads fact)
                (when (cl-mpm/mesh::node-active node)
                  (with-accessors ((disp cl-mpm/mesh::node-acceleration)
                                   (node-lock cl-mpm/mesh::node-lock)
                                   (ghost cl-mpm/mesh::node-ghost-force))
                      node
                    (let* ((dsvp
                             (fast-scale!
                              (magicl:transpose
                               (cl-mpm/shape-function::assemble-dsvp-3d
                                (cl-mpm::gradient-push-forwards
                                 grads
                                 (cl-mpm/mesh::cell-deformation-gradient cell))
                                ;; grads
                                ))
                              fact)))
                      (let ((ghost-force
                              (cl-mpm/fastmaths:fast-scale!
                               (magicl:@
                                dsvp
                                dsvp-adjuster
                                gradient-terms)
                               (*
                                -1d0
                                (/ (* ghost-factor (expt h *ghost-exp*)) 3)
                                face-length
                                gp-weight))))
                        (sb-thread:with-mutex (node-lock)
                          (cl-mpm/fastmaths:fast-.+
                           ghost-force
                           ghost
                           ghost)))))))))))))))


(defun iterate-over-ghost-pairs (sim func)
  (declare (function func))
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (mps cl-mpm:sim-mps)
                   )
      sim
    (with-accessors ((cells cl-mpm/mesh::mesh-cells)
                     (h cl-mpm/mesh::mesh-resolution)
                     (nd cl-mpm/mesh:mesh-nd))
        mesh
      (cl-mpm::filter-cells sim)
      (locate-ghost-elements sim)
      (cl-mpm::iterate-over-cells
       mesh
        (lambda (cell)
          (let* ((index (cl-mpm/mesh::cell-index cell))
                 (cell (cl-mpm/mesh::get-cell mesh index)))
            (when (cl-mpm/mesh::cell-ghost-element cell)
                (loop for direction from 0 below nd
                      do
                         (let ((ind-dir (list 0 0 0)))
                           (setf (nth direction ind-dir) 1)
                           (let ((index-b (mapcar #'+ index ind-dir)))
                             (when (cl-mpm/mesh::in-bounds-cell mesh index-b)
                               (funcall func cell (cl-mpm/mesh::get-cell mesh index-b)))))))))))))


(declaim (notinline apply-ghost))
(defun apply-ghost (sim ghost-factor)
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (mps cl-mpm:sim-mps))
      sim
    (with-accessors ((cells cl-mpm/mesh::mesh-cells)
                     (h cl-mpm/mesh::mesh-resolution)
                     (nd cl-mpm/mesh:mesh-nd))
        mesh
      (declare (double-float h ghost-factor))
      (cl-mpm::filter-cells sim)
      (locate-ghost-elements sim)
      (cl-mpm::iterate-over-cells
       mesh
        (lambda (cell)
          (let* ((index (cl-mpm/mesh::cell-index cell))
                 (cell (cl-mpm/mesh::get-cell mesh index)))
            (when (cl-mpm/mesh::cell-ghost-element cell)
                (loop for direction from 0 below nd
                      do
                         (let ((ind-dir (list 0 0 0)))
                           (setf (nth direction ind-dir) 1)
                           (let ((index-b (mapcar #'+ index ind-dir)))
                             (when (cl-mpm/mesh::in-bounds-cell mesh index-b)
                               (apply-ghost-cells-new mesh cell
                                                      (cl-mpm/mesh::get-cell mesh index-b)
                                                      ghost-factor)))))))))
      )))

(defun apply-ghost-accel (sim ghost-factor)
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (mps cl-mpm:sim-mps))
      sim
    (with-accessors ((cells cl-mpm/mesh::mesh-cells)
                     (h cl-mpm/mesh::mesh-resolution)
                     (nd cl-mpm/mesh:mesh-nd))
        mesh
      (declare (double-float h ghost-factor))
      ;; (cl-mpm::filter-cells sim)
      (cl-mpm::update-cells sim)
      (locate-ghost-elements sim)
      (cl-mpm::iterate-over-cells
       mesh
        (lambda (cell)
          (let* ((index (cl-mpm/mesh::cell-index cell))
                 (cell (cl-mpm/mesh::get-cell mesh index)))
            (when (cl-mpm/mesh::cell-ghost-element cell)
                (loop for direction from 0 below nd
                      do
                         (let ((ind-dir (list 0 0 0)))
                           (setf (nth direction ind-dir) 1)
                           (let ((index-b (mapcar #'+ index ind-dir)))
                             (when (cl-mpm/mesh::in-bounds-cell mesh index-b)
                               (apply-ghost-cells-accel mesh cell
                                                        (cl-mpm/mesh::get-cell mesh index-b)
                                                        ghost-factor)))))))))
      )))

;; (defun test-markup (sim)
;;   (let* ((index (list 10 10 0))
;;          (mesh (cl-mpm:sim-mesh sim))
;;          (cell (cl-mpm/mesh::get-cell mesh index)))
;;     (loop for direction from 0 to 0
;;           do
;;              (let ((ind-dir (list 0 0 0)))
;;                (setf (nth direction ind-dir) 1)
;;                (let ((index-b (mapcar #'+ index ind-dir)))
;;                  (when (cl-mpm/mesh::in-bounds-cell mesh index-b)
;;                    (iterate-over-face-gps
;;                     mesh
;;                     cell
;;                     (cl-mpm/mesh::get-cell mesh index-b)
;;                     (lambda (gp-loc gp-weight normal normal-trial)
;;                       (pprint gp-loc)
;;                       (iterate-over-gp-nodes
;;                        mesh
;;                        gp-loc
;;                        normal
;;                        (lambda (node weight grad dface dnorm)
;;                          (pprint node)
;;                          (setf (cl-mpm/mesh::node-active node) t))
;;                        )
;;                       )
;;                     )
;;                    ))))))

(defun calculate-forces-ghost (node damping dt mass-scale)
  "Update forces and nodal velocities with viscous damping"
  (when (cl-mpm/mesh:node-active node)
    (with-accessors ((mass node-mass)
                     (vel node-velocity)
                     (force node-force)
                     (disp cl-mpm/mesh::node-displacment)
                     (force-ghost cl-mpm/mesh::node-ghost-force)
                     (acc node-acceleration))
        node
      (declare (double-float mass dt damping mass-scale))
      (progn
        ;; (cl-mpm/fastmaths:fast-zero acc)
        ;; (cl-mpm/fastmaths:fast-fmacc acc force (/ 1d0 (* mass mass-scale)))
        ;; (cl-mpm/fastmaths:fast-fmacc acc force-ghost (/ 1d0 (* mass mass-scale)))
        ;; (cl-mpm::integrate-vel-euler vel acc mass mass-scale dt 0d0)
        ;; (let ((df (cl-mpm/fastmaths:fast-.+ force force-ghost)))
        ;;   ;; (cl-mpm/fastmaths:fast-fmacc acc force-ghost (/ 1d0 (* mass mass-scale)))
        ;;   (cl-mpm/utils:vector-copy (cl-mpm/fastmaths:fast-scale df (/ 1d0 (* mass mass-scale))) acc)
        ;;   (cl-mpm/fastmaths:fast-fmacc vel force-ghost (/ dt (* mass mass-scale)))
        ;;   (cl-mpm/fastmaths:fast-fmacc disp force-ghost (/ (* dt dt) (* mass mass-scale)))
        ;;   )
        (cl-mpm/fastmaths:fast-fmacc acc force-ghost (/ 1d0 (* mass mass-scale)))
        (cl-mpm/fastmaths:fast-fmacc vel force-ghost (/ dt (* mass mass-scale)))
        (cl-mpm/fastmaths:fast-fmacc disp force-ghost (/ (* dt dt) (* mass mass-scale)))
        )))
  (values))
(defun update-node-forces-ghost (sim dt)
  (with-accessors ((damping sim-damping-factor)
                   (mass-scale sim-mass-scale)
                   (mesh sim-mesh)
                   (damping-algo sim-damping-algorithm)
                   ;; (dt sim-dt)
                   )
      sim
    (iterate-over-nodes
     mesh
     (lambda (node)
       (when (cl-mpm/mesh:node-active node)
         (calculate-forces-ghost node damping dt mass-scale))))))

(defun iterative-ghost (sim)
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (ghost-factor cl-mpm::sim-ghost-factor)
                   (bcs cl-mpm::sim-bcs)
                   (dt cl-mpm::sim-dt))
      sim
    (let* ((iters 10))
      (with-accessors ((mesh cl-mpm:sim-mesh)
                       (mps cl-mpm:sim-mps))
          sim
        (with-accessors ((cells cl-mpm/mesh::mesh-cells)
                         (nd cl-mpm/mesh:mesh-nd))
            mesh
          (declare (double-float ghost-factor))
          ;; (cl-mpm::filter-cells sim)
          (cl-mpm::update-cells sim)
          (locate-ghost-elements sim)
          (let ((elems (make-array 0 :adjustable t :fill-pointer t))
                (mut (sb-thread:make-mutex)))
            (cl-mpm::iterate-over-cells
             mesh
             (lambda (cell)
               (let* ((index (cl-mpm/mesh::cell-index cell))
                      (cell (cl-mpm/mesh::get-cell mesh index)))
                 (when (cl-mpm/mesh::cell-ghost-element cell)
                   (loop for direction from 0 below nd
                         do
                            (let ((ind-dir (list 0 0 0)))
                              (setf (nth direction ind-dir) 1)
                              (let ((index-b (mapcar #'+ index ind-dir)))
                                (when (cl-mpm/mesh::in-bounds-cell mesh index-b)
                                  (let ((cell-a cell)
                                        (cell-b (cl-mpm/mesh::get-cell mesh index-b)))
                                    (when
                                        (and
                                         (and
                                          (cl-mpm/mesh::cell-active cell-a)
                                          (cl-mpm/mesh::cell-active cell-b))
                                         (not (cl-mpm/mesh::cell-partial cell-a))
                                         (not (cl-mpm/mesh::cell-partial cell-b))
                                         (and
                                          (cl-mpm/mesh::cell-ghost-element cell-a)
                                          (cl-mpm/mesh::cell-ghost-element cell-b)))
                                      (sb-thread:with-mutex (mut)
                                        (vector-push-extend (list cell-a cell-b) elems))))))))))))
            (dotimes (i iters)
              (cl-mpm::iterate-over-nodes
               mesh
               (lambda (n)
                 (when (cl-mpm/mesh::node-active n)
                   (cl-mpm/fastmaths:fast-zero (cl-mpm/mesh::node-ghost-force n)))))
              (cl-mpm::update-cells sim)
              ;; (cl-mpm/ghost::apply-ghost-accel sim (/ ghost-factor iters))
              ;; (cl-mpm/ghost::apply-ghost sim ghost-factor)
              (lparallel:pdotimes (i (length elems))
                (destructuring-bind (cell-a cell-b) (aref elems i)
                  (apply-ghost-cells-accel mesh cell-a cell-b (/ ghost-factor iters))
                  ;; (apply-ghost-cells-new mesh cell-a cell-b (/ ghost-factor iters))
                  ))
              (update-node-forces-ghost sim dt)
              (cl-mpm::apply-bcs mesh bcs dt))))))))

(defun apply-half-step-ghost (sim)
  (with-accessors ((ghost-factor cl-mpm::sim-ghost-factor)
                   (mesh cl-mpm::sim-mesh)
                   (bcs cl-mpm::sim-bcs)
                   (dt cl-mpm::sim-dt)
                   )
      sim
    (when ghost-factor
      ;; (cl-mpm::reset-node-displacement sim)
      ;; (cl-mpm::update-nodes sim)
      (cl-mpm::update-cells sim)
      ;; (cl-mpm::apply-bcs mesh bcs dt)
      ;; (dotimes )
      ;;Standard
      ;; (iterative-ghost sim)

      (cl-mpm/ghost::apply-ghost-accel sim ghost-factor)
      ;; (cl-mpm/ghost::apply-ghost sim ghost-factor)
      (update-node-forces-ghost sim dt)
      (cl-mpm::apply-bcs mesh bcs dt))))

(defun estimate-ul-enhancement (cell)
  (with-accessors ((df cl-mpm/mesh::cell-deformation-gradient))
      cell
    (let* ((grads (cl-mpm::gradient-push-forwards (list 1d0 1d0 1d0) df))
           (peak-grad (abs (reduce #'max (mapcar (lambda (x) (expt x -1)) grads)))))
      peak-grad)))

(declaim (notinline apply-ghost-stiffness))
(defun apply-ghost-stiffness (sim)
  (with-accessors ((ghost-factor cl-mpm::sim-ghost-factor)
                   (ghost-cache cl-mpm::sim-ghost-cache)
                   (mesh cl-mpm::sim-mesh))
      sim
    (when ghost-factor
      (with-accessors ((cells cl-mpm/mesh::mesh-cells)
                       (h cl-mpm/mesh::mesh-resolution))
          mesh
        (let ()
          (flet ((apply-stiffness (cell-a cell-b)
                   (apply-stiffness-cells mesh cell-a cell-b ghost-factor)
                   ;; (let ((node-list (make-array 8 :adjustable t :fill-pointer 0 :element-type t)))
                   ;;   (let ((ul (* (estimate-ul-enhancement cell-a)
                   ;;                (estimate-ul-enhancement cell-b))))
                   ;;     (dolist (cell (list cell-a cell-b))
                   ;;       (cl-mpm/ghost::iterate-over-cell-nodes
                   ;;        mesh
                   ;;        cell
                   ;;        (lambda (n)
                   ;;          (declare (cl-mpm/mesh::node n))
                   ;;          (unless (position n node-list)
                   ;;            (with-accessors ((volume cl-mpm/mesh::cell-volume))
                   ;;                cell
                   ;;              (sb-thread:with-mutex ((cl-mpm/mesh:node-lock n))
                   ;;                (setf (cl-mpm/mesh::node-mass n)
                   ;;                      (+
                   ;;                       (cl-mpm/mesh::node-mass n)
                   ;;                       (*
                   ;;                        ;; ul
                   ;;                        ;; volume
                   ;;                        ;; (cl-mpm/fastmaths:det-3x3 (cl-mpm/mesh::cell-deformation-gradient cell))
                   ;;                        gf)))))
                   ;;            (vector-push-extend n node-list)))))))
                   ))
            (if ghost-cache
                (iterate-over-ghost-cache
                 sim
                 #'apply-stiffness)
                (iterate-over-ghost-pairs
                 sim
                 #'apply-stiffness)))
          ))
      ;; (with-accessors ((cells cl-mpm/mesh::mesh-cells)
      ;;                  (h cl-mpm/mesh::mesh-resolution))
      ;;     mesh
      ;;   (declare (double-float h ghost-factor))
      ;;   (let ((gf (* 8d0 ghost-factor (expt h 0;; (- *ghost-exp* 3)
      ;;                                       )
      ;;                )))
      ;;     (cl-mpm::iterate-over-cells
      ;;      mesh
      ;;      (lambda (cell)
      ;;        (when (and (cl-mpm/mesh::cell-active cell)
      ;;                   (cl-mpm/mesh::cell-ghost-element cell))
      ;;          (let ((ul (estimate-ul-enhancement cell)))
      ;;            ;; (pprint ul)
      ;;            (loop for n in (cl-mpm/mesh::cell-nodes cell)
      ;;                  do
      ;;                     (when (cl-mpm/mesh::node-active n)
      ;;                       (sb-thread:with-mutex ((cl-mpm/mesh:node-lock n))
      ;;                         (setf (cl-mpm/mesh::node-mass n)
      ;;                               (max
      ;;                                (cl-mpm/mesh::node-mass n)
      ;;                                (* ul
      ;;                                 gf))))))))))))
      )))


(defun reset-ghost-cache (sim)
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (mps cl-mpm:sim-mps)
                   (ghost-cache cl-mpm::sim-ghost-cache))
      sim
    (when ghost-cache
        (setf (fill-pointer ghost-cache) 0))))

(defun build-ghost-cache (sim)
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (mps cl-mpm:sim-mps)
                   (ghost-cache cl-mpm::sim-ghost-cache))
      sim
    (if ghost-cache
        (setf (fill-pointer ghost-cache) 0)
      (setf ghost-cache (make-array 0 :adjustable t :fill-pointer t)))
    (with-accessors ((cells cl-mpm/mesh::mesh-cells)
                     (nd cl-mpm/mesh:mesh-nd))
        mesh
      (locate-ghost-elements sim)
      (let ((mut (sb-thread:make-mutex)))
        (cl-mpm::iterate-over-cells
         mesh
         (lambda (cell)
           (let* ((index (cl-mpm/mesh::cell-index cell))
                  (cell (cl-mpm/mesh::get-cell mesh index)))
             (when (cl-mpm/mesh::cell-ghost-element cell)
               (loop for direction from 0 below nd
                     do
                        (let ((ind-dir (list 0 0 0)))
                          (setf (nth direction ind-dir) 1)
                          (let ((index-b (mapcar #'+ index ind-dir)))
                            (when (cl-mpm/mesh::in-bounds-cell mesh index-b)
                              (let ((cell-a cell)
                                    (cell-b (cl-mpm/mesh::get-cell mesh index-b)))
                                (when
                                    (and
                                     (and
                                      (cl-mpm/mesh::cell-active cell-a)
                                      (cl-mpm/mesh::cell-active cell-b))
                                     (not (cl-mpm/mesh::cell-partial cell-a))
                                     (not (cl-mpm/mesh::cell-partial cell-b))
                                     (and
                                      (cl-mpm/mesh::cell-ghost-element cell-a)
                                      (cl-mpm/mesh::cell-ghost-element cell-b)))
                                  (sb-thread:with-mutex (mut)
                                    (vector-push-extend (list cell-a cell-b) ghost-cache))))))))))))))))

(defun iterate-over-ghost-cache (sim func)
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (mps cl-mpm:sim-mps)
                   (ghost-factor cl-mpm::sim-ghost-factor)
                   (ghost-cache cl-mpm::sim-ghost-cache))
      sim
    (unless ghost-cache
      (build-ghost-cache sim))
    (lparallel:pdotimes (i (length ghost-cache))
      (destructuring-bind (cell-a cell-b) (aref ghost-cache i)
        (funcall func cell-a cell-b)))))

(defun apply-ghost-cached (sim)
  (with-accessors ((mesh cl-mpm:sim-mesh)
                   (mps cl-mpm:sim-mps)
                   (ghost-factor cl-mpm::sim-ghost-factor)
                   (ghost-cache cl-mpm::sim-ghost-cache))
      sim
    (when ghost-factor
      (if ghost-cache
        (iterate-over-ghost-cache
         sim
         (lambda (cell-a cell-b)
           (apply-ghost-cells-new mesh cell-a cell-b ghost-factor)
           ;; (apply-ghost-cells-undeformed mesh cell-a cell-b ghost-factor)
           ))
        (build-ghost-cache sim)))))

(declaim (notinline apply-stiffness-cells))
(defun apply-stiffness-cells (mesh cell-a cell-b ghost-factor)
  (when
      (and
       (and
        (cl-mpm/mesh::cell-active cell-a)
        (cl-mpm/mesh::cell-active cell-b))
       (not (cl-mpm/mesh::cell-partial cell-a))
       (not (cl-mpm/mesh::cell-partial cell-b))
       (and
        (cl-mpm/mesh::cell-ghost-element cell-a)
        (cl-mpm/mesh::cell-ghost-element cell-b)))
    (with-accessors ((h cl-mpm/mesh:mesh-resolution))
        mesh
      (let ((h (cl-mpm/mesh:mesh-resolution mesh)))
        (iterate-over-face-gps
         mesh
         cell-a
         cell-b
         (lambda (gp-loc gp-weight normal normal-trial face-length)
           (iterate-over-bicell-nodes
            mesh
            cell-a
            cell-b
            gp-loc
            (lambda (cell node weight grads fact)
              (when (cl-mpm/mesh::node-active node)
                (with-accessors ((disp cl-mpm/mesh::node-displacment)
                                 (pos cl-mpm/mesh::node-position)
                                 (node-lock cl-mpm/mesh::node-lock)
                                 (ghost cl-mpm/mesh::node-ghost-force))
                    node
                  (let* ((ghost-stiffness (abs (*
                                                0.25d0
                                                1/3
                                                ghost-factor
                                                (expt h -2)
                                                (expt face-length *ghost-exp*)
                                                gp-weight))))
                    (sb-thread:with-mutex (node-lock)
                      (setf (cl-mpm/mesh::node-mass node)
                            (+
                             (cl-mpm/mesh::node-mass node)
                             ghost-stiffness))))))))))))))
