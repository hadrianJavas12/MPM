(asdf:defsystem "cl-mpm-framework"
  :description "Composable, headless native CL-MPM simulation recipes"
  :depends-on ("cl-mpm" "cl-mpm/setup" "cl-mpm/damage" "cl-mpm/models/chalk"
               "cl-mpm/models/mc-evolution" "cl-mpm/models/clay-creep"
               "cl-mpm/models/wang2017-native" "cl-mpm/models/wang2017-apex"
               "cl-mpm/output" "cl-mpm/penalty" "cl-mpm/plotter" "vgplot"
               "jonathan" "yason" "alexandria" "uiop")
  :serial t
  :components
  (
   (:file "config/package" :pathname "src/simulation/config/package")
   (:file "config/parameters" :pathname "src/simulation/config/parameters")
   (:file "package" :pathname "src/simulation/package")
   (:file "components/base" :pathname "src/simulation/components/base")
   (:file "components/material-definition" :pathname "materials/core/definition")
   (:file "components/specifications" :pathname "src/simulation/components/specifications")
   (:file "components/materials" :pathname "materials/adapters/native")
   (:file "components/diagnostics" :pathname "materials/core/diagnostics-interface")
   (:file "components/native-diagnostics" :pathname "materials/diagnostics/native")
   (:file "components/wang2017-diagnostics" :pathname "materials/adapters/wang2017")
   (:file "components/wang2017-apex-diagnostics" :pathname "materials/adapters/wang2017-apex")
   (:file "components/material-output" :pathname "src/measurements/material-output")
   (:file "components/geometry" :pathname "src/simulation/components/geometry")
   (:file "simulation" :pathname "src/simulation/lifecycle")
   (:file "scenarios/cliff/settings" :pathname "scenarios/cliff/settings")
   (:file "scenarios/cliff/settings-p4-owner-2" :pathname "src/numerics/angles")
   (:file "scenarios/cliff/settings-p4-owner-3" :pathname "scenarios/cliff/solver")
   (:file "materials/chalk" :pathname "materials/models/chalk/joss-reference")
   (:file "materials/chalk-p4-owner-2" :pathname "materials/adapters/chalk")
   (:file "scenarios/cliff/geometry" :pathname "scenarios/cliff/geometry")
   (:file "scenarios/cliff/build" :pathname "scenarios/cliff/build")
   (:file "output/plotting" :pathname "src/output/plotting/legacy-particle")
   (:file "scenarios/joss/classes" :pathname "scenarios/joss/classes")
   (:file "scenarios/joss/statistics" :pathname "scenarios/joss/statistics")
   (:file "scenarios/joss/phases" :pathname "scenarios/joss/phases")
   (:file "scenarios/joss/geometry" :pathname "scenarios/joss/geometry")
   (:file "scenarios/joss/build" :pathname "scenarios/joss/build")
   (:file "scenarios/joss/measurements" :pathname "scenarios/joss/measurements")
   (:file "scenarios/joss/measurements-p4-owner-2" :pathname "materials/diagnostics/chalk-reference")
   (:file "scenarios/joss/measurements-p4-owner-3" :pathname "scenarios/joss/validation")
   (:file "scenarios/joss/output" :pathname "scenarios/joss/output")
   (:file "scenarios/joss/run" :pathname "scenarios/joss/run")
   (:file "scenarios/cliff/run" :pathname "scenarios/cliff/run")
   (:file "scenarios/triaxial/package" :pathname "src/simulation/compatibility/triaxial-package")
   (:file "scenarios/triaxial/package-p4-owner-2" :pathname "scenarios/triaxial/state")
   (:file "scenarios/triaxial/config" :pathname "src/simulation/config/legacy-triaxial-values")
   (:file "scenarios/triaxial/config-p4-owner-2" :pathname "scenarios/triaxial/config")
   (:file "scenarios/triaxial/config-p4-owner-3" :pathname "src/output/legacy-triaxial-json")
   (:file "scenarios/triaxial/config-p4-owner-4" :pathname "materials/adapters/diagnostics-call")
   (:file "scenarios/triaxial/tensors" :pathname "src/numerics/legacy-tensors")
   (:file "scenarios/triaxial/tensors-p4-owner-2" :pathname "src/measurements/legacy-particle")
   (:file "scenarios/triaxial/tensors-p4-owner-3" :pathname "scenarios/triaxial/stress-measures")
   (:file "scenarios/triaxial/tensors-p4-owner-4" :pathname "src/measurements/legacy-stress")
   (:file "scenarios/triaxial/material" :pathname "materials/adapters/triaxial")
   (:file "scenarios/triaxial/material-p4-owner-2" :pathname "materials/adapters/legacy-triaxial")
   (:file "scenarios/triaxial/geometry" :pathname "scenarios/triaxial/geometry")
   (:file "scenarios/triaxial/boundaries" :pathname "src/boundaries/pressure/isotropic")
   (:file "scenarios/triaxial/measurements" :pathname "scenarios/triaxial/measurements")
   (:file "scenarios/triaxial/mpm" :pathname "scenarios/triaxial/mpm")
   (:file "scenarios/triaxial/homogeneous" :pathname "scenarios/triaxial/homogeneous")
   (:file "scenarios/triaxial/controls" :pathname "scenarios/triaxial/controls")
   (:file "scenarios/triaxial/runner" :pathname "scenarios/triaxial/runner")
   (:file "scenarios/triaxial/adapter" :pathname "scenarios/triaxial/adapter")
   (:file "scenarios/cliff/adapter" :pathname "scenarios/cliff/adapter")
   (:file "scenarios/cliff/adapter-p4-owner-2" :pathname "materials/adapters/cliff")
   (:file "scenarios/cliff/adapter-p4-owner-3" :pathname "scenarios/cliff/execute")
   (:file "src/output/retained-history")
   (:file "scenarios/slope-descent/package")
   (:file "scenarios/slope-descent/configuration")
   (:file "scenarios/slope-descent/geometry")
   (:file "scenarios/slope-descent/boundary")
   (:file "scenarios/slope-descent/wang2017-output")
   (:file "scenarios/slope-descent/runner")
   (:file "scenarios/slope-descent/adapter")
   (:file "scenarios/slope-creep/package")
   (:file "scenarios/slope-creep/configuration")
   (:file "scenarios/slope-creep/measurements")
   (:file "scenarios/slope-creep/loading")
   (:file "scenarios/slope-creep/loading-output")
   (:file "scenarios/slope-creep/runner")
   (:file "scenarios/slope-creep/adapter")
   (:file "scenarios/gravity-slope/package")
   (:file "scenarios/gravity-slope/configuration")
   (:file "scenarios/gravity-slope/geometry")
   (:file "scenarios/gravity-slope/measurements")
   (:file "scenarios/gravity-slope/runner")
   (:file "scenarios/gravity-slope/adapter")))

(asdf:defsystem "cl-mpm-framework/mc-composite-apex"
  :description "Optional explicit apex-flow material diagnostics for native framework cases"
  :depends-on ("cl-mpm-framework" "cl-mpm/models/mc-composite-apex")
  :serial t
  :components ((:file "materials/adapters/mc-composite-apex")
               (:file "scenarios/gravity-slope/mc-composite-apex-adapter")))

(asdf:defsystem "cl-mpm-framework/urmi-strength-transfer"
  :description "Optional atomic drained-to-undrained native material transfer; no MPM runner"
  :depends-on ("cl-mpm-framework" "cl-mpm/models/urmi-strength-damage")
  :serial t
  :components ((:file "scenarios/urmi-damage40/package")
               (:file "scenarios/urmi-damage40/transfer")))

(asdf:defsystem "cl-mpm-framework/urmi-output-streams"
  :description "Owned fresh Urmi output retention during errors; no engine dependencies"
  :serial t
  :components ((:file "scenarios/urmi-damage40/output-streams")))

(asdf:defsystem "cl-mpm-framework/urmi-damage40"
  :description "Owned40-degree soil MC drained equilibrium and undrained strength-damage experiment"
  :depends-on ("cl-mpm-framework" "cl-mpm-framework/urmi-strength-transfer" "cl-mpm/models/urmi-strength-damage"
               "cl-mpm-framework/urmi-output-streams")
  :serial t
  :components ((:file "scenarios/urmi-damage40/recipe-package")
               (:file "scenarios/urmi-damage40/configuration")
               (:file "scenarios/urmi-damage40/geometry")
               (:file "scenarios/urmi-damage40/output")
               (:file "scenarios/urmi-damage40/runner")
               (:file "scenarios/urmi-damage40/adapter")))

(asdf:defsystem "cl-mpm-framework/urmi-damage40-rapid"
  :description "Explicit coarse approximate Urmi-like 40-degree visual demonstration"
  :depends-on ("cl-mpm-framework/urmi-damage40")
  :serial t
  :components ((:file "scenarios/urmi-damage40/rapid")))

(asdf:defsystem "cl-mpm-framework/urmi-damage40-extended"
  :description "Approved12m left extension and8m foundation rough MC damage demo"
  :depends-on ("cl-mpm-framework/urmi-damage40-rapid")
  :serial t
  :components ((:file "scenarios/urmi-damage40/extended")))

(asdf:defsystem "cl-mpm-framework/urmi-damage40-proper"
  :description "Opt-in measured-equilibrium h1/PPC2 volume-domain Urmi numerical trial"
  :depends-on ("cl-mpm-framework/urmi-damage40")
  :serial t
  :components ((:file "scenarios/urmi-damage40/proper")))

(asdf:defsystem "cl-mpm-framework/residual-clay-slope"
  :description "Human-approved peak-initial residual clay, quarter residual frictional strength"
  :depends-on ("cl-mpm-framework/urmi-damage40-proper")
  :serial t
  :components ((:file "scenarios/residual-clay-slope/package")
               (:file "scenarios/residual-clay-slope/output")
               (:file "scenarios/residual-clay-slope/runner")))

(asdf:defsystem "cl-mpm-framework/residual-clay-hs-apex"
  :description "Explicit opt-in HS clay apex extension, no-notch gravity slope"
  :depends-on ("cl-mpm-framework/residual-clay-slope" "cl-mpm/models/mc-hs-apex"))

(asdf:defsystem "cl-mpm-framework/clay-toe-profile"
  :description "Explicit two-angle no-notch clay geometry comparison with separate strain/damage observation"
  :depends-on ("cl-mpm-framework/residual-clay-hs-apex")
    :serial t
    :components ((:file "scenarios/residual-clay-slope/toe-profile")
                 (:file "scenarios/residual-clay-slope/adaptive-kinematics")))
