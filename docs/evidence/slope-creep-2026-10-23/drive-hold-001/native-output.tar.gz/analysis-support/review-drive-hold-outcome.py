"""Interpret saved measurements; never run or modify the MPM solver."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sys

import numpy as np

root = Path('D:/MPM')
sys.path.insert(0, str(root / 'scripts'))
from plot_m5_cliff_comparison import read_cliff_vtk

run = root / 'output/slope-creep-2026-10-23/drive-hold-001'
reference = root / 'output/slope-creep-2026-10-22/hold-30s-001'
review = json.loads((run / 'drive-hold-review.json').read_text())
manifest = json.loads((run / 'manifest.json').read_text())
def rows(path):
    with path.open(newline='') as stream:
        return [{k: float(v.lower().replace('d', 'e')) for k, v in r.items()}
                for r in csv.DictReader(stream)]

contact = rows(run / 'loading-history.csv')
reference_rows = rows(reference / 'creep-history.csv')
baseline, baseline_fields = read_cliff_vtk(reference / 'vtk/particles_0000.vtk')
ids = baseline_fields['unique-id']
order = np.argsort(ids)
baseline, ids = baseline[order], ids[order]
weights = baseline_fields['mass'][order]
region = baseline[:, 1] > manifest['config']['baseHeight']
tangent = np.array([review['downslopeDirection']['x'], review['downslopeDirection']['y']])
samples = []
for time in (5.0, 7.5, 10.0):
    matches = [r for r in reference_rows if r['time_s'] == time]
    assert len(matches) == 1
    row = matches[0]
    points, fields = read_cliff_vtk(reference / 'vtk' / f'particles_{int(row["frame"]):04d}.vtk')
    ordering = np.argsort(fields['unique-id'])
    assert np.array_equal(fields['unique-id'][ordering], ids)
    displacement = np.average(points[ordering][region, :2] - baseline[region, :2],
                              axis=0, weights=weights[region])
    samples.append({'timeS': time, 'centroidDxM': float(displacement[0]),
                    'centroidDyM': float(displacement[1]),
                    'downslopeProjectionM': float(displacement @ tangent),
                    'crestSettlementM': row['crest_settlement_m'],
                    'maxDisplacementM': row['max_displacement_m']})
secants = [(b['downslopeProjectionM'] - a['downslopeProjectionM']) / (b['timeS'] - a['timeS'])
           for a, b in zip(samples, samples[1:])]
unloaded = [r for r in contact if r['time_s'] > 0 and r['active_contacts'] == 0
            and r['separated_contacts'] == manifest['pusherContactCount']
            and r['reaction_upward_N_per_m'] == 0]
result = {
    'sourceCommit': '733996a3799e48253691f244862d65b1932f665f',
    'nativeTimeS': 10.0, 'landslideVerified': False, 'scientificValidation': False,
    'visualReview': 'Unamplified final overview/contact plots inspected: distributed creep, no detached sliding mass or clear run-out; saved centers inside viewport',
    'firstSavedFullyUnloadedTimeS': min(r['time_s'] for r in unloaded),
    'lastSavedFullyUnloadedTimeS': max(r['time_s'] for r in unloaded),
    'unloadedSamples': len(unloaded),
    'holdCommandWorkConstant': review['hold']['commandWorkExactlyConstantAcrossSavedHold'],
    'commandWorkRectangleJPerM': review['hold']['commandWorkAtFinalFrameJPerM'],
    'maximumSavedCompressionGapM': max(r['max_compression_gap_m'] for r in contact),
    'peakSavedReactionNPerM': max(r['reaction_upward_N_per_m'] for r in contact),
    'minimumSavedJ': min(f['minimumJFromNativeHistory'] for f in review['frames']),
    'gravityOnlyExactTimeReference': str(reference),
    'gravityReferenceRegionParticleCount': int(region.sum()),
    'gravityOnlySamples': samples,
    'gravityOnlyDownslopeCentroidSecantsMPerS': secants,
    'interpretation': 'Driven hold centroid secants rise slightly, but remain below gravity-only projections; KE/max speed decay. Only one sampled second is fully unloaded. No runaway/landslide validation.',
    'nextBoundedStudy': 'Observe the unchanged command/material to20s total to resolve post-release motion, not to assume that extra time causes failure',
    'stopRule': 'If extended unloaded response decays or levels, do not repeat duration-only studies; report current mechanism limitation before a separate material/geometry study',
    'scope': 'Exact saved-time comparison, no interpolation. Downslope projection includes settlement; work is a rectangle estimate and a fixed driver can still release stored contact energy.',
    'scriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(run / 'interpretation.json').write_text(json.dumps(result, indent=2) + '\n')
shutil.copy2(__file__, run / 'analysis-support' / Path(__file__).name)
print(json.dumps(result, indent=2))
