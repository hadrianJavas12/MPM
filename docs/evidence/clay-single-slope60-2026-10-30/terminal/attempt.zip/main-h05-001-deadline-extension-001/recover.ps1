param([string]$RunDirectory)
$ErrorActionPreference='Stop'
$r=$RunDirectory
$d=$r+'-monitor-recovery-001'
$s=Get-Content ($r+'-deadline-extension-001/extended-status.json') -Raw|ConvertFrom-Json -AsHashtable
function Save-Status {
 $s.heartbeatUtc=[DateTime]::UtcNow.ToString('o')
 try { $m=Get-Content "$r/manifest.json" -Raw|ConvertFrom-Json -AsHashtable; $s.progress=$m } catch {}
 $json=$s|ConvertTo-Json -Depth 15
 for($i=0;$i -lt 20;$i++) { try { [IO.File]::WriteAllText($r+'-status.json',$json); return } catch [IO.IOException] { Start-Sleep -Milliseconds 200 } }
 throw 'Status write retries exhausted; retained native handle remains unmodified.'
}
try {
 $p=Get-Process -Id $s.processIdentity.nativeCommand.pid
 $null=$p.Handle
 $actual=$p.StartTime.ToUniversalTime()
 $expected=([DateTime]$s.processIdentity.nativeCommand.createdUtc).ToUniversalTime()
 if([Math]::Abs(($actual-$expected).TotalMilliseconds) -gt 2 -or $p.ProcessName -ne 'cmd') { throw 'Exact native command identity mismatch' }
 $b=Get-Process -Id $s.processIdentity.sbcl.pid
 if([Math]::Abs(($b.StartTime.ToUniversalTime()-([DateTime]$s.processIdentity.sbcl.createdUtc).ToUniversalTime()).TotalMilliseconds) -gt 2 -or $b.ProcessName -ne 'sbcl') { throw 'Exact SBCL identity mismatch' }
 $s.status='NATIVE_RUNNING'; $s.monitorRecovery=[ordered]@{processId=$PID;startedUtc=[DateTime]::UtcNow.ToString('o');originalStatus="$d/original-status.json";nativeReruns=0;originalError=$s.error}
 $s.Remove('endedUtc');$s.Remove('error');Save-Status
 $ps=(Get-Process -Id $PID).Path
 $watch=$r+'-deadline-extension-001/watch-media.ps1'
 $media=Start-Process -FilePath $ps -ArgumentList @('-NoProfile','-NonInteractive','-File',('"'+$watch+'"'),'-RunDirectory',('"'+$r+'"')) -WindowStyle Hidden -PassThru -RedirectStandardOutput ($r+'-deadline-extension-001/media.stdout.log') -RedirectStandardError ($r+'-deadline-extension-001/media.stderr.log')
 $s.monitorRecovery.mediaProcessId=$media.Id;Save-Status
 $deadline=([DateTime]$s.wallDeadlineUtc).ToUniversalTime()
 while(-not $p.HasExited) {
  $remaining=($deadline-[DateTime]::UtcNow).TotalMilliseconds
  if($remaining -le 0) { $p.Kill($true);$p.WaitForExit();$s.status='STOPPED_WALL_BUDGET';break }
  if($p.WaitForExit([int][Math]::Min(60000,$remaining))) {break};Save-Status
 }
 $p.Refresh();$s.nativeExitCode=$p.ExitCode;$s.endedUtc=[DateTime]::UtcNow.ToString('o')
 if($s.status -ne 'STOPPED_WALL_BUDGET') {
  $m=Get-Content "$r/manifest.json" -Raw|ConvertFrom-Json
  $s.nativeComplete=[bool]$m.complete
  $s.status=if($p.ExitCode -ne 0){'FAILED_NATIVE'}elseif($m.complete){'NATIVE_COMPLETE_REVIEW_PENDING'}else{'INCOMPLETE_NATIVE'}
 }
 Save-Status
} catch { $_|Out-String|Set-Content "$d/recovery-error.txt";throw }


