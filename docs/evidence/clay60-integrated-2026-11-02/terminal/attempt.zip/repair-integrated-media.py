from pathlib import Path
import shutil,json,hashlib
r=Path('D:/MPM');base=r/'output/clay60-integrated-2026-11-02';run=base/'integrated-h05-001'
prep=base/'saved-media-repair-001';a=prep/'analysis';a.mkdir(parents=True,exist_ok=False)
old=Path(str(run)+'-launch-preparation')/'analysis'
for name in ['review-clay-single-slope60.py','review-urmi-damage40.py','plot_m5_cliff_comparison.py','preview-urmi-damage40.py']:shutil.copyfile(old/name,a/name)
p=a/'review-clay-single-slope60.py';s=p.read_text()
s=s.replace('MOVIE_FPS=5','MOVIE_FPS=5\nAUDIT_FAILURES=[]')
oldline="        require((j>0).all() and (mass>0).all() and (v0>0).all() and helper.close(np.linalg.det(f),j) and helper.close(v['volume_m3_per_m'],j*v0),'F/J/positive mass/originalV0 identity failed')"
assert oldline in s
s=s.replace(oldline,"""        require((j>0).all() and (mass>0).all() and (v0>0).all(), 'Nonpositive J/mass/V0; diagnostic export refused')
        for label,actual,expected in [('numpyDetF-versus-nativeJ',np.linalg.det(f),j),('volume-versus-nativeJtimesV0',v['volume_m3_per_m'],j*v0)]:
            if not helper.close(actual,expected):
                bad=np.abs(actual-expected)>(helper.ATOL+helper.RTOL*np.abs(expected))
                worst=int(np.argmax(np.abs(actual-expected)))
                AUDIT_FAILURES.append({'frame':frame,'check':label,'failedMPs':int(bad.sum()),'maxAbsError':float(np.abs(actual-expected).max()),'worstParticleId':worst,'actual':float(actual[worst]),'expected':float(expected[worst]),'atol':helper.ATOL,'rtol':helper.RTOL})""")
oldpatch='''    require(np.isfinite(vertices).all() and np.all(area>0) and
            np.allclose(area, values["J"]*values["reference_volume_m3_per_m"],rtol=2e-9,atol=1e-12),
            "Actual deformed patch area disagrees with positive J*originalV0")'''
assert oldpatch in s
s=s.replace(oldpatch,'''    require(np.isfinite(vertices).all() and np.all(area>0), "Nonfinite/nonpositive actual patch area; diagnostic export refused")
    expected=values["J"]*values["reference_volume_m3_per_m"]
    if not np.allclose(area,expected,rtol=2e-9,atol=1e-12):
        AUDIT_FAILURES.append({"check":"actual-patch-area-versus-nativeJtimesV0","timeS":float(values["time_s"][0]),"maxAbsError":float(np.abs(area-expected).max()),"rtol":2e-9,"atol":1e-12})''')
s=s.replace("'savedIntegrity':'PASS'","'savedIntegrity':'FAILED', 'diagnosticOnly':True, 'auditFailures':AUDIT_FAILURES")
s=s.replace('else "PARTIAL TRIAL"','else "PARTIAL DIAGNOSTIC | INTEGRITY FAILED"')
s=s.replace('overlaps/gaps retained; no calibrated validation','overlaps/gaps retained; INTEGRITY FAILED; no calibrated validation')
p.write_text(s,encoding='utf8')
records=[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(a.glob('*.py'))]
(prep/'repair-freeze.json').write_text(json.dumps(dict(scope='SAVED-DATA ONLY diagnostic export. Original observer/failed001 retained; strict thresholds unchanged and failures retained, never PASS. No native rerun/input mutation. Other original source/law/IDs/yield checks remain mandatory.',records=records),indent=2))
print(str(p))
