from pathlib import Path
import json,hashlib,zipfile,shutil
r=Path('D:/MPM');base=r/'output/clay60-integrated-2026-11-02';run=base/'integrated-h05-001';review=run/'filled-review-002'
report=json.loads((review/'review.json').read_text());assert report['savedIntegrity']=='FAILED' and len(report['states'])==15
dest=r/'docs/evidence/clay60-integrated-2026-11-02/terminal';dest.mkdir(exist_ok=False)
for name in ['audit-integrated-terminal.py','repair-integrated-media.py','archive-integrated-terminal.py']:
 shutil.copyfile(r/'tmp'/name,base/name)
h=lambda b:hashlib.sha256(b).hexdigest()
files=sorted(p for p in base.rglob('*') if p.is_file() and (p.relative_to(base).parts[0].startswith('integrated-h05-001') or p.relative_to(base).parts[0].startswith('saved-media-repair-001')))
files += [base/name for name in ['terminal-observation.json','startup-proof.json','launch-git-proof.json','audit-integrated-terminal.py','repair-integrated-media.py','archive-integrated-terminal.py','media-recovery-receipt.json']]
seen={};records=[]
with zipfile.ZipFile(dest/'attempt.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in files:
  b=p.read_bytes();digest=h(b);name=p.relative_to(base).as_posix();canonical=seen.get(digest)
  if canonical is None:z.writestr(name,b);seen[digest]=name;canonical=name
  records.append(dict(path=name,bytes=len(b),sha256=digest,canonical=canonical))
with zipfile.ZipFile(dest/'attempt.zip') as z:
 for rec in records:assert h(z.read(rec['canonical']))==rec['sha256']
for name in ['soil-motion.mp4','strength-damage.mp4','plastic-shear-strain.mp4','proper-motion-result.png','proper-damage-result.png','proper-plastic-strain-result.png','review.json']:
 shutil.copyfile(review/name,dest/name)
summary=dict(scope='Partial integrated-GIMP clay60 DIAGNOSTIC, SAVED INTEGRITY FAILED, not physical validation',sourceCommit='eea21e935fbbe44e72468c43f6b2db6f145da9d4',nativeExit=1,nativeEndedUtc='2026-11-02T10:03:53.8307093Z',attemptedTimeS=7.5,updates=8516,savedTimesS=[i*.5 for i in range(15)],particles=13517,failure='Actual output-state guard ID8040 V=J*V0 mismatch5.16333e-10>1e-10 bound; highFsingular4604.39. Not DFnegative/gridescape. Full7.5s snapshot not saved.',strictSavedAudit='FAILED at6/6.5/7s volume/FJ serialization thresholds unchanged; all failures retained in diagnostic review002. Original failed review001 preserved.',noSolverReruns=True,archiveRecords=records,uniqueZipMembers=len(seen),interpretation='Longer saved duration7s vs old5s; no full8s or scientificPASS. AllactualMP Fpatches retain extreme distortion beyondgrid; patchtips not runout. Videos labeled INTEGRITY FAILED.',media='Three diagnostic videos0..7s,all15states/all13517MP; no temporal interpolation/filtering',additionalAudit='terminal-observation.json in ZIP')
(dest/'manifest.json').write_text(json.dumps(summary,indent=2)+'\n')
idx=[dict(path=p.name,bytes=p.stat().st_size,sha256=h(p.read_bytes())) for p in sorted(dest.iterdir()) if p.is_file()]
(dest/'sha256-index.json').write_text(json.dumps(idx,indent=2)+'\n')
print(json.dumps(dict(records=len(records),members=len(seen),zipBytes=(dest/'attempt.zip').stat().st_size,indexed=len(idx))))
