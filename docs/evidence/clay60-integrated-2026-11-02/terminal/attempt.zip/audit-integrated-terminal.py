from pathlib import Path
import json,sys,importlib.util,decimal
import numpy as np
r=Path('D:/MPM');base=r/'output/clay60-integrated-2026-11-02';run=base/'integrated-h05-001'
a=Path(str(run)+'-launch-preparation')/'analysis'
def mod(name,file):
 spec=importlib.util.spec_from_file_location(name,a/file);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
h=mod('terminalhelper','review-urmi-damage40.py');rows=[];initial=None
for frame,v in h.csv_frames(run/'material-state.csv'):
 assert len(v['particle_id'])==13517 and np.array_equal(v['particle_id'],np.arange(13517))
 assert all(np.isfinite(x).all() for x in v.values())
 f=np.column_stack([v['F_'+str(i)+str(j)] for i in range(3) for j in range(3)]).reshape(-1,3,3)
 sv=np.linalg.svd(f,compute_uv=False);det=np.linalg.det(f)
 if initial is None:initial=np.column_stack([v['initial_x_m'],v['initial_y_m']]);mass=v['mass_kg_per_m'].copy();v0=v['reference_volume_m3_per_m'].copy()
 assert np.array_equal(mass,v['mass_kg_per_m']) and np.array_equal(v0,v['reference_volume_m3_per_m'])
 xy=np.column_stack([v['x_m'],v['y_m']]);vel=np.column_stack([v['vx_m_per_s'],v['vy_m_per_s']]);upper=(initial[:,0]>14)&(initial[:,1]>10)
 row=dict(frame=frame,timeS=float(v['time_s'][0]),minJ=float(v['J'].min()),maxJ=float(v['J'].max()),maxFSingular=float(sv.max()),maxFCondition=float((sv[:,0]/sv[:,-1]).max()),mass=float(mass.sum()),maxSpeed=float(np.linalg.norm(vel,axis=1).max()),kineticJPerM=float((.5*mass*np.sum(vel*vel,axis=1)).sum()),maxDisplacement=float(np.linalg.norm(xy-initial,axis=1).max()),upperMeanVx=float(np.average(vel[upper,0],weights=mass[upper])),upperCentroidDelta=np.average((xy-initial)[upper],axis=0,weights=mass[upper]).tolist(),minGridCenterMargin=float(np.min(np.column_stack([xy[:,0],72-xy[:,0],xy[:,1],24-xy[:,1]]))),maxDetDifference=float(np.abs(det-v['J']).max()),maxVolumeDifference=float(np.abs(v['volume_m3_per_m']-v['J']*v0).max()))
 rows.append(row)
failure=json.loads((run/'output-state-failure.json').read_text());F=failure['F'];D=decimal.Decimal;decimal.getcontext().prec=60
exact=D.from_float(F[0])*D.from_float(F[4])-D.from_float(F[1])*D.from_float(F[3])
trace=json.loads((run/'step-trace.json').read_text())
summary=dict(scope='Actual terminal saved-only numerical audit; no source/raw mutation/no native rerun/no scientific validation',states=rows,allSavedMPFinite=True,allIDsMassV0Constant=True,failure=failure,failedFExactBinaryDecimalDet=str(exact),failedFMathematicalVolumeError=str(D.from_float(failure['volume'])-exact*D.from_float(failure['originalV0'])),failedFSingular=np.linalg.svd(np.array(F).reshape(3,3),compute_uv=False).tolist(),lastPeriodicTrace=dict(stepOrdinal=trace['stepOrdinal'],nativeTimeS=trace['nativeTimeS'],cache=trace['cache'],adaptiveStep=trace['adaptiveStep'],forceStages=trace['currentForceStages']),actualStepFailureExists=(run/'actual-step-failure.json').exists(),actualDfFailureExists=(run/'actual-df-failure.json').exists(),interpretation='15 complete saved states0..7s; native output guard fails at7.5s/8516updates. Strict saved observer also rejects F/J identity. Large accumulated F/cancellation and tiny volume mismatch must remain failures, not silently relaxed. Not8s or calibratedrunout. Last periodic trace8500 does not supply last16steps or failed8040 velocity.')
(base/'terminal-observation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(savedStates=len(rows),lastSaved=rows[-1],failedFSingular=summary['failedFSingular'],failureVolumeError=failure['volumeError'],exactVolumeError=summary['failedFMathematicalVolumeError'],lastTrace=summary['lastPeriodicTrace']['nativeTimeS'],cache=trace['cache']),indent=2))
