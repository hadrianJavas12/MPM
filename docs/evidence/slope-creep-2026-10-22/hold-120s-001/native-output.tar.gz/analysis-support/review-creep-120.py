"""Read-only native review plus an explicitly analytical, separate material check."""
import csv
import importlib.util
import json
import math
from pathlib import Path

root = Path(r'D:\MPM')
run = root / 'output/slope-creep-2026-10-22/hold-120s-001'
with (run / 'creep-history.csv').open(newline='') as stream:
    rows = [{k: float(v.lower().replace('d', 'e')) for k, v in row.items()}
            for row in csv.DictReader(stream)]
manifest = json.loads((run / 'manifest.json').read_text())
prefix = json.loads((run / 'prefix-comparison.json').read_text())
bytime = {r['time_s']: r for r in rows}
windows = [{'startS': a, 'endS': b, 'crestSettlementSecantMmPerS':
            1000 * (bytime[b]['crest_settlement_m'] - bytime[a]['crest_settlement_m']) / (b-a)}
           for a, b in [(0, 30), (30, 60), (60, 90), (90, 120)]]
spec = importlib.util.spec_from_file_location('native_reader', root / 'scripts/plot_m5_cliff_comparison.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
bounds = []
for frame in [0, 60, 240]:
    points, fields = module.read_cliff_vtk(run / f'vtk/particles_{frame:04d}.vtk')
    bounds.append({'frame': frame, 'minXY': points[:, :2].min(axis=0).tolist(),
                   'maxXY': points[:, :2].max(axis=0).tolist(),
                   'insideDisplayedViewport': bool(((points[:, 0] >= 0) & (points[:, 0] <= 20)
                                                   & (points[:, 1] >= 0) & (points[:, 1] <= 16)).all())})
review = {'nativeSourceCommit': 'cfc65e9a9b33b17c84d2906055b92a52f66b979a',
          'nativeComplete': True, 'physicalTimeS': 120, 'frames': len(rows),
          'crestSettlementM': rows[-1]['crest_settlement_m'],
          'maxDisplacementM': rows[-1]['max_displacement_m'],
          'maxCreepKappa': rows[-1]['max_creep_kappa'],
          'maxSpeedMPerS': rows[-1]['max_speed_m_per_s'],
          'sampledPeakMaxSpeedMPerS': max(r['max_speed_m_per_s'] for r in rows),
          'finalKineticJPerM': rows[-1]['kinetic_J_per_m'],
          'sampledPeakKineticJPerM': max(r['kinetic_J_per_m'] for r in rows),
          'zeroMassDrift': all(r['mass_error_fraction'] == 0 for r in rows),
          'minJAcrossSavedFrames': min(r['min_J'] for r in rows),
          'crestSecantWindows': windows, 'selectedSnapshotBounds': bounds,
          'prefixVtkFilesByteIdentical': len(prefix['vtk']) if prefix['passed'] else None,
          'prefixHistoryByteIdentical': prefix['historyPrefixByteIdentical'],
          'macroscopicLandslideVerified': False, 'scientificValidation': False,
          'visualReview': 'Distributed creep and toe/base strain concentration; no detached mass or clear run-out in reviewed particle overview.',
          'caveat': 'Late instantaneous local speed rises but does not establish sustained crest acceleration. Constant-stress analytical examples below are not full-MPM predictions.'}
(run / 'review.json').write_text(json.dumps(review, indent=2) + '\n')

config = manifest['config']
yp, yr, ks, eta = [config[k] for k in ['yieldPeakPa', 'yieldResidualPa', 'softeningKappa', 'viscosityPaS']]
h = (yp - yr) / ks
examples = []
for q in [60000., 100000., 150000.]:
    # Virgin point held strictly at q>Yp. After reaching residual strength,
    # fixed q and constant eta imply a constant positive strain rate.
    tk = eta / h * math.log((q - yr) / (q - yp))
    examples.append({'assumedConstantKirchhoffQPa': q,
                     'analyticalResidualArrivalTimeS': tk,
                     'analyticalPostResidualRatePerS': (q - yr) / eta})
capability = {'scope': 'Analytical 0D constant-stress model capability; not native MPM measurements or laboratory data',
              'inputs': {k: config[k] for k in ['yieldPeakPa', 'yieldResidualPa', 'softeningKappa', 'viscosityPaS']},
              'softeningModulusPa': h,
              'formulaBeforeResidual': 'kappa_dot=(q-Yp+H*kappa)/eta, H=(Yp-Yr)/kappa_s',
              'formulaAfterResidual': 'kappa_dot=(q-Yr)/eta for fixed q and constant eta',
              'exampleStressValuesAreAssumptions': True, 'examples': examples,
              'interpretation': 'Softening increases the 0D rate until residual strength; afterward constant stress/viscosity gives secondary creep. More time alone does not guarantee a failure transition. Full-slope geometry and stress redistribution can still change rates.',
              'nextStep': 'Review mechanism and localization/activation assumptions before changing parameters or running beyond the authorized120s.'}
(run / 'material-capability-analysis.json').write_text(json.dumps(capability, indent=2) + '\n')
print(json.dumps(review, indent=2))
