"""Read saved native data only; no solver invocation or modification of histories."""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

root = Path('D:/MPM')
run = root / 'output/slope-creep-2026-10-22/pusher-pilot-001'
def read_csv(name):
    with (run / name).open(encoding='utf-8-sig', newline='') as stream:
        return [{k: float(v.lower().replace('d', 'e')) for k, v in row.items()}
                for row in csv.DictReader(stream)]

manifest = json.loads((run / 'manifest.json').read_text())
audit = json.loads((run / 'output-audit.json').read_text())
history = read_csv('creep-history.csv')
contacts = read_csv('loading-history.csv')
assert manifest['complete'] and audit['passedConsistencyChecks']
assert audit['unilateralContactHistoryConsistent'] and len(contacts) == len(history)
count = manifest['pusherContactCount']
released = [r for r in contacts if r['time_s'] > 0 and r['active_contacts'] == 0
            and r['separated_contacts'] == count and r['reaction_upward_N_per_m'] == 0
            and r['measured_patch_settlement_m'] > r['commanded_settlement_m']]
loaded = [r for r in contacts if r['reaction_upward_N_per_m'] > 0]
module_path = root / 'scripts/plot_m5_cliff_comparison.py'
spec = importlib.util.spec_from_file_location('saved_vtk_reader', module_path)
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
viewport_ok = True
cfg = manifest['config']
for row in history:
    points, _ = reader.read_cliff_vtk(run / 'vtk' / f'particles_{int(row["frame"]):04d}.vtk')
    viewport_ok &= bool(np.all((points[:, 0] >= 0) & (points[:, 0] <= cfg['width'])
                             & (points[:, 1] >= 0)
                             & (points[:, 1] <= cfg['baseHeight'] + cfg['height'] + cfg['meshSize'])))
review = {
    'scope': 'Actual native 1s moving-driver pilot; sampled unilateral loading/release, not calibrated landslide validation',
    'sourceCommit': 'ec285c05956c1b6fd592428869fba826b7430dd9',
    'nativeComplete': manifest['complete'], 'frames': len(history),
    'particleCount': manifest['particleCount'], 'durationS': history[-1]['time_s'],
    'driverVelocityMPerS': cfg['pusherVelocity'],
    'finalCommandedSettlementM': contacts[-1]['commanded_settlement_m'],
    'finalMeasuredPatchSettlementM': contacts[-1]['measured_patch_settlement_m'],
    'finalMeanCrestSettlementM': history[-1]['crest_settlement_m'],
    'finalMaxDisplacementM': history[-1]['max_displacement_m'],
    'finalMaxSpeedMPerS': history[-1]['max_speed_m_per_s'],
    'maxAbsMassErrorFraction': max(abs(r['mass_error_fraction']) for r in history),
    'minimumSavedJacobian': min(r['min_J'] for r in history),
    'finalMaxCreepKappa': history[-1]['max_creep_kappa'],
    'positiveReactionSampleTimesS': [r['time_s'] for r in loaded],
    'maxSavedReactionNPerM': max(r['reaction_upward_N_per_m'] for r in contacts),
    'maxSavedCompressionGapM': max(r['max_compression_gap_m'] for r in contacts),
    'allContactsReleasedSampleTimesS': [r['time_s'] for r in released],
    'finalActiveContacts': contacts[-1]['active_contacts'],
    'finalSeparatedContacts': contacts[-1]['separated_contacts'],
    'finalReactionNPerM': contacts[-1]['reaction_upward_N_per_m'],
    'allSavedParticlesInsideOverviewViewport': viewport_ok,
    'sampledDynamicLoadingAndReleaseVerified': bool(loaded and released),
    'landslideVerified': False, 'scientificValidation': False,
    'morphologyReview': 'Unamplified overview inspected: small distributed creep, no detached mass or run-out',
    'limits': ['Contact force/gaps are the last predicted BC evaluation; settlement is current MP geometry',
               '0.1s samples do not establish zero force at every intervening step or an integrated actuator-work budget',
               'Original tracked surface/profile, finite penalty, no new surface search/tangential traction',
               'The inherited penalty timestep and actual early contact force differ from the gravity-only pilot; do not call them an exact physics match',
               'Slow driver releases once soil moves ahead; this pilot does not justify a long run as a sustained loading experiment'],
    'reviewScriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(run / 'review.json').write_text(json.dumps(review, indent=2) + '\n')
times = [r['time_s'] for r in contacts]
fig, axes = plt.subplots(1, 3, figsize=(13.5, 3.8), constrained_layout=True)
axes[0].plot(times, [r['commanded_settlement_m'] * 1000 for r in contacts], '--', label='Driver command')
axes[0].plot(times, [r['measured_patch_settlement_m'] * 1000 for r in contacts], label='Measured tracked soil patch')
axes[0].set(ylabel='Downward settlement (mm)', title='Soil can move ahead')
axes[0].legend(fontsize=8)
axes[1].plot(times, [r['reaction_upward_N_per_m'] / 1000 for r in contacts], 'o-')
axes[1].set(ylabel='Upward actuator reaction (kN/m)', title='Saved compressive reaction')
axes[2].step(times, [r['active_contacts'] for r in contacts], where='post', label='Active')
axes[2].step(times, [r['separated_contacts'] for r in contacts], where='post', label='Unloaded')
axes[2].set(ylabel='Tracked contact count', title='Saved contact evaluations')
axes[2].legend(fontsize=8)
for ax in axes:
    ax.set_xlabel('Actual simulation time (s)')
    ax.grid(alpha=.25)
fig.suptitle('Native one-way pusher pilot | 0.005 m/s command, free soil | 0.1 s samples, no lab calibration')
fig.savefig(run / 'contact-diagnostics.png', dpi=140)
plt.close(fig)
support = run / 'analysis-support'
support.mkdir(exist_ok=True)
shutil.copy2(__file__, support / Path(__file__).name)
print(json.dumps(review, indent=2))
