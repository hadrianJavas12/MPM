"""ONE saved worker discrepancy diagnosis; no pass-tolerance change or MPM call."""
from pathlib import Path
import csv
import json
import math
import hashlib
from datetime import datetime, timezone
import numpy as np

BASE = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parents[1]
ATOL = RTOL = 1e-11
TIME_ATOL = TIME_RTOL = 1e-10
EXACT = {"frame", "particle_id", "phase_code", "damage_active", "free_upper_reference_subset", "particle_count",
         "updates", "dynamic_updates", "preparation_updates", "force_ratio_defined", "free_ke_ratio_defined"}


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def csv_values(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        columns = reader.fieldnames
        rows = [{k: float(v.replace("D", "E").replace("d", "e")) for k, v in row.items()} for row in reader]
    return {key: np.asarray([row[key] for row in rows]) for key in columns}


def location(values, i):
    return {key: float(values[key][i]) for key in ("frame", "particle_id", "phase_code", "time_s", "native_time_s", "x_m", "y_m", "initial_x_m", "initial_y_m") if key in values}


def statistics(a, b, key, values):
    assert a.shape == b.shape and np.isfinite(a).all() and np.isfinite(b).all()
    delta = b - a
    absolute = np.abs(delta)
    time = "time" in key
    atol, rtol = (TIME_ATOL, TIME_RTOL) if time else (ATOL, RTOL)
    limit = atol + rtol * np.abs(b)
    failed = (a != b) if key in EXACT else absolute > limit
    denom = np.maximum(np.abs(a), np.abs(b))
    relative = np.divide(absolute, denom, out=np.zeros_like(absolute), where=denom > 0)
    maximum = int(np.argmax(absolute))
    ratio = np.divide(absolute, limit)
    record = {"rows": int(len(a)), "exactlyDifferentRows": int(np.count_nonzero(delta)), "fixedToleranceExceededRows": int(failed.sum()),
              "maximumAbsoluteDelta": float(absolute[maximum]), "maximumRelativeDelta": float(relative.max()),
              "maximumToleranceRatio": float(ratio.max()), "maxAbsLocation": location(values, maximum),
              "serialAtMaxAbs": float(a[maximum]), "parallelAtMaxAbs": float(b[maximum]),
              "absoluteDeltaQuantiles": dict(zip(("p50", "p90", "p99", "p100"), map(float, np.quantile(absolute, [0.5, 0.9, 0.99, 1])))),
              "phaseFrames": []}
    if "frame" in values:
        for frame in np.unique(values["frame"]):
            mask = values["frame"] == frame
            record["phaseFrames"].append({"frame": int(frame), "phaseCode": int(values["phase_code"][mask][0]) if "phase_code" in values else None,
                "rows": int(mask.sum()), "fixedToleranceExceededRows": int(failed[mask].sum()),
                "maximumAbsoluteDelta": float(absolute[mask].max()), "maximumRelativeDelta": float(relative[mask].max()),
                "maximumToleranceRatio": float(ratio[mask].max())})
    if failed.any() and "initial_x_m" in values:
        record["exceedanceInitialBBoxM"] = {key: [float(values[key][failed].min()), float(values[key][failed].max())]
                                             for key in ("initial_x_m", "initial_y_m")}
        record["firstFiveExceedances"] = [{"location": location(values, int(i)), "serial": float(a[i]), "parallel": float(b[i]),
            "delta": float(delta[i]), "fixedLimit": float(limit[i])} for i in np.flatnonzero(failed)[:5]]
    return record


def json_deltas(a, b, path="root", findings=None):
    if findings is None:
        findings = {"differentNumbers": [], "differentStructuralOrTextValues": []}
    if isinstance(a, dict) and isinstance(b, dict):
        if a.keys() != b.keys():
            findings["differentStructuralOrTextValues"].append({"path": path, "serialKeys": list(a), "parallelKeys": list(b)})
        for key in a.keys() & b.keys():
            json_deltas(a[key], b[key], f"{path}/{key}", findings)
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            findings["differentStructuralOrTextValues"].append({"path": path, "serialLength": len(a), "parallelLength": len(b)})
        for i, (x, y) in enumerate(zip(a, b)):
            json_deltas(x, y, f"{path}/{i}", findings)
    elif isinstance(a, (int, float)) and not isinstance(a, bool) and isinstance(b, (int, float)) and not isinstance(b, bool):
        assert math.isfinite(a) and math.isfinite(b)
        if a != b:
            findings["differentNumbers"].append({"path": path, "serial": a, "parallel": b, "absoluteDelta": abs(b-a),
                "fixedToleranceExceeded": abs(b-a) > ATOL + RTOL * abs(b)})
    elif a != b:
        findings["differentStructuralOrTextValues"].append({"path": path, "serial": a, "parallel": b})
    return findings


before = load(OUT / "invocation-before.json")
assert all(sha(Path(row["path"])) == row["sha256"] for row in before["inputs"])
assert sha(Path(__file__)) == before["analysisSha256"]
report = {"scope": "ONE saved discrepancy diagnosis after worker-comparison-001 failure; no relaxed tolerance/new native/replay/render or production change",
          "createdUtc": datetime.now(timezone.utc).isoformat(), "firstComparison": load(BASE / "worker-comparison-001/review.json"),
          "stateAtol": ATOL, "stateRtol": RTOL, "timeAtol": TIME_ATOL, "timeRtol": TIME_RTOL, "tables": {}, "jsonState": {}}
serial, parallel = BASE / "workers1-001", BASE / "workers4-001"
for name in ("material-state.csv", "history.csv", "native-state-extra.csv"):
    a, b = csv_values(serial / name), csv_values(parallel / name)
    assert a.keys() == b.keys()
    for identity in ("frame", "particle_id", "phase_code"):
        if identity in a:
            assert np.array_equal(a[identity], b[identity]), (name, identity)
    fields = {key: statistics(a[key], b[key], key, a) for key in a}
    report["tables"][name] = {"rows": len(next(iter(a.values()))), "fields": fields,
       "fieldsExceedingFixedTolerance": [key for key in fields if fields[key]["fixedToleranceExceededRows"]],
       "fieldsExactlyIdentical": [key for key in fields if fields[key]["exactlyDifferentRows"] == 0]}
for name in ("plastic-inputs-before.json", "plastic-results.json", "expected-rejection-input-before.json", "expected-rejection-capsule.json"):
    report["jsonState"][name] = json_deltas(load(serial / name), load(parallel / name))
results = [load(directory / "result.json") for directory in (serial, parallel)]
report["nativeResults"] = [{"workers": row["workers"], "passed": row["passed"], "groups": row["passedGroups"], "counters": row["counters"],
                            "mappedDllSha256": row["nativeBackend"]["sha256"]} for row in results]
report["counterEquality"] = results[0]["counters"] == results[1]["counters"]
report["configDeltas"] = json_deltas(results[0]["observations"]["physicalConfig"], results[1]["observations"]["physicalConfig"])
payloads = [{row["path"]: row["sha256"] for row in load(directory / "source/source-manifest.json")["files"]} for directory in (serial, parallel)]
report["sourceManifestPayloadSame"] = payloads[0] == payloads[1]
report["sourcePayloadCount"] = list(map(len, payloads))
report["timingsNotAcceptance"] = []
timings = [{row["name"]: row for row in result["timings"]} for result in results]
for phase in ("drained", "undrained"):
    sums = [sum(timings[i][f"{phase}-four-USF-block{block}"]["realSeconds"] for block in range(2)) for i in range(2)]
    report["timingsNotAcceptance"].append({"workload": phase, "serialSeconds": sums[0], "parallelSeconds": sums[1], "observedRatio": sums[0]/sums[1]})
point = [row["seventy-two-native-plastic-points"]["realSeconds"] for row in timings]
report["timingsNotAcceptance"].append({"workload": "syntheticNativePlastic72", "serialSeconds": point[0], "parallelSeconds": point[1], "observedRatio": point[0]/point[1]})
assert all(sha(Path(row["path"])) == row["sha256"] for row in before["inputs"])
report["inputsUnchangedAfterAnalysis"] = True
(OUT / "diagnosis.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
summary = {"allFieldCounts": {name: len(table["fields"]) for name, table in report["tables"].items()},
           "failingFields": {name: table["fieldsExceedingFixedTolerance"] for name, table in report["tables"].items()},
           "jsonNumericDeltaCounts": {name: len(value["differentNumbers"]) for name, value in report["jsonState"].items()},
           "jsonStructuralDeltaCounts": {name: len(value["differentStructuralOrTextValues"]) for name, value in report["jsonState"].items()},
           "timingsNotAcceptance": report["timingsNotAcceptance"]}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
