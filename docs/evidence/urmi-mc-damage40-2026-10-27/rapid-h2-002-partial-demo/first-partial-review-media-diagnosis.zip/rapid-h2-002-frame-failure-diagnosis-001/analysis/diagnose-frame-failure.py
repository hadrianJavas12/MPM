"""ONE saved-only ID55 investigation; never reconstruct an absent failed state."""
from pathlib import Path
import csv
import hashlib
import json
import math
from datetime import datetime, timezone
import numpy as np

OUT = Path(__file__).resolve().parents[1]
RUN = OUT.parent / "rapid-h2-002"
ID = 55


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return [{key: float(value.replace("d", "e").replace("D", "E")) for key, value in row.items()} for row in csv.DictReader(stream)]


def vtk_point(path, target):
    data, offset = path.read_bytes(), 0
    def line():
        nonlocal offset
        end = data.index(b"\n", offset)
        result = data[offset:end].decode("ascii").rstrip("\r")
        offset = end + 1
        return result
    def doubles(n):
        nonlocal offset
        result = np.frombuffer(data, dtype=">f8", count=n, offset=offset)
        offset += n*8
        assert line() == ""
        return result
    assert line().startswith("# vtk DataFile Version")
    line()
    assert line() == "BINARY" and line() == "DATASET UNSTRUCTURED_GRID"
    header = line().split()
    assert header[0] == "POINTS"
    n = int(header[1])
    positions = doubles(n*3).reshape(n, 3)
    assert line() == f"POINT_DATA {n}"
    result = {"position": positions[target].tolist()}
    while offset < len(data):
        header = line().split()
        if not header:
            continue
        assert header[0] == "SCALARS" and line() == "LOOKUP_TABLE default"
        result[header[1]] = float(doubles(n)[target])
    return result


provenance = load(OUT / "invocation-before.json")
assert sha(Path(__file__)) == provenance["analysisSha256"]
assert all(sha(Path(row["path"])) == row["sha256"] for row in provenance["inputs"])
manifest = load(RUN / "manifest.json")
initial = next(row for row in rows(RUN / "preparation-material-state.csv") if row["particle_id"] == ID and row["phase_code"] == 0)
saved = [row for row in rows(RUN / "material-state.csv") if row["particle_id"] == ID]
ledger = load(RUN / "transfer-ledger.json")
report = {"scope": "ONE saved-only failed-frame investigation; no native/replay/render/guard modification; failed frame absent",
          "createdUtc": datetime.now(timezone.utc).isoformat(), "manifest": manifest, "initialID55": initial,
          "lastSavedID55Frames": [], "absentActualFailedState": {"frame": 5, "dynamicTimeS": manifest["timeS"], "nativeTimeS": manifest["nativeTimeS"],
          "vtkExists": (RUN / "vtk/particles_0005.vtk").exists(), "csvRowExists": any(row["frame"] == 5 for row in saved),
          "exactFailingPredicate": "NOT_DETERMINABLE_FROM_ABSENT_FAILED_TUPLE", "failedF9": "NOT_RECORDED",
          "failedDomainSizeXY": "NOT_RECORDED", "failedV_J_V0_kappa_work_residualTolerance": "NOT_RECORDED"}}
for row in saved:
    frame = int(row["frame"])
    vtk = vtk_point(RUN / f"vtk/particles_{frame:04d}.vtk", ID)
    f = np.asarray([row[f"F_{i}{j}"] for i in range(3) for j in range(3)]).reshape(3, 3)
    volume_error = abs(row["volume_m3_per_m"] - row["J"]*row["reference_volume_m3_per_m"])
    volume_limit = 1e-10*max(1, row["volume_m3_per_m"])
    tau = np.zeros((3, 3))
    for (i, j), axis in zip(((0, 0), (1, 1), (2, 2), (1, 2), (0, 2), (0, 1)), ("xx", "yy", "zz", "yz", "xz", "xy")):
        tau[i, j] = tau[j, i] = row[f"sig_{axis}_pa"]*row["J"]
    principal = np.linalg.eigvalsh(tau)
    sine = math.sin(row["friction_rad"])
    offset = 2*row["J"]*row["cohesion_pa"]*math.cos(row["friction_rad"])
    residual = max((1+sine)*principal[i]-(1-sine)*principal[j]-offset for i in range(3) for j in range(3) if i != j)
    report["lastSavedID55Frames"].append({"row": row, "vtkID55": vtk,
        "determinantRecomputedFromSavedF9": float(np.linalg.det(f)), "volumeError": volume_error, "volumeLimit": volume_limit,
        "independentSavedSixPlaneResidualPa": float(residual),
        "availableSavedGuardPredicates": {"logicalID": row["particle_id"] == ID, "V_equals_J_V0": volume_error <= volume_limit,
            "sizeXPositive": vtk["size_x"] > 0, "sizeYPositive": vtk["size_y"] > 0,
            "kappaGeInitial": row["mc_kappa"] >= initial["mc_kappa"],
            "workGeInitialMinus1eMinus8": row["plastic_work_pa"] >= initial["plastic_work_pa"]-1e-8,
            "nativeSavedResidualLeTolerance": row["yield_residual_kirchhoff_pa"] <= row["native_yield_tolerance_pa"]}})
report["transferID55"] = next(row for row in ledger["entries"] if row["particleIndex"] == ID)
report["sourceControlFlowFacts"] = [
    "save-state evaluates audit-state before writing the requested VTK or CSV; no failed frame5 output exists",
    "audit-state evaluates gs::measure-state across all particles BEFORE its own per-ID predicate guard",
    "gs::measure-state rejects any nonfinite position/velocity/stress/strain/F/domain-size, nonpositive mass/V/J, changed mass, or center outside computational rectangle",
    "Observed error is the later owned ID55 compound guard, so failed frame5 reached that guard after the preceding all-particle measure-state checks returned",
    "Therefore negative center x/y alone cannot be this observed failure: its source error would have been Particle...left computational domain",
    "The remaining unsaved alternatives are logical ID, V=J*V0 allowance, positive domain-size components, initial kappa/work bounds, or independent native-yield tolerance"
]
assert all(sha(Path(row["path"])) == row["sha256"] for row in provenance["inputs"])
report["allInputsUnchangedAfter"] = True
(OUT / "diagnosis.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
summary = {"failure": manifest["error"], "failedState": report["absentActualFailedState"],
           "savedID55": [{"frame": int(row["row"]["frame"]), "timeS": row["row"]["time_s"],
             "x": row["row"]["x_m"], "y": row["row"]["y_m"], "J": row["row"]["J"],
             "sizeX": row["vtkID55"]["size_x"], "sizeY": row["vtkID55"]["size_y"],
             "kappa": row["row"]["mc_kappa"], "Ds": row["row"]["strength_damage"],
             "workPa": row["row"]["plastic_work_pa"], "volumeError": row["volumeError"],
             "nativeResidualPa": row["row"]["yield_residual_kirchhoff_pa"], "nativeTolPa": row["row"]["native_yield_tolerance_pa"],
             "availableSavedGuardPredicates": row["availableSavedGuardPredicates"]} for row in report["lastSavedID55Frames"]]}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
