"""MEDIA ONLY: encode the existing five unchanged actual native PNG states."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def put(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def record(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


report = load(ROOT / 'review.json')
assert report['nativeComplete'] is False and report['actualDynamicSavedFrames'] == 5
assert [s['timeS'] for s in report['states']] == [0, .5, 1, 1.5, 2]
assert report['media']['decodedFrames'] == 5
frames = [ROOT / 'actual-frames' / f'frame_{i:04d}.png' for i in range(5)]
before = [record(path) for path in frames]
destination = ROOT / 'rough-strength-damage-slow.mp4'
assert not destination.exists()
executable = load(ROOT / 'video-command.json')[0]
command = [executable, '-v', 'error', '-n', '-framerate', '1', '-i', str(ROOT / 'actual-frames/frame_%04d.png'),
           '-frames:v', '5', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-movflags', '+faststart',
           '-metadata', 'comment=Playback slowed to 1 fps; five actual saved native states from simulation 0 to 2 seconds; no interpolation; incomplete rough demo',
           '-vf', 'pad=ceil(iw/2)*2:ceil(ih/2)*2', str(destination)]
put(ROOT / 'slow-media-command-before.json', dict(recordedUtc=datetime.now(timezone.utc).isoformat(), command=command,
    sourceFrames=before, executedScript=record(Path(__file__).resolve()),
    scope='Only encode unchanged existing PNGs; no solver, state audit, plot render or new simulation state'))
encoded = subprocess.run(command, capture_output=True, text=True)
(ROOT / 'slow-video.stderr.log').write_text(encoded.stderr, encoding='utf-8')
assert encoded.returncode == 0
decode_command = [executable, '-v', 'error', '-nostats', '-progress', 'pipe:1', '-i', str(destination), '-f', 'null', '-']
put(ROOT / 'slow-media-decode-command.json', decode_command)
decoded = subprocess.run(decode_command, capture_output=True, text=True)
(ROOT / 'slow-video-decode.stdout.log').write_text(decoded.stdout, encoding='utf-8')
(ROOT / 'slow-video-decode.stderr.log').write_text(decoded.stderr, encoding='utf-8')
counts = [int(line.split('=', 1)[1]) for line in decoded.stdout.splitlines() if line.startswith('frame=')]
assert decoded.returncode == 0 and not decoded.stderr.strip() and counts[-1] == 5
assert before == [record(path) for path in frames]
put(ROOT / 'slow-media.json', dict(scope='PARTIAL ROUGH NUMERICAL DEMO; playback slowed, not a full20s result',
    video=record(destination), actualSavedPhysicalTimesS=[0, .5, 1, 1.5, 2], actualFrames=5,
    playbackFramesPerSecond=1, playbackDurationS=5, interpolation=False, framesModified=False,
    sourceFrameHashesUnchanged=True, fullDecodeExitCode=decoded.returncode, decodedFrameCount=counts[-1],
    nativeSolverRerun=False, stateAuditRepeated=False, sourceFrames=before))
print(json.dumps(dict(video=str(destination), physicalTimeSpanS=[0, 2], playbackDurationS=5,
                     actualFrames=5, fullDecodeExitCode=0, interpolation=False)))
