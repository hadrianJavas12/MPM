;;;; Native headless CLI: windows\cl-mpm.cmd scripts\run-case.lisp cases\CASE.lisp OUTPUT
;;;; A case is trusted executable Lisp, just like any local native script.
(in-package :cl-user)
(require :asdf)
(let ((directory (uiop:pathname-directory-pathname *load-truename*)))
  (load (or (probe-file (merge-pathnames "lisp/native-source-snapshot.lisp" directory))
            (probe-file (merge-pathnames "scripts/lisp/native-source-snapshot.lisp" directory))
            (error "Native source snapshot helper is missing beside the CLI."))))

(let* ((args (cl-mpm-script-args)) (case-file (first args)) (output (second args)))
  (unless (and (= (length args) 2) case-file output)
    (error "Usage: windows\\cl-mpm.cmd scripts\\run-case.lisp cases\\CASE.lisp OUTPUT"))
  (snapshot-require-fresh-runtime)
  (let ((directory (uiop:ensure-directory-pathname (merge-pathnames output))))
    (when (and (probe-file directory)
               (or (uiop:directory-files directory) (uiop:subdirectories directory)))
      (error "Choose a new/empty output directory: ~A" directory))
    (multiple-value-bind (copied records) (snapshot-case-sources directory case-file)
      (snapshot-write-json (merge-pathnames "source/source-manifest.json" directory)
                           (snapshot-object "scope" "Copied bytes before any project load/compilation"
                                            "files" (coerce records 'vector)))
      (let ((*native-snapshot-context* (snapshot-register-native directory records)))
        (snapshot-check-plan "cl-mpm/settings")
        (ql:quickload :cl-mpm/settings :silent t)
        ;; Set the same policy before reading/compiling native #. declarations.
        (setf (symbol-value (find-symbol "*OPTIMISE-SETTING*" "CL-MPM/SETTINGS"))
              '(optimize (speed 3) (safety 1) (debug 1) (compilation-speed 0)))
        (snapshot-check-plan "cl-mpm-framework")
        (ql:quickload :cl-mpm-framework :silent t)
        (snapshot-native-proof)
        (progv (list (find-symbol "*SIMULATION*" :cl-mpm/framework)
                     (find-symbol "*INPUT-ROOT*" :cl-mpm/framework)
                     (find-symbol "*SCHEMA-PATH*" :cl-mpm/framework/config))
               (list nil (merge-pathnames "source/inputs/" directory)
                     (merge-pathnames "source/inputs/studio/schema.json" directory))
          (snapshot-verify-file (merge-pathnames "source/case.lisp" directory))
          (load (merge-pathnames "source/case.lisp" directory))
          (let ((case (symbol-value (find-symbol "*SIMULATION*" :cl-mpm/framework))))
            (unless case (error "The case file must SETF cl-mpm/framework:*simulation*."))
            (write-case-source-provenance directory copied nil)
            ;; Observe a failed return without handling/retrying it. The original
            ;; condition and exit status remain authoritative; no successful step
            ;; allocates a diagnostic or writes a per-particle file.
            (handler-bind
                ((error
                   (lambda (condition)
                     (let* ((package (find-package :cl-mpm/models/mc-evolution))
                            (type (and package (find-symbol "MATERIAL-INTEGRATION-ERROR" package)))
                            (reader (and package (find-symbol "INTEGRATION-ERROR-DIAGNOSTIC" package))))
                       (when (and type (find-class type nil) (typep condition type)
                                  reader (fboundp reader))
                         (let ((record (funcall reader condition)))
                           (when record
                             (handler-case
                                 (with-open-file
                                     (stream (merge-pathnames "mc-integration-failure.json" directory)
                                             :direction :output :if-exists :error
                                             :external-format :utf-8)
                                   ;; Bootstrap JSON deliberately has no float
                                   ;; support; use the already-loaded serializer.
                                   (funcall (find-symbol "ENCODE" :yason) record stream))
                               (error (capture-error)
                                 (format *error-output* "~&MC diagnostic save failed: ~A~%"
                                         capture-error))))))))))
              (funcall (find-symbol "RUN-SIMULATION" :cl-mpm/framework) case :output directory)))))))
  (uiop:quit 0))
