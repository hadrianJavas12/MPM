;;;; Section 2 canonical module descriptor (materials/core/parameters.lisp).
;;;; Active compilation unit owner: materials/core/definition.lisp
(in-package :cl-mpm/framework)
