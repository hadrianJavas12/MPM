(in-package :cl-mpm/damage)

(declaim (ftype (function (double-float double-float double-float double-float )
                          double-float) damage-response-exponential))
(defun damage-response-exponential (stress E init-stress ductility)
  (declare (double-float stress E init-stress ductility))
  "Function that controls how damage evolves with principal stresses"
  (let* ((ft init-stress)
         (e0 (/ ft E))
         (ef (/ (* ft (+ ductility 1d0)) (* 2d0 E)))
         (k (/ stress E))
         (beta (/ 1d0 (- ef e0)))
         )
    (declare (double-float ft e0 ef k beta))
    (if (> k e0)
        (- 1d0 (* (/ e0 k) (exp (- (* beta (- k e0))))))
        0d0)))

(defun find-k-damage-mp (mp damage)

  (with-accessors
        ((E cl-mpm/particle::mp-e)
         (init-stress cl-mpm/particle::mp-initiation-stress)
         (ductility cl-mpm/particle::mp-ductility))
      mp
    (find-k-damage E init-stress ductility damage))
  )
(defun find-k-damage (E init-stress ductility damage)
  (* init-stress
     (cl-mpm/damage::compute-oversize-factor damage ductility))
  ;; (let* ((e0 init-stress)
  ;;        (d-est 0d0)
  ;;        (k-est e0)
  ;;        (k-max nil)
  ;;        (k-prev e0)
  ;;        )
  ;;   (loop for i from 0 to 10000
  ;;         while (> (abs (- damage d-est)) 1d-8)
  ;;         do
  ;;            (progn
  ;;              (setf d-est (damage-response-exponential k-est E init-stress ductility))
  ;;              ;; (format t "~F ~F~%" d-est k-est)
  ;;              (when (> damage d-est)
  ;;                (setf k-prev k-est)
  ;;                (setf k-est
  ;;                      (if k-max
  ;;                          (/ (+ k-prev k-max) 2d0)
  ;;                          (* k-est 2))))
  ;;              (when (< damage d-est)
  ;;                (setf k-max k-est)
  ;;                (setf k-est (/ (+ k-prev k-max) 2d0)))
  ;;              ))
  ;;   k-est)
  )

(declaim (ftype (function (double-float double-float double-float double-float double-float)
                          double-float) damage-response-exponential-peerlings-residual))
(defun damage-response-exponential-peerlings-residual (stress E init-stress ductility residual)
  (declare (double-float stress E init-stress ductility residual))
  "Function that controls how damage evolves with principal stresses"
  (let* ((ft init-stress)
         (e0 (/ ft E))
         (ef (/ (* ft (+ ductility 1d0)) (* 2d0 E)))
         (k (/ stress E))
         (beta (/ 1d0 (- ef e0))))
    (declare (double-float ft e0 ef k beta))
    (if (> k e0)
        (- 1d0 (* (/ e0 k) (+ (- 1d0 residual) (* residual (exp (- (* beta (- k e0))))))))
        0d0)))
(declaim (ftype (function (double-float double-float double-float double-float double-float)
                          double-float) damage-response-exponential-residual))
(defun damage-response-exponential-residual (stress E init-stress ductility residual)
  (declare (double-float stress E init-stress ductility residual))
  "Function that controls how damage evolves with principal stresses"
  (let* ((ft init-stress)
         (e0 (/ ft E))
         (ef (/ (* ft (+ ductility 1d0)) (* 2d0 E)))
         (k (/ stress E))
         (beta (/ 1d0 (- ef e0))))
    (declare (double-float ft e0 ef k beta))
    (if (> k e0)
        (- 1d0 (+ (- 1d0 residual) (* residual (exp (- (* beta (- k e0)))))))
        0d0)))

(defun damage-response-exponential-beta (E init-stress ductility)
  (declare (double-float E init-stress ductility))
  "Function that controls how damage evolves with principal stresses"
  (let* ((ft init-stress)
         (e0 (/ ft E))
         (ef (/ (* ft (+ ductility 1d0)) (* 2d0 E)))
         (beta (/ 1d0 (- ef e0))))
    beta))


(defun estimate-ductility-jirsek2004 (GF R ft E &optional (k 2d0))
  "Simple estimate of ductility from key elastic parameters"
  (declare (double-float GF R ft E k))
  (let* ((e0 (/ ft E))
         (ef (+ (/ GF (* k R E e0)) (/ e0 2d0))))
    (- (* 2d0 (/ ef e0)) 1d0)))

(defun gf-from-ductility (ductility R ft E &optional (k 1d0))
  (declare (double-float ductility R ft E k))
  "Sanity check for estimating fracture energy from ductility and elastic parameters"
  (let ((e0 (/ ft E)))
    (/ (* ductility R E (expt e0 2))
       2d0)))

(defun compute-oversize-factor-residual (damage-final E init-stress ductility residual)
  "Compute the estimated oversize factor (i.e. w * init-stress) required to have plasticity kick in at (d=damage-final)"
  (let* ((ft init-stress)
         (e0 (/ ft E))
         (ef (/ (* ft (+ ductility 1d0)) (* 2d0 E)))
         (beta (/ 1d0 (- ef e0)))
         (y (- 1d0 damage-final))
         )
    (* (/ 1d0 e0)
       (/ (+
           (* y (- ef e0) (cl-mpm/fastmaths::lambert-w-0 (/ (* -1d0 e0 residual (exp (/ (* -1d0 e0 (+ residual y -1d0))
                                                                                          (* y (- e0 ef)))))
                                                              (* y (- e0 ef)))))
             (* e0 -1d0 residual)
             e0
             )
          y))))


(defun compute-oversize-factor (damage-final ductility)
  "Compute the estimated oversize factor (i.e. w * init-stress) required to have plasticity kick in at (d=damage-final)"
  (declare (optimize (speed 0) (debug 3)))
  (when (< ductility 1d0)
    (error "Ductility ~A cannot be less than 1" ductility))
  (if (= damage-final 0d0)
    1d0
    (let* ((eta ductility)
           (value (/ (* 2d0 (exp (/ 2d0 (- eta 1d0))))
                     (* (- 1d0 damage-final) (- eta 1d0)))))
      (* 0.5d0 (- eta 1d0) (cl-mpm/fastmaths::lambert-w-0 value)))))

(defun delayed-damage-y (stress E Gf length init-stress)
  (declare (double-float stress E Gf length init-stress))
  "Function that controls how damage evolves with principal stresses"
  (let* ((ft init-stress)
         (e0 (/ ft E))
         (ef (+ (/ e0 2) (/ Gf (* length ft))))
         (k (/ stress E)))
    (if (> k e0)
        (/ (- stress init-stress) (- (* ef E) init-stress))
        0d0
        )))


(defun damage-response-linear (stress E Gf length init-stress ductility)
   (declare (double-float stress E Gf length init-stress ductility))
   "Linear softening"
   (let* ((ft init-stress)
          (e0 (/ ft E))
          (ef (* e0 ductility))
          (k (/ stress E)))
     (if (> k e0)
         (min 1d0
              (if (> k e0)
                  (* (/ e0 (- ef e0))
                     (- 1d0 (/ e0 k)))))
         0d0)))
