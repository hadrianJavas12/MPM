import gzip,hashlib,io,json,pathlib,shutil,tarfile
root=pathlib.Path.cwd(); src=root/'output/wang2017-reference-2026-10-24/fast-010-001-review';dst=root/'docs/evidence/wang2017-reference-2026-10-24/fast-010-001-review';dst.mkdir(exist_ok=False)
(dst/'.gitattributes').write_text('* -text -whitespace\n*.gz binary\n',encoding='utf8')
for name in ['completed-trial-review.json','review-input-hashes.json','CONTACT_MEASUREMENT_NOTE.md']:
    shutil.copyfile(src/name,dst/name)
shutil.copyfile(src/'media-support/review.json',dst/'media-review.json')
for name in ['fast-010-001-evidence-collection-execution.json','fast-010-001-evidence-collection-verification.json','fast-010-001-evidence-collection.log']:
    p=src.parent/name
    if p.is_file():shutil.copyfile(p,dst/name)
records=[]
with (dst/'all-review-artifacts.tar.gz').open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
    for p in sorted(src.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts:continue
        rel=p.relative_to(src).as_posix();data=p.read_bytes();info=tarfile.TarInfo(rel);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data));records.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
with tarfile.open(dst/'all-review-artifacts.tar.gz','r:gz') as tar:
    assert len(tar.getmembers())==len(records)
    for r in records:
        data=tar.extractfile(r['path']).read();assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
(dst/'review-archive-verification.json').write_text(json.dumps({'allMembersVerified':True,'records':records},indent=2)+'\n',encoding='utf8')
(dst/'README.md').write_text('# Completed fast010 independent review\n\nReview of real61-state Windows native trial,0.01m/s to60mm over6physicalseconds. Native/audit/render exit0. No solver was rerun for review. Scientific validation and coherent landslide remain NOT_VERIFIED. Comparisons align actual saved commanded settlement and stableparticleIDs, not frame indexes across different rates, with no interpolated states. Surface-contact displacement includes domain-height change and is reconstructed independently for all61frames; it differs from particle-centre motion.\n\nMedia runtime QA checks61render-source hashes,265frozen source bytes, actual mapped DLL, worker exit0/session11 and full H264 decode. Video61frames/4fps=15.25seconds playback, fixed axes/colour/scale1; physicaltime6s is distinct. Initial frame-extraction tool-option failure is preserved along with its narrow retry; native/video decoding did not fail.\n\nExact review scripts, input hashes, initial/final review artifacts, selected decoded frames and collection command proof are in all-review-artifacts.tar.gz. Every archived member was reopened and SHA/length verified. Native raw/source/media packet is ../fast-010-001-completed/. None of this establishes paper curve agreement, a closed energy balance, a directly saved loading determinant J or rate independence.\n',encoding='utf8')
entries=[{'path':p.relative_to(dst).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(dst.rglob('*')) if p.is_file()]
(dst/'evidence-manifest.json').write_text(json.dumps({'entries':entries},indent=2)+'\n',encoding='utf8')
for e in entries:assert hashlib.sha256((dst/e['path']).read_bytes()).hexdigest()==e['sha256']
print(json.dumps({'reviewArtifactHashes':len(entries),'reviewArchiveMembers':len(records)}))
