"""Read actual completed accelerated Wang trial; no solver, model edits or interpolation."""
from pathlib import Path
import json
import numpy as np
from native_saved_io import load, vtk, sha

ROOT = Path(__file__).resolve().parents[4]
BASE = ROOT / "output"
RUN = BASE / "wang2017-reference-2026-10-24/fast-010-001"
DEST = RUN.with_name(RUN.name + "-review")


def comparison(current, other):
    records = []
    for value in sorted(set(current[4]) & set(other[4])):
        ci, oi = current[4].index(value), other[4].index(value)
        cp, cf = current[3][ci]
        op, of = other[3][oi]
        if not np.array_equal(cf["unique-id"], of["unique-id"]):
            raise ValueError("Cross-run IDs differ")
        cr, rr = current[1][ci], other[1][oi]
        dpos, dk = cp-op, cf["mc-kappa"]-of["mc-kappa"]
        force_delta = cr["reaction_upward_N_per_m"]-rr["reaction_upward_N_per_m"]
        records.append({
            "commandedSettlementM": float(value), "currentFrame": ci, "otherFrame": oi,
            "currentTimeS": cr["time_s"], "otherTimeS": rr["time_s"],
            "currentReactionNPerM": cr["reaction_upward_N_per_m"], "otherReactionNPerM": rr["reaction_upward_N_per_m"],
            "currentMinusOtherReactionNPerM": force_delta,
            "reactionDifferenceOverAbsOtherOrNull": force_delta/abs(rr["reaction_upward_N_per_m"]) if rr["reaction_upward_N_per_m"] else None,
            "currentKineticJPerM": cr["kinetic_energy_J_per_m"], "otherKineticJPerM": rr["kinetic_energy_J_per_m"],
            "maxPositionDistanceM": float(np.linalg.norm(dpos, axis=1).max()),
            "rmsPositionDistanceM": float(np.sqrt(np.mean(np.sum(dpos*dpos, axis=1)))),
            "maxAbsNativeKappaDifference": float(np.abs(dk).max()),
            "rmsNativeKappaDifference": float(np.sqrt(np.mean(dk*dk))),
            "maxAbsStressYYDifferencePa": float(np.abs(cf["sig_yy"]-of["sig_yy"]).max()),
        })
    return {"alignment": "Exact Decimal equality of saved commanded settlement and sorted native unique-id; no interpolation",
            "matchedSavedCommandCount": len(records), "states": records,
            "rateConvergence": "NOT_VERIFIED: observations only; no tolerance PASS assigned"}


def main():
    current = load(RUN)
    wrapper_status_path = RUN.with_name(RUN.name+"-status.json")
    wrapper_status = json.loads(wrapper_status_path.read_text(encoding="utf-8-sig"))
    if wrapper_status.get("nativeExitCode") != 0 or wrapper_status.get("auditAndRenderExitCode") != 0:
        raise ValueError("Native and audit completion not established by adjacent wrapper status")
    old_fast = load(BASE / "wang2017-reference-2026-10-23/diagnostic-fast-005-002")
    slow = load(BASE / "wang2017-reference-2026-10-23/rate-002-001")
    manifest, force, energy, states = current[:4]
    if manifest.get("complete") is not True or manifest["status"] != "complete":
        raise ValueError("This analysis requires the genuinely complete native manifest")
    command = manifest["config"]["targetDisplacement"]
    if abs(force[-1]["commanded_settlement_m"]-command) > 1e-12:
        raise ValueError("Complete flag does not reach target")
    original, original_fields = vtk(RUN / "vtk/gravity_initial.vtk")
    p0, f0 = states[0]
    final, fields = states[-1]
    if not np.array_equal(original_fields["unique-id"], fields["unique-id"]):
        raise ValueError("Original IDs differ")
    delta = final-p0
    speed = np.sqrt(fields["vel_x"]**2+fields["vel_y"]**2)
    velocity = np.column_stack((fields["vel_x"],fields["vel_y"],np.zeros(len(final))))
    mass = fields["mass"]
    dk = fields["mc-kappa"]-f0["mc-kappa"]
    cfg = manifest["config"]
    top = original[:,1] == original[:,1].max()
    half_size = original_fields["size_x"]*.5
    left, right = cfg["patchStart"], cfg["patchStart"]+cfg["patchLength"]
    overlap = np.maximum(0, np.minimum(right,original[:,0]+half_size)-np.maximum(left,original[:,0]-half_size))
    strip = top & (overlap>0)
    above_base = original[:,1]>cfg["baseHeight"]
    masks = {"all": np.ones(len(final),dtype=bool), "aboveBaseOriginalYGreater5m": above_base,
             "baseOriginalYAtMost5m": ~above_base, "trackedStripOriginalTopOverlap": strip,
             "aboveBaseExcludingTrackedStrip": above_base & ~strip}
    slope_angle = np.deg2rad(cfg["slope"])
    downslope = delta[:,0]*np.cos(slope_angle)-delta[:,1]*np.sin(slope_angle)
    motion = {}
    for name, mask in masks.items():
        m, d, v = mass[mask], delta[mask], speed[mask]
        weighted = np.average(d,axis=0,weights=m)
        mean_velocity = np.average(velocity[mask],axis=0,weights=m)
        rms_velocity = float(np.sqrt(np.average(v*v,weights=m)))
        vector_norm = np.linalg.norm(d,axis=1)
        motion[name] = {
            "particleCount": int(mask.sum()), "massKgPerM": float(m.sum()),
            "massWeightedCentroidMotionM": weighted.tolist(),
            "massWeightedMeanMotionNormM": float(np.linalg.norm(weighted)),
            "maxMotionNormM": float(vector_norm.max()),
            "maxAbsHorizontalMotionM": float(np.abs(d[:,0]).max()),
            "maxDownwardMotionM": float((-d[:,1]).max()),
            "maxUpwardMotionM": float(d[:,1].max()),
            "massWeightedRmsDeviationFromMeanVectorM": float(np.sqrt(np.average(np.sum((d-weighted)**2,axis=1),weights=m))),
            "maxSpeedMPerS": float(v.max()), "massWeightedRmsSpeedMPerS": float(np.sqrt(np.average(v*v,weights=m))),
            "massWeightedMeanVelocityMPerS": mean_velocity.tolist(),
            "meanVelocityNormOverRmsSpeed": float(np.linalg.norm(mean_velocity)/rms_velocity) if rms_velocity else None,
            "massFractionVelocityRightwardAndDownward": float(m[(velocity[mask,0]>0)&(velocity[mask,1]<0)].sum()/m.sum()),
            "massFractionRightwardMotionGreater5mm": float(m[d[:,0]>.005].sum()/m.sum()),
            "massFractionRightwardMotionGreater10mm": float(m[d[:,0]>.01].sum()/m.sum()),
            "massFractionDownwardMotionGreater10mm": float(m[-d[:,1]>.01].sum()/m.sum()),
            "massFractionSpeedExceedsDriverSpeed": float(m[v>cfg["velocity"]].sum()/m.sum()),
            "massWeightedMeanDownslopeProjectionM": float(np.average(downslope[mask],weights=m)),
        }
    max_id_index = int(np.linalg.norm(delta,axis=1).argmax())
    max_motion = {"nativeUniqueId": int(fields["unique-id"][max_id_index]),
                  "originalPositionM": original[max_id_index].tolist(), "settledPositionM": p0[max_id_index].tolist(),
                  "finalPositionM": final[max_id_index].tolist(), "deltaFromSettledM": delta[max_id_index].tolist(),
                  "trackedStrip": bool(strip[max_id_index]), "aboveBase": bool(above_base[max_id_index])}
    speed_index = int(speed.argmax())
    max_speed_particle = {"nativeUniqueId": int(fields["unique-id"][speed_index]),
                          "originalPositionM": original[speed_index].tolist(),
                          "finalPositionM": final[speed_index].tolist(),
                          "finalVelocityMPerS": [float(fields["vel_x"][speed_index]),float(fields["vel_y"][speed_index])],
                          "speedMPerS": float(speed[speed_index]),
                          "trackedStrip": bool(strip[speed_index]),"aboveBase": bool(above_base[speed_index]),
                          "finalSpeedQuantilesMPerS": {str(q): float(np.quantile(speed,q)) for q in (.5,.9,.95,.99,1.0)}}
    series = []
    contact_reconstruction = []
    for row,(points,values) in zip(force,states):
        movement = points-p0
        speeds = np.sqrt(values["vel_x"]**2+values["vel_y"]**2)
        subset = above_base & ~strip
        series.append({"timeS": row["time_s"],"commandedSettlementM":row["commanded_settlement_m"],
                       "maxAllParticleMotionM":float(np.linalg.norm(movement,axis=1).max()),
                       "maxAllAbsHorizontalMotionM":float(np.abs(movement[:,0]).max()),
                       "aboveBaseNoStripCentroidMotionM":np.average(movement[subset],axis=0,weights=mass[subset]).tolist(),
                       "aboveBaseNoStripRmsSpeedMPerS":float(np.sqrt(np.average(speeds[subset]**2,weights=mass[subset]))),
                       "aboveBaseNoStripMaxSpeedMPerS":float(speeds[subset].max())})
        centre_downward = p0[:,1]-points[:,1]
        half_height_change = .5*(f0["size_y"]-values["size_y"])
        top_downward = centre_downward+half_height_change
        mean_centre = float(np.average(centre_downward[strip],weights=overlap[strip]))
        mean_half_height = float(np.average(half_height_change[strip],weights=overlap[strip]))
        mean_top = float(np.average(top_downward[strip],weights=overlap[strip]))
        gap = row["commanded_settlement_m"]-top_downward[strip]
        contact_reconstruction.append({"frame":int(row["frame"]),"timeS":row["time_s"],
            "meanCentreDescentM":mean_centre,"meanHalfHeightReductionM":mean_half_height,
            "reconstructedMeanTopSurfaceDescentM":mean_top,"csvMeasuredTopSurfaceDescentM":row["measured_settlement_m"],
            "topMeasurementResidualM":mean_top-row["measured_settlement_m"],
            "reconstructedMaxIndividualGapM":float(np.abs(gap).max()),"csvMaxIndividualGapM":row["max_gap_m"]})
    max_contact_identity_error = max(abs(r["topMeasurementResidualM"]) for r in contact_reconstruction)
    max_gap_identity_error = max(abs(r["reconstructedMaxIndividualGapM"]-r["csvMaxIndividualGapM"]) for r in contact_reconstruction)
    if max(max_contact_identity_error,max_gap_identity_error)>1e-12:
        raise ValueError("Saved-data contact geometry identity does not reproduce CSV precision")
    measurement_sources = ["scenarios/slope-descent/boundary.lisp","src/output/vtk.lisp","src/core/simulation-base.lisp"]
    measurement_identity = {
        "formula":"top_point_y = particle_centre_y + .5*mp_domain_size_y; descent = (y0-y) + .5*(size_y0-size_y)",
        "weights":"Original top-particle overlap widths with patch[7,10]m; all six widths0.5m",
        "stripParticleIds":fields["unique-id"][strip].astype(int).tolist(),
        "particleCentreMotionAndSurfaceDescentAreDifferentObservables":True,
        "maxAbsReconstructedMeanSurfaceDescentMinusCsvM":max_contact_identity_error,
        "maxAbsReconstructedMaxGapMinusCsvM":max_gap_identity_error,
        "finalDecomposition":contact_reconstruction[-1],
        "finalIndividualCentreDescentM":(p0[:,1]-final[:,1])[strip].tolist(),
        "finalIndividualHalfHeightReductionM":(.5*(f0["size_y"]-fields["size_y"]))[strip].tolist(),
        "finalIndividualTopSurfaceDescentM":(p0[:,1]-final[:,1]+.5*(f0["size_y"]-fields["size_y"]))[strip].tolist(),
        "executedSourceSha256":{path:sha(RUN/"source"/path) for path in measurement_sources},
        "sourceInterpretation":"Frozen boundary.top-point adds half current domain height to mp-position. Frozen vtk exports mp-domain-size as size vector and mp-position-trial as coordinates; update-particle-kirchoff copies updated mp-position into mp-position-trial before saved output. Data identity independently reproduces the recorded contact measurements across all61states.",
        "frames":contact_reconstruction,
    }
    top_indices = np.argsort(dk)[-50:]
    total_increment = float(np.sum(dk*mass))
    localization = {
        "meaning": "Native accumulated plastic history increment from settled frame0, not damage or Soil2 tensor history",
        "rangeOfIncrement": [float(dk.min()),float(dk.max())],
        "countIncrementGreater1eMinus8": int((dk>1e-8).sum()),
        "countIncrementGreater1eMinus3": int((dk>.001).sum()),
        "largest50IncrementOriginalBoundingBoxM": [original[top_indices].min(axis=0).tolist(),original[top_indices].max(axis=0).tolist()],
        "largest50IncrementSettledBoundingBoxM": [p0[top_indices].min(axis=0).tolist(),p0[top_indices].max(axis=0).tolist()],
        "largest50IncrementMassWeightedShareOfAllIncrement": float(np.sum(dk[top_indices]*mass[top_indices])/total_increment) if total_increment else None,
        "largest50IncrementTrackedStripCount": int(strip[top_indices].sum()),
        "massWeightedIncrementBySubset": {name: float(np.sum(dk[mask]*mass[mask])) for name,mask in masks.items()},
        "largest50ParticleIds": fields["unique-id"][top_indices].astype(int).tolist(),
        "shearBandOrFailureMechanism": "NOT_VERIFIED: increment concentration alone does not prove a throughgoing failure surface",
    }
    last, en = force[-1], energy[-1]
    result = {
        "scope": "Actual complete accelerated trial, native exit0 independently retained by wrapper; no new solver calls. Scientific validation and reference-speed completion are not claimed.",
        "wrapperEvidence":{"path":str(wrapper_status_path),"sha256":sha(wrapper_status_path),
                           "nativeExitCode":wrapper_status["nativeExitCode"],"auditAndRenderExitCode":wrapper_status["auditAndRenderExitCode"]},
        "scientificValidation": False,"nativeManifestComplete": True,"actualDurationS": last["time_s"],
        "actualCommandedSettlementM": last["commanded_settlement_m"],"loadingRateMultiplier": manifest["loadingRateMultiplier"],
        "native": current[6],"motionDefinition": "ID-aligned final minus settled loading-frame0 particle centres; gravity movement excluded",
        "motion": motion,"largestMotionParticle": max_motion,"fastestFinalParticle":max_speed_particle,
        "contactGeometryIdentity":measurement_identity,
        "motionTimeSeries":series,
        "maxAcrossAllSavedFramesMotionM":max(row["maxAllParticleMotionM"] for row in series),
        "maxAcrossAllSavedFramesAbsHorizontalMotionM":max(row["maxAllAbsHorizontalMotionM"] for row in series),
        "nativePlasticLocalization": localization,
        "contact": {"expectedContactsFromOriginalGeometry": int(strip.sum()),"manifestContacts": manifest["stripContactCount"],
                    "lastCommandedSettlementM": last["commanded_settlement_m"],"lastMeasuredTopPointSettlementM": last["measured_settlement_m"],
                    "lastMeanGapM": last["penalty_gap_m"],"lastMaxIndividualGapM": last["max_gap_m"],
                    "lastReactionUpwardNPerM": last["reaction_upward_N_per_m"],
                    "lastReactionDividedByStripWidthPa": last["reaction_upward_N_per_m"]/cfg["patchLength"],
                    "referenceComparison": "No digitized/reference reaction target supplied; raw output is not paper-curve agreement",
                    "reactionMeaning": "Total actuator reaction, unit-thickness N/m; width-normalized value is mean applied stress, not deviatoric stress"},
        "energyObservations": {"lastKineticJPerM": en["kinetic_J_per_m"],
                               "lastDeltaElasticProxyJPerM": en["delta_elastic_proxy_J_per_m"],
                               "lastDeltaNativePlasticProxyJPerM": en["delta_native_plastic_proxy_J_per_m"],
                               "lastSignedActuatorCommandWorkJPerM": en["actuator_signed_command_work_J_per_m"],
                               "energyClosure": "NOT_VERIFIED: current-volume Hencky/native-plastic proxies omit a closed balance; prestress can mask inertia"},
        "comparisonWith005": comparison(current,old_fast),"comparisonWith002": comparison(current,slow),
        "initialIdentityWith005": {name: sha(RUN/name)==sha(BASE/"wang2017-reference-2026-10-23/diagnostic-fast-005-002"/name)
                                   for name in ("gravity-state.csv","vtk/gravity_initial.vtk","vtk/gravity_equilibrium.vtk","vtk/particles_0000.vtk")},
        "interpretation": {"landslide": "NOT_VERIFIED: inspect horizontal motion, spatially coherent movement and time evolution separately; imposed top-strip settlement is not by itself slope collapse",
                           "downslopeProjection": "Contains vertical settlement; positive projection does not prove sliding or run-out",
                           "quasiStaticOrRateConvergence": "NOT_VERIFIED: loading velocities are20x,50x,100x paper with different physical observation times",
                           "geometryAndBoundary": "10m relief assumed; fixed bottom and side rollers constrain motion; paper endpoint/restraint not independently verified",
                           "loadingDeterminantJ": "NOT_DIRECTLY_SAVED; only positive current/reference volume ratios are available for loading"},
    }
    DEST.mkdir(exist_ok=True)
    (DEST/"completed-trial-review.json").write_text(json.dumps(result,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    (DEST/"CONTACT_MEASUREMENT_NOTE.md").write_text(
        "# Particle-centre motion and measured strip descent\n\n"
        "These observables use different physical points. The maximum native VTK particle-centre displacement is59.128931mm, on tracked particle509. "
        "The CSV59.535670mm is the width-weighted descent of six particle top surfaces. Frozen boundary.lisp defines top-point as centre plus half the current domain height. "
        "Each top-surface descent therefore equals centre descent plus half the domain-height reduction; domain compression can make surface descent exceed every particle-centre displacement norm.\n\n"
        f"Final strip mean centre descent {mean_centre*1000:.9f}mm + mean half-height reduction {mean_half_height*1000:.9f}mm = mean surface descent {mean_top*1000:.9f}mm. "
        f"Reconstruction from saved coordinates/size_y matches the CSV over all61states to maximum {max_contact_identity_error:.3e}m; individual maximum-gap reconstruction differs by at most {max_gap_identity_error:.3e}m. "
        "The script also checks these identities within1e-12m, compatible with CSV serialization precision. These are measurement identities, not scientific-validation tests. "
        "Exact frozen source hashes, individual particle values and all61identity records are in completed-trial-review.json/contactGeometryIdentity. No solver or physics was changed.\n",
        encoding="utf-8")
    inputs = {"analysisSources": {p.name: sha(p) for p in Path(__file__).parent.glob("*.py")},
              "currentInputs": current[7],"adjacentWrapperStatus":{"path":str(wrapper_status_path),"sha256":sha(wrapper_status_path)},
              "measurementSources":measurement_identity["executedSourceSha256"],
              "comparison005Inputs": old_fast[7],"comparison002Inputs": slow[7]}
    (DEST/"review-input-hashes.json").write_text(json.dumps(inputs,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"native":result["native"],"motion":motion,"largestMotionParticle":max_motion,
                      "localization":localization,"comparison005Last":result["comparisonWith005"]["states"][-1],
                      "comparison002Last":result["comparisonWith002"]["states"][-1],"energy":result["energyObservations"]},indent=2))


if __name__=="__main__":
    main()
