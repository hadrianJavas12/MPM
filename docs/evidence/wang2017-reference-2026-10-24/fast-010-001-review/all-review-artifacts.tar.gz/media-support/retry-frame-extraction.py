"""Retry only unsupported legacy-vsync frame extraction; preserve first review."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

out = Path(__file__).resolve().parent
review_path = out / "review.json"
review = json.loads(review_path.read_text(encoding="utf-8"))
assert review["fullDecodeExitCode"] == review["ffprobeExitCode"] == 0
assert review["selectedFramesExitCode"] != 0
assert not (out / "review.attempt001.json").exists()
shutil.copy2(review_path, out / "review.attempt001.json")
video = Path(review["videoPath"])
integrity = json.loads((out / "input-integrity.json").read_text(encoding="utf-8"))
video_sha = hashlib.sha256(video.read_bytes()).hexdigest()
assert video_sha == integrity["afterSha256"][str(video)]
arguments = [shutil.which("ffmpeg"), "-hide_banner", "-v", "error", "-i", str(video),
             "-vf", "select=eq(n\\,0)+eq(n\\,30)+eq(n\\,60)", "-fps_mode", "passthrough", str(out / "video-selected-%02d.png")]
result = subprocess.run(arguments, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
(out / "ffmpeg-selected-frames.attempt002.stdout.log").write_text(result.stdout, encoding="utf-8")
(out / "ffmpeg-selected-frames.attempt002.stderr.log").write_text(result.stderr, encoding="utf-8")
(out / "frame-retry-command.json").write_text(json.dumps({"arguments": arguments, "exitCode": result.returncode,
    "reason": "Installed ffmpeg rejects removed legacy -vsync; use -fps_mode passthrough. Only selected-frame extraction repeated.",
    "videoSha256Unchanged": video_sha}, indent=2)+"\n", encoding="utf-8")
assert result.returncode == 0
assert len(list(out.glob("video-selected-*.png"))) == 3
review["selectedFramesExitCode"] = result.returncode
review["frameExtractionRetry"] = "Initial -vsync failure retained; current -fps_mode passthrough succeeded. No solver or prior passed checks repeated."
review["status"] = "PASS"
review_path.write_text(json.dumps(review, indent=2)+"\n", encoding="utf-8")
print("Selected frame extraction retry PASS;3 decoded images. Original failed review and logs retained.")
