"""Read-only independent post-run media/runtime checks; no solver execution."""
from pathlib import Path
import argparse
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def utc(path):
    return datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-directory", required=True)
    parser.add_argument("--review-directory", required=True)
    args = parser.parse_args()
    run = Path(args.run_directory).resolve()
    out = Path(args.review_directory).resolve()
    detached = run.with_name(run.name + "-detached")
    audit_path = run / "output-audit.json"
    provenance_path = run / "source-provenance.json"
    source_manifest_path = run / "source/source-manifest.json"
    status_path = run.with_name(run.name + "-status.json")
    worker_paths = [detached / name for name in ["launch-proof.json", "launch-request.json", "launch-request.ps1", "worker-start.json", "worker-exit.json"]]
    immutable_paths = [audit_path, provenance_path, source_manifest_path, status_path, run / "manifest.json", run / "slope-descent.mp4"] + worker_paths
    before = {str(path): digest(path) for path in immutable_paths}
    audit, provenance, source_manifest, status = map(load, [audit_path, provenance_path, source_manifest_path, status_path])
    proof, request, worker_start, worker_exit = map(load, [worker_paths[0], worker_paths[1], worker_paths[3], worker_paths[4]])
    native_end = datetime.fromisoformat(status["nativeEndedUtc"].replace("Z", "+00:00"))
    copied_checks = []
    for item in source_manifest["files"]:
        path = run / item["path"].replace("\\", "/")
        copied_checks.append({"path": item["path"], "expectedSha256": item["sha256"].lower(), "actualSha256": digest(path), "bytes": path.stat().st_size, "expectedBytes": item["bytes"], "lastWriteUtc": utc(path), "lastWriteNotAfterNativeExit": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc) <= native_end})
    save(out / "copied-source-checks.json", copied_checks)
    source_ok = all(item["expectedSha256"] == item["actualSha256"] and item["bytes"] == item["expectedBytes"] for item in copied_checks)
    vtk_checks = []
    for item in audit["sources"]:
        if item["path"].lower().endswith(".vtk"):
            path = run / item["path"].replace("\\", "/")
            vtk_checks.append({"path": item["path"], "expectedSha256": item["sha256"].lower(), "actualSha256": digest(path), "bytes": path.stat().st_size})
    save(out / "render-vtk-checks.json", vtk_checks)
    raw_vtks = list((run / "vtk").glob("particles_*.vtk"))
    vtk_ok = len(vtk_checks) == len(raw_vtks) == 61 and all(item["expectedSha256"] == item["actualSha256"] for item in vtk_checks)
    backend = provenance["nativeBackend"]
    backend_path = Path(backend["modulePath"])
    backend_ok = backend_path.resolve() == (run / "source/libs/kirchoff.dll").resolve() and digest(backend_path) == backend["sha256"].lower() and backend["verifiedBy"] == "GetModuleHandleW/GetModuleFileNameW" and backend["nativeMcEntryPresent"]
    ffprobe = shutil.which("ffprobe")
    ffmpeg = shutil.which("ffmpeg")
    commands = []
    def command(arguments, stem):
        result = subprocess.run(arguments, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
        (out / (stem + ".stdout.log")).write_text(result.stdout, encoding="utf-8")
        (out / (stem + ".stderr.log")).write_text(result.stderr, encoding="utf-8")
        commands.append({"arguments": arguments, "exitCode": result.returncode, "stdout": stem + ".stdout.log", "stderr": stem + ".stderr.log"})
        return result
    probe = command([ffprobe, "-v", "error", "-count_frames", "-show_streams", "-show_format", "-of", "json", str(run / "slope-descent.mp4")], "ffprobe")
    probe_json = json.loads(probe.stdout) if probe.returncode == 0 else {}
    streams = [item for item in probe_json.get("streams", []) if item.get("codec_type") == "video"]
    stream = streams[0] if len(streams) == 1 else {}
    decode = command([ffmpeg, "-hide_banner", "-v", "error", "-i", str(run / "slope-descent.mp4"), "-f", "null", "NUL"], "ffmpeg-full-decode")
    extract = command([ffmpeg, "-hide_banner", "-v", "error", "-i", str(run / "slope-descent.mp4"), "-vf", "select=eq(n\\,0)+eq(n\\,30)+eq(n\\,60)", "-vsync", "0", str(out / "video-selected-%02d.png")], "ffmpeg-selected-frames")
    sessions = {"caller": proof["callerSessionId"], "workerProof": proof["workerSessionId"], "workerStart": worker_start["sessionId"]}
    sessions.update({key: value["sessionId"] for key, value in status["processIdentity"].items()})
    identity_ok = proof["returnValue"] == 0 and proof["startupObserved"] and proof["workerProcessId"] == worker_start["processId"] == worker_exit["processId"] and proof["workerCreationUtc"] == worker_start["creationUtc"] and proof["workerParentProcessId"] == worker_start["parentProcessId"] and worker_exit["status"] == "WORKER_EXITED" and worker_exit["exitCode"] == 0 and len(set(sessions.values())) == 1
    request_ok = digest(worker_paths[1]) == proof["requestSha256"].lower() and digest(worker_paths[2]) == proof["workerScriptSha256"].lower()
    rendering = audit["visualization"]
    video_ok = probe.returncode == decode.returncode == extract.returncode == 0 and stream.get("codec_name") == "h264" and stream.get("pix_fmt") == "yuv420p" and int(stream.get("nb_read_frames", 0)) == 61 and stream.get("avg_frame_rate") == "4/1" and rendering["displacementScale"] == 1 and rendering["interpolatedStates"] is False
    after = {str(path): digest(path) for path in immutable_paths}
    unchanged = before == after
    save(out / "input-integrity.json", {"beforeSha256": before, "afterSha256": after, "unchanged": unchanged})
    save(out / "commands.json", commands)
    review = {
        "status": "PASS" if all([source_ok, vtk_ok, backend_ok, identity_ok, request_ok, video_ok, unchanged]) else "FAIL",
        "scope": "Independent media/runtime artifact consistency; not scientific validation or FEM equivalence.",
        "reviewedUtc": datetime.now(timezone.utc).isoformat(),
        "videoPath": str(run / "slope-descent.mp4"),
        "nativeComplete": status["nativeComplete"], "nativeExitCode": status["nativeExitCode"], "auditAndRenderExitCode": status["auditAndRenderExitCode"],
        "physicalTimeS": audit["physicalTimeS"], "commandedSettlementM": audit["commandedSettlementM"], "velocityMPerS": audit["loadingVelocityMPerS"], "paperRateMultiplier": audit["loadingRateMultiplier"],
        "copiedSourceFiles": len(copied_checks), "copiedSourceHashesAndSizesMatch": source_ok,
        "sourceLastWritesNotAfterNativeExit": all(item["lastWriteNotAfterNativeExit"] for item in copied_checks),
        "sourceSnapshotExactLoadedBytesClaim": provenance["sourceSnapshotExactLoadedBytes"], "copiedByteEqualityBeforeLoadClaim": provenance["copiedByteEqualityBeforeLoad"],
        "sourceProvenanceLastWriteUtc": utc(provenance_path), "nativeEndedUtc": status["nativeEndedUtc"],
        "renderSourceVtkHashesMatchAll61RawFiles": vtk_ok, "renderSourceVtkCount": len(vtk_checks),
        "actualMappedNativeBackend": backend, "mappedDllHashMatchesFrozenCopy": backend_ok,
        "wmiWorkerIdentityAndTerminalExitMatch": identity_ok, "sessions": sessions, "launchRequestAndWorkerHashesMatch": request_ok,
        "ffprobeExitCode": probe.returncode, "fullDecodeExitCode": decode.returncode, "selectedFramesExitCode": extract.returncode,
        "video": {key: stream.get(key) for key in ["codec_name", "pix_fmt", "width", "height", "avg_frame_rate", "nb_read_frames", "duration"]},
        "visualization": rendering,
        "originalInputsUnchanged": unchanged,
        "visualInspection": "Pending direct image inspection of selected start/middle/end decoded frames.",
        "limits": ["Only6s at0.01m/s (100x paper rate), not600s at1e-4m/s.", "Native mc-kappa is plastic history, not damage or calibrated Soil2 softening.", "Hash/mtime equality supports retained bytes and snapshot claims; it is not proof every non-ASDF or external dependency was frozen.", "SessionId11 stayed consistent in recorded process observations; logoff/reboot survival is not established.", "Gravity convergence/output consistency do not establish quasistatic response, paper agreement or experimental validity."] + provenance["limits"],
    }
    save(out / "review.json", review)
    print(json.dumps({key: review[key] for key in ["status", "copiedSourceFiles", "copiedSourceHashesAndSizesMatch", "sourceLastWritesNotAfterNativeExit", "renderSourceVtkHashesMatchAll61RawFiles", "mappedDllHashMatchesFrozenCopy", "wmiWorkerIdentityAndTerminalExitMatch", "fullDecodeExitCode", "video", "originalInputsUnchanged"]}, indent=2))
    return 0 if review["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
