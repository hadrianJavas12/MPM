"""Record direct decoded-image inspection and hash this isolated QA packet."""
from pathlib import Path
import hashlib
import json

out = Path(__file__).resolve().parent
path = out / "review.json"
review = json.loads(path.read_text(encoding="utf-8"))
assert review["status"] == "PASS"
review["visualInspection"] = {
    "method": "Direct view_image inspection of three PNGs decoded from the completed MP4, at encoded frame indices0,30,60.",
    "inspectedFrames": [
        {"file": "video-selected-01.png", "physicalTimeS": 0, "observation": "Legible particle view and empty loading curve at t0; axes/colour scale and100x accelerated-trial labels visible."},
        {"file": "video-selected-02.png", "physicalTimeS": 3, "observation": "Legible mid-run curve through30mm; geometry changes remain small at scale1."},
        {"file": "video-selected-03.png", "physicalTimeS": 6, "observation": "Legible final curve through60mm and localized mc-kappa colour near upper slope; no gross landslide/run-out visible."},
    ],
    "layout": "No clipping or missing panels observed. Fixed spatial/colour bounds; explicit no displacement amplification label.",
    "interpretation": "Playable native accelerated Soil1 control, not600s paper-rate output or demonstrated landslide. mc-kappa is plastic history, not damage.",
}
path.write_text(json.dumps(review, indent=2)+"\n", encoding="utf-8")
records = []
for item in sorted(out.iterdir()):
    if item.is_file() and item.name != "review-artifacts.json":
        records.append({"path": item.name, "bytes": item.stat().st_size, "sha256": hashlib.sha256(item.read_bytes()).hexdigest()})
(out / "review-artifacts.json").write_text(json.dumps({"scope": "Independent post-run media/runtime QA artifacts including preserved initial extraction failure and exact analysis sources.", "files": records}, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"status": review["status"], "visualInspection": "3 decoded frames inspected; no gross landslide visible", "artifacts": len(records)}, indent=2))
