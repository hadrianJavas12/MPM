# Unexecuted hash-only fixture; no postprocessing expected.
