; No MPM is loaded by the mock Windows launcher.
