# Root review of actual saved full-run output

Reviewed 26 October 2026 (WIB), after native and frozen saved-data review exit0.
Native source: `354273763ad43f3efc48163c7d2d245d977d3402`.

The root viewed `variant-review-002/gravity-slope-review.png`, SHA256
`e434c95950b40752201ea262633073501d2435258a4813e29fee555a451f4348`.
This is the existing scale1 summary of the actual 61 saved native states;
no solver, rendering or decoding was repeated for this visual inspection.
The existing video is `variant-review-002/gravity-slope-actual.mp4`, SHA256
`9f348ac4076eaf0677171b5f3a7dd47406a12c8fb3dba24bd35bf7bd2d24512d`:
61 actual states at4fps,15.25s playback representing6s physical time,
deformation scale1, no interpolation, previously recorded full-decode exit0.

## Observations and decision

- The slope retains its overall shape. Plastic history localizes mainly near
  the lower face/toe; no detached or coherently translating upper mass is
  apparent. Plastic history colour is not a damage/fracture variable.
- Fixed initial upper-cohort final centroid displacement is
  (+0.0639870242872917,-0.03619730050392523)m. Relative to the saved2s state,
  its final increment is (+0.04489286987213638,-0.02126246042063403)m.
  Horizontal motion plateaus around3.2s and kinetic energy decays after its
  transient peak. Final cohort mean velocity is
  (-0.000339550848414852,+0.000051721500811350576)m/s.
- The preregistered whole-run and post2s connected-motion tests both report
  NOT_DETECTED; no qualifying component or toe-runout gate is detected.
  The observer's physical-metre thresholds are retained without relaxation.
- Frozen variant review reports integrityPASS on61 states/880 IDs/53680
  particle rows, including F/J, mass, six-plane current-state yield, law,
  cumulative work/volume and CSV/VTK consistency. There are no sampled
  floor-penetrating or domain-exiting centres. The minimum particle-domain
  margin is -8.524677552995685e-6m; full particle-support containment and
  validated runout contact are not claimed.

**Decision: native completion and saved integrity pass; verified landslide,
runout and scientific validation remain false.** Local yield and transient
plastic deformation occur, but this run does not establish sustained global
failure. Its optional volumetric apex flow is a declared material extension,
not unchanged strictMC or exact reproduction of a journal model.

Preserve this negative result. Diagnose fixed-base/adapted-foundation and
resolution effects from the saved mechanism before another expensive study.
Do not automatically extend duration or increase SRF. A same-factor finer-grid
experiment, if justified and preregistered, is a resolution study rather than
confirmation of an already observed slide. Same CFL with a smaller grid is
coupled space/time refinement. Quantitative FoS/runout validation is open.
