"""One terminal file/runtime-record verification; no PID or numerical query."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "output/mc-composite-apex-2026-10-26"
NAME = "srf1p6-composite-001"
RUN = RAW / NAME


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def record(path):
    payload = path.read_bytes()
    return {"path": str(path), "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}


def main():
    target = RUN / "terminal-native-source-runtime-verification.json"
    support = RUN / "terminal-proof-support"
    if target.exists() or support.exists():
        raise RuntimeError("Preserve the first terminal proof; do not repeat")
    status = read(RAW / (NAME + "-status.json"))
    worker_path = RAW / (NAME + "-detached/worker-exit.json")
    worker, manifest = read(worker_path), read(RUN / "manifest.json")
    if not (status["status"] == "NATIVE_COMPLETE_REVIEW_PENDING" and status["nativeExitCode"] == 0
            and status["nativeComplete"] and worker["exitCode"] == 0
            and manifest["complete"] is True and manifest["status"] == "complete"
            and manifest["timeS"] == 6 and manifest["savedFrames"] == 61
            and manifest["particleCount"] == 880 and manifest["updates"] == 7740):
        raise RuntimeError("Actual terminal scope differs")
    rows = read(RUN / "source/source-manifest.json")["files"]
    if len({row["path"] for row in rows}) != len(rows):
        raise RuntimeError("Duplicate frozen native source")
    verified = []
    for row in rows:
        path = (RUN / row["path"]).resolve()
        if not path.is_relative_to((RUN / "source").resolve()):
            raise RuntimeError("Frozen source escapes its tree")
        actual = record(path)
        if (actual["bytes"], actual["sha256"]) != (row["bytes"], row["sha256"]):
            raise RuntimeError("Frozen bytes changed since pre-load manifest")
        verified.append({"path": row["path"], "bytes": actual["bytes"], "sha256": actual["sha256"]})
    provenance = read(RUN / "source-provenance.json")
    backend, dll = provenance["nativeBackend"], RUN / "source/libs/kirchoff.dll"
    if not (provenance["sourceSnapshotExactLoadedBytes"] and provenance["copiedByteEqualityBeforeLoad"]
            and set(provenance["copiedFiles"]) == {row["path"] for row in rows}
            and Path(backend["modulePath"]).resolve() == dll.resolve()
            and backend["sha256"] == record(dll)["sha256"]
            and backend["verifiedBy"] == "GetModuleHandleW/GetModuleFileNameW"):
        raise RuntimeError("Recorded actual mapped-DLL/pre-solver source proof disagrees")
    expected = ["materials/models/plastic/mc-composite-apex/" + name + ".lisp"
                for name in ("package", "projection", "native")]
    expected += ["materials/adapters/mc-composite-apex.lisp", "scenarios/gravity-slope/mc-composite-apex-adapter.lisp"]
    loaded = {Path(row["source"]).resolve() for row in provenance["verifiedAsdfActions"]
              if row.get("firstParty") is True and row.get("event") == "performing" and row.get("operation") == "load-op"}
    if any((RUN / "source" / name).resolve() not in loaded for name in expected):
        raise RuntimeError("Optional runtime sources were not recorded loaded")
    support.mkdir()
    (support / "executed-verifier.py").write_bytes(Path(__file__).read_bytes())
    invocation = {"argv": sys.argv, "startedUtc": datetime.now(timezone.utc).isoformat(),
                  "scope": "Terminal file/provenance hash verification only; no process/native/analysis invocation"}
    (support / "invocation.json").write_text(json.dumps(invocation, indent=2) + "\n", encoding="utf-8")
    records = [record(RUN / path) for path in ("manifest.json", "source/source-manifest.json", "source-provenance.json")]
    records += [record(path) for path in sorted(RAW.glob(NAME + "*")) if path.is_file()]
    records += [record(path) for path in sorted((RAW / (NAME + "-detached")).rglob("*")) if path.is_file()]
    report = {"status": "PASS", "verifiedUtc": datetime.now(timezone.utc).isoformat(),
        "nativeSourceCommit": status["sourceCommit"], "nativeExit": 0, "workerExit": 0,
        "nativeComplete": True, "physicalTimeS": 6, "savedFrames": 61, "particleCount": 880, "acceptedUpdates": 7740,
        "sourceCount": len(rows), "files": verified, "allTerminalHashesMatchOriginalPreloadManifest": True,
        "runtimeNativeBackend": backend, "requiredOptionalSourcesRecordedLoaded": expected,
        "originalRuntimeProvenanceTiming": "Written after case load and BEFORE solver; no separate native after-provenance exists or is invented",
        "terminalProofScope": "Independent retained file hashes after supervisor/worker terminal, checked against original before-load manifest and recorded actual runtime mapping. No PID remapping or saved-state audit.",
        "capturedTerminalRecords": records, "executedVerifier": record(Path(__file__)),
        "landslideVerified": False, "scientificallyValidated": False}
    target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"proof": str(target), "status": "PASS", "sources": len(rows), "nativeExit": 0, "workerExit": 0}))


if __name__ == "__main__":
    main()
