# Composite apex design checkpoint

This separate artifact retains the pure-algebra design and synthetic coexistence
fixture. These are not a simulation, native replay, or scientific validation.
The earlier actual failure replay is immutable in failure-replay-002.

The explicit optional model adds g_A=p volumetric flow only at the hydrostatic
apex, while preserving the strict model as a separate default. All regular and
apex candidates are enumerated before ambiguity rejection. No chosen-root
fallback or collapse-based selector is approved.

The sufficient noncoexistence proof in apex-coexistence-exclusion-bound.json
uses true tensor shear/Frobenius norms and current Cauchy-to-Kirchhoff J.
At the paper E20MPa, nu.25 and captured J1.0018908194640175, the Lipschitz
coefficient .04742637140993 is below beta_min .86351461550859; Jcrit is
18.24190508426521. This excludes a distinct apex/nonhydrostatic regular pair
under that bound, not ordinary-root multiplicity or global constitutive
uniqueness. The soft E0.5MPa fixture deliberately violates the bound and
requires ambiguity rejection. No modulus was changed in the physical case.

The point work/compliance checks are local fixed-J Hencky/Kirchhoff checks;
they do not prove finite-strain thermodynamics or solver energy balance.
The native monotonic-history scope guard remains. Controls are NOT_RUN at
this source-only checkpoint. Source hashes are in source-only-checkpoint.json.
