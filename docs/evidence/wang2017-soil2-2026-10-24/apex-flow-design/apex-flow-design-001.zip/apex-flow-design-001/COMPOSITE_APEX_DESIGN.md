# Proposed opt-in composite apex flow: design only

No production implementation, native replay, old control or slope run accompanies
this proposal. The existing strict material must remain unchanged. This is an
explicit new flow rule at the MC apex, not a correction preserving strict psi0.

## Constitutive definition and unique apex candidate

Use the existing six shear yield planes and zero-dilation shear directions
`m_ij=e_i-e_j`. Add the redundant MC support plane
`fA=p-J*c(k)*cot(phi)<=0` with potential `gA=p`, so its flow direction is `I/3`.
This support plane touches the MC domain only at its hydrostatic apex. It adds a
flow direction, without imposing a free tensile-strength parameter or altering
the existing elastic domain.

For current trial Kirchhoff tensor `tau_tr`, fixed positive J and isotropic G,K:

1. `d=dev(tau_tr)/(2G)` is the unique deviatoric plastic increment required for
   a hydrostatic return. Compute it in the captured spatial frame, or map trial
   principal components through Q.
2. `kA=paper-kps(Ep_rotated+d)`. Hydrostatic plastic strain does not affect this norm.
3. `pA=J*c(kA)*cot(phi)` and `q=(p_tr-pA)/K`.
4. Require q>=0, then form the FULL increment `deltaEp=d+(q/3)I`, full candidate
   `Ep_new=Ep_rotated+deltaEp`, and elastic return `he_new=he_tr-deltaEp`.
5. Independently check `kA=paper-kps(Ep_new)`, `C:he_new=pA I`, all six shear
   planes and fA active, fixed J, finite values, declared history scope and work.

This scalar construction gives at most one apex stress/history state. It does
not claim that the combined material has only one admissible state.

For the actual captured input, the analytic candidate has:

- kA=.016530943069873974; c=17601.79269759452Pa;
- pA=25185.49650996058Pa; q=1.2187681321902346e-7;
- full-history residual and elastic-compliance residual both zero at double precision;
- Kirchhoff plastic work pA*q=.00306952805397Pa, positive.

The complete tensor and all diagnostic values are in
`apex-composite-design-diagnostic.json`. This is a hypothetical candidate of the
NEW model, not a successful return of the strict model or a simulation result.

## Positive multipliers do not select a branch

At the apex all six shear planes are active. Their psi0 directions generate the
entire trace-free diagonal plane as a positive cone: transfer each negative
component of d to its positive components using nonnegative lambda_ij. A
deterministic transfer ordering can provide one auditable multiplier decomposition,
but different decompositions producing the same deltaEp are not different material roots.
The hydrostatic multiplier is lambdaA=q because dgA/dtau=I/3.

Consequently, positive shear multipliers impose no additional restriction on d.
The combined cone is the half-space `trace(deltaEp)>=0`. Restricting the set to
some trial-selected faces would be another constitutive/loading rule and needs
its own definition. Do not claim positivity proves uniqueness.

This cone is NOT the associated MC(phi) normal cone. For associated flow a
necessary component bound is

`-(1-sin(phi))*q/(2sin(phi)) <= deltaEp_i <= (1+sin(phi))*q/(2sin(phi))`.

The actual candidate violates that bound substantially. Calling it associated MC
would therefore be incorrect. It is specifically a composite psi0 shear plus
volumetric-apex flow graph. Mathematically, this half-space is also the closed
limit of the six-face positive flow cones as positive dilation approaches zero;
the exact psi0 cone alone remains trace-free. This limiting interpretation is an
explicit modeling choice, not evidence that Wang used it.

## Constant-cohesion legacy correspondence

In libs/src/constitutive.h:234-252, with psi0, rg1=rg2=(1,1,1). The legacy
selector numerators are `trace(Ce*(tau_tr-pA I))=q`; their denominators are
positive for valid E,nu and phi. Thus t1,t2>0 reduce to p_tr>pA (apart from the
legacy numerical tolerance). The legacy return then sets tau=pA I and recomputes
elastic strain by Ce*tau, giving precisely the full compliance increment above.

For Cauchy cohesion the legacy call must use J*c as its Kirchhoff cohesion.
This establishes the constant-c zero-dilation apex region/stress/compliance
correspondence. It does not make the proposed softening/history completion an
unchanged legacy model, nor equate it to a standard associated-apex prescription.

## Work, J and objectivity

At the candidate, `tau_new:deltaEp=pA*q>=0` because c>=0, phi>0, J>0 and q>=0.
With the current isotropic Hencky elastic quadratic at fixed supplied J:

`W_trial-W_new=pA*q+G*(d:d)+(K/2)*q^2>=0`.

These are useful point-level mechanical admissibility/energy checks. They do not
prove a full finite-strain Clausius-Duhem inequality for the existing corotational
signed Ep approximation, a closed global energy budget, softening fracture energy,
or mesh objectivity.

Use the existing polar transport only on committed Ep; Q and d are already in
the current trial frame. J remains the determinant supplied by external
kinematics; do not change F/J to manufacture dilation. Plastic trace q reduces
elastic trace by the same amount, preserving the scalar elastic/plastic log-volume
split when the prior split was consistent. Native additive J2 uses only d;
plastic-volume history receives q. All current/committed fields and failure
diagnostics must remain transactional.

## Coexistence is real

`apex-coexistence-design-fixture.json` is pure algebra using synthetic E=.5MPa,
nu=.25, J=1, Q=I, oldEp=diag(-.0035,.0015,.002), and trialtau=diag(33000,27000,6000)Pa.
It is NOT a change to Wang's E20MPa case. The trial exceeds old yield by3957Pa.

- A monotonic strict face return has k=.00423668876986, positive multiplier,
  tau=(30286.9516,27000,8713.0484)Pa and positive work146.3276Pa.
- The composite apex has k=.0332866339542, residual c15kPa, pA21422.2201Pa,
  q=.001733339697 and positive work37.1320Pa.

Both satisfy the declared nondecreasing-history scope. The literal strict
equations additionally have a decreasing-history root, excluded by that scope;
the current strict API would already reject its raw multiplicity. The example
nevertheless proves that positivity, work and the history guard cannot ensure
uniqueness of the extended admissible set.

## Required selection and verification gates

A deterministic honest PARTIAL solver is possible: enumerate smooth faces,
edges, residual branches and the apex candidate together; apply every declared
admissibility/history constraint; deduplicate equal stress/full-increment/history
states; accept exactly one, reject zero or multiple. Never catch an arbitrary
integration exception and force the apex. Rejecting ambiguity can stop a run; it
does not promise a collapse result.

Keep the existing elastic-predictor rule explicit. If an elastic trial is inside
the old domain, choosing the elastic continuation is a stated loading rule. If
global finite-increment root uniqueness is claimed instead, include the elastic
candidate when assessing coexistence with distant softening roots.

Selecting least work, nearest stress, largest damage, or the apex merely because
it completes a run is unjustified. Defensible future continuation must specify
the loading/deformation homotopy, follow a branch connected to the previous
accepted state, demonstrate step-refinement/path consistency, and detect folds
or bifurcations. A fold may still prevent continuation. Viscoplastic or nonlocal
regularization introduces time/length parameters requiring calibration or an
explicit sensitivity study; it is not a parameter-free remedy.

Before a new slope run: isolated point tests must cover the actual capsule,
constant-c legacy correspondence, outside-domain rejection, the coexistence
fixture/ambiguity retention, full tensor/compliance/work/J checks, observer
rotation, repeated trials, rollback/copy/loadstep, and strict-model regression.
Only a separately named opt-in class/scenario may activate this flow. The paper's
apex convention remains unverified and must not be represented as established.
